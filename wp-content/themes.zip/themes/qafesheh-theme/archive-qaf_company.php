<?php
/**
 * أرشيف الشركات.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

get_header();

qafesheh_banner(
	array(
		'title'   => qafesheh_sec( 'companies', 'arch_title', 'شركات المجموعة' ),
		'text'    => qafesheh_sec( 'companies', 'arch_intro', '' ),
		'image'   => qafesheh_sec_image_id( 'companies' ),
	)
);
?>

<section class="q-sec">
	<div class="q-wrap">
		<?php
		qafesheh_render_section_head(
			array(
				'num'   => '٠١',
				'label' => 'قطاعات الأعمال',
				'title' => 'ثلاث علاماتٍ متخصصة',
				'text'  => qafesheh_sec( 'companies', 'arch_intro', '' ),
			)
		);
		?>
	</div>
	<div class="q-wrap" style="margin-block-start:var(--q-sp-9)">
		<?php
		qafesheh_render_companies();
		?>
	</div>
</section>

<?php
get_footer();
