<?php
/**
 * القالب العام: الأرشيفات والمقالات والصفحات التي لا قالب خاص لها.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

get_header();

/* عنوان البانر حسب السياق */
if ( is_home() ) {
	$q_title = 'المقالات والأخبار';
} elseif ( is_post_type_archive() ) {
	$q_title = post_type_archive_title( '', false );
} elseif ( is_tax() || is_category() || is_tag() ) {
	$q_title = single_term_title( '', false );
} elseif ( is_search() ) {
	/* translators: %s: كلمة البحث */
	$q_title = sprintf( 'نتائج البحث عن «%s»', get_search_query() );
} else {
	$q_title = get_the_title();
}

qafesheh_banner(
	array(
		'title'   => $q_title,
		'image'   => is_singular() ? get_post_thumbnail_id() : 0,
	)
);
?>

<section class="q-sec">
	<div class="q-wrap">

		<?php if ( have_posts() ) : ?>

			<?php if ( is_singular() ) : ?>

				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<article <?php post_class(); ?>>
						<div class="q-prose">
							<?php
							the_content();

							wp_link_pages(
								array(
									'before' => '<div class="q-pager">',
									'after'  => '</div>',
								)
							);
							?>
						</div>
					</article>

					<?php
					if ( comments_open() || get_comments_number() ) {
						comments_template();
					}
					?>
					<?php
				endwhile;
				?>

			<?php else : ?>

				<div class="q-cards" id="q-archive" data-q-stagger>
					<?php
					while ( have_posts() ) :
						the_post();
						qafesheh_card( get_post() );
					endwhile;
					?>
				</div>

				<?php qafesheh_pagination(); ?>

			<?php endif; ?>

		<?php else : ?>

			<div class="q-empty">
				<h2>لا يوجد محتوى بعد</h2>
				<p>لم نعثر على ما تبحث عنه. جرّب البحث بكلمات أخرى أو عُد إلى الرئيسية.</p>
				<?php qafesheh_button( 'العودة للرئيسية', home_url( '/' ), 'solid' ); ?>
			</div>

		<?php endif; ?>

	</div>
</section>

<?php
get_footer();
