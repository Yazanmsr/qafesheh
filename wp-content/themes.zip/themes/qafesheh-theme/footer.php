<?php
/**
 * الفوتر — خمسة أعمدة وشريط غرز علوي، كما في التصميم.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

$q_columns = array(
	'footer_group'   => 'المجموعة',
	'footer_brands'  => 'شركاتنا',
	'footer_service' => 'خدمة العملاء',
);
?>
</main>

<footer class="q-foot">

	<?php if ( qafesheh_opt( 'footer_stitch', 1 ) ) : ?>
		<div class="q-foot__stitch" aria-hidden="true"></div>
	<?php endif; ?>

	<div class="q-wrap q-foot__in">

		<div class="q-foot__cols">

			<div class="q-foot__brand">
				<?php
				$q_logo = qafesheh_opt_image( 'logo_light', 'medium' );
				$q_src  = $q_logo['url'] ? $q_logo['url'] : qafesheh_url( 'assets/images/logo-qafesheh.png' );
				?>
				<span class="q-foot__mark">
					<img src="<?php echo esc_url( $q_src ); ?>" alt="" width="120" height="120" loading="lazy">
				</span>

				<span class="q-foot__name"><?php echo esc_html( qafesheh_opt( 'brand_ar', 'مجموعة قفيشة الصناعية' ) ); ?></span>
				<span class="q-foot__latin"><?php echo esc_html( qafesheh_opt( 'brand_en', 'QAFESHEH INDUSTRIAL GROUP' ) ); ?></span>

				<?php if ( qafesheh_opt( 'footer_about' ) ) : ?>
					<p class="q-foot__about"><?php echo esc_html( qafesheh_opt( 'footer_about' ) ); ?></p>
				<?php endif; ?>
			</div>

			<?php foreach ( $q_columns as $q_location => $q_title ) : ?>
				<?php if ( has_nav_menu( $q_location ) ) : ?>
					<div class="q-foot__col">
						<h2 class="q-foot__col-title"><?php echo esc_html( $q_title ); ?></h2>
						<?php
						wp_nav_menu(
							array(
								'theme_location' => $q_location,
								'container'      => false,
								'menu_class'     => 'q-foot__list',
								'depth'          => 1,
								'fallback_cb'    => false,
							)
						);
						?>
					</div>
				<?php endif; ?>
			<?php endforeach; ?>

			<div class="q-foot__col">
				<h2 class="q-foot__col-title">تواصل</h2>

				<div class="q-foot__contact">
					<?php if ( qafesheh_opt( 'c_email' ) ) : ?>
						<a dir="ltr" href="mailto:<?php echo esc_attr( qafesheh_opt( 'c_email' ) ); ?>"><?php echo esc_html( qafesheh_opt( 'c_email' ) ); ?></a>
					<?php endif; ?>

					<?php if ( qafesheh_opt( 'c_phone' ) ) : ?>
						<a dir="ltr" href="<?php echo esc_url( qafesheh_tel_href( qafesheh_opt( 'c_phone' ) ) ); ?>"><?php echo esc_html( qafesheh_opt( 'c_phone' ) ); ?></a>
					<?php endif; ?>

					<?php if ( qafesheh_opt( 'c_address' ) ) : ?>
						<span><?php echo esc_html( qafesheh_opt( 'c_address' ) ); ?></span>
					<?php endif; ?>

					<?php qafesheh_social( 'q-social' ); ?>
				</div>
			</div>

		</div>

		<div class="q-foot__bar">
			<span><?php echo esc_html( qafesheh_opt( 'footer_copy' ) ); ?></span>

			<div class="q-foot__legal">
				<?php
				if ( has_nav_menu( 'footer_legal' ) ) {
					wp_nav_menu(
						array(
							'theme_location' => 'footer_legal',
							'container'      => false,
							'menu_class'     => 'q-foot__legal-list',
							'items_wrap'     => '%3$s',
							'depth'          => 1,
							'fallback_cb'    => false,
							'walker'         => new Qafesheh_Flat_Walker(),
						)
					);
				}
				?>
				<span><?php echo esc_html( qafesheh_opt( 'footer_credit' ) ); ?></span>
			</div>
		</div>

	</div>
</footer>

<button class="q-top" type="button" aria-label="العودة للأعلى">↑</button>

<?php wp_footer(); ?>
</body>
</html>
