<?php
/**
 * صفحة فرع واحد.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

get_header();

while ( have_posts() ) :
	the_post();

	$q_city  = (string) get_post_meta( get_the_ID(), 'q_branch_city', true );
	$q_addr  = (string) get_post_meta( get_the_ID(), 'q_branch_addr', true );
	$q_phone = (string) get_post_meta( get_the_ID(), 'q_branch_phone', true );
	$q_hours = (string) get_post_meta( get_the_ID(), 'q_branch_hours', true );
	$q_map   = (string) get_post_meta( get_the_ID(), 'q_branch_map', true );

	qafesheh_banner(
		array(
			'title'   => get_the_title(),
			'image'   => get_post_thumbnail_id() ? get_post_thumbnail_id() : qafesheh_sec_image_id( 'branches' ),
		)
	);
	?>

	<section class="q-sec">
		<div class="q-wrap">
			<div class="q-single">

				<div class="q-prose"><?php the_content(); ?></div>

				<aside class="q-single__side">
					<div class="q-box">
						<h2 class="q-box__title">بيانات الفرع</h2>
						<dl class="q-box__list">
							<?php if ( $q_addr ) : ?>
								<div class="q-caps__row"><dt>العنوان</dt><dd><?php echo esc_html( $q_addr ); ?></dd></div>
							<?php endif; ?>
							<?php if ( $q_phone ) : ?>
								<div class="q-caps__row"><dt>الهاتف</dt><dd><a dir="ltr" href="<?php echo esc_url( qafesheh_tel_href( $q_phone ) ); ?>"><?php echo esc_html( $q_phone ); ?></a></dd></div>
							<?php endif; ?>
							<?php if ( $q_hours ) : ?>
								<div class="q-caps__row"><dt>الدوام</dt><dd><?php echo esc_html( $q_hours ); ?></dd></div>
							<?php endif; ?>
						</dl>

						<?php if ( $q_map ) : ?>
							<a class="q-box__cta" href="<?php echo esc_url( $q_map ); ?>" target="_blank" rel="noopener">الموقع على الخريطة ↗</a>
						<?php endif; ?>
					</div>
				</aside>

			</div>
		</div>
	</section>

	<?php
endwhile;

get_footer();
