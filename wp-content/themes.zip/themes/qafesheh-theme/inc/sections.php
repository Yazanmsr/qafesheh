<?php
/**
 * إعدادات الأقسام — كل قسم له صفحته وخياراته المستقلة.
 * الخدمات لها إعداداتها، الشركات لها إعداداتها… لا شيء مكدّس في مكان واحد.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * تعريف الأقسام.
 *
 * @return array
 */
function qafesheh_sections() {
	static $sections = null;
	if ( null !== $sections ) {
		return $sections;
	}

	/* حقول مشتركة لرأس صفحة الأرشيف */
	$header = function ( $title, $eyebrow, $intro ) {
		return array(
			'title'   => 'رأس الصفحة',
			'fields'  => array(
				'arch_title'   => array(
					'type'    => 'text',
					'label'   => 'عنوان الصفحة',
					'default' => $title,
				),
				'arch_eyebrow' => array(
					'type'    => 'text',
					'label'   => 'السطر العلوي (لاتيني)',
					'default' => $eyebrow,
				),
				'arch_intro'   => array(
					'type'    => 'textarea',
					'label'   => 'الفقرة التعريفية',
					'default' => $intro,
				),
				'arch_image'   => array(
					'type'  => 'image',
					'label' => 'صورة البانر',
					'help'  => 'تظهر خلف عنوان الصفحة. عرض ٢٥٦٠px يُفضَّل.',
				),
			),
		);
	};

	/* حقول مشتركة لدعوة التواصل أسفل الصفحة */
	$cta = function ( $title, $text, $btn ) {
		return array(
			'title'  => 'دعوة التواصل أسفل الصفحة',
			'fields' => array(
				'cta_on'    => array(
					'type'    => 'toggle',
					'label'   => 'إظهار القسم',
					'default' => 1,
				),
				'cta_title' => array(
					'type'    => 'text',
					'label'   => 'العنوان',
					'default' => $title,
				),
				'cta_text'  => array(
					'type'    => 'text',
					'label'   => 'النص',
					'default' => $text,
				),
				'cta_btn'   => array(
					'type'    => 'text',
					'label'   => 'نص الزر',
					'default' => $btn,
				),
				'cta_url'   => array(
					'type'  => 'url',
					'label' => 'رابط الزر',
				),
			),
		);
	};

	$cols = array(
		'type'    => 'select',
		'label'   => 'عدد الأعمدة',
		'default' => '3',
		'options' => array(
			'2' => 'عمودان',
			'3' => 'ثلاثة أعمدة',
			'4' => 'أربعة أعمدة',
		),
	);

	$sections = array(

		'services' => array(
			'label'     => 'الخدمات',
			'menu'      => 'إعدادات الخدمات',
			'icon'      => 'dashicons-admin-tools',
			'post_type' => 'qaf_service',
			'desc'      => 'شكل صفحة الخدمات وترتيبها. الخدمات نفسها تُضاف من «كل الخدمات».',
			'groups'    => array(
				$header(
					'خدمات المجموعة',
					'OUR SERVICES',
					'من التصنيع والتطريز إلى الجملة والتصدير — خدمات المجموعة تغطي دورة المنتج كاملة، من الفكرة إلى باب التاجر.'
				),
				array(
					'title'  => 'العرض',
					'fields' => array(
						'cols'      => $cols,
						'per_page'  => array(
							'type'    => 'number',
							'label'   => 'عدد الخدمات في الصفحة',
							'default' => 12,
							'min'     => 3,
							'max'     => 48,
						),
						'show_num'  => array(
							'type'    => 'toggle',
							'label'   => 'إظهار رقم الخدمة (٠١)',
							'default' => 1,
						),
						'show_more' => array(
							'type'    => 'toggle',
							'label'   => 'إظهار زر «اقرأ المزيد»',
							'default' => 1,
						),
					),
				),
				$cta(
					'تحتاج خدمةً بمواصفاتٍ خاصة؟',
					'فريق المجموعة يستقبل طلبات التصنيع والتوريد والعلامات الخاصة على مدار العام.',
					'تواصل معنا'
				),
			),
		),

		'companies' => array(
			'label'     => 'الشركات',
			'menu'      => 'إعدادات الشركات',
			'icon'      => 'dashicons-building',
			'post_type' => 'qaf_company',
			'desc'      => 'شكل صفحة الشركات وبطاقاتها في الرئيسية.',
			'groups'    => array(
				$header(
					'شركات المجموعة',
					'OUR COMPANIES',
					'لكل علامةٍ من علامات المجموعة جمهورها وهويتها البصرية وخطّ إنتاجها، ويجمعها مصنعٌ واحد ومعيارُ جودةٍ واحد.'
				),
				array(
					'title'  => 'العرض',
					'fields' => array(
						'cols'       => array(
							'type'    => 'select',
							'label'   => 'عدد الأعمدة',
							'default' => '3',
							'options' => array(
								'2' => 'عمودان',
								'3' => 'ثلاثة أعمدة',
							),
						),
						'show_color' => array(
							'type'    => 'toggle',
							'label'   => 'إظهار لون كل علامة على بطاقتها',
							'default' => 1,
						),
						'show_shop'  => array(
							'type'    => 'toggle',
							'label'   => 'إظهار زر «زيارة المتجر»',
							'default' => 1,
						),
						'shop_txt'   => array(
							'type'    => 'text',
							'label'   => 'نص زر المتجر',
							'default' => 'زيارة المتجر',
						),
					),
				),
			),
		),

		'branches' => array(
			'label'     => 'الفروع',
			'menu'      => 'إعدادات الفروع',
			'icon'      => 'dashicons-store',
			'post_type' => 'qaf_branch',
			'desc'      => 'شكل صفحة الفروع والفلترة بالعلامة التجارية.',
			'groups'    => array(
				$header(
					'فروعنا ومعارضنا',
					'OUR BRANCHES',
					'معارض المجموعة موزّعة في عمّان وإربد، إضافةً إلى المصنع في سحاب. بعض المعارض تعرض أكثر من علامةٍ واحدة.'
				),
				array(
					'title'  => 'العرض',
					'fields' => array(
						'cols'        => $cols,
						'show_filter' => array(
							'type'    => 'toggle',
							'label'   => 'إظهار فلتر العلامات التجارية',
							'default' => 1,
						),
						'show_map'    => array(
							'type'    => 'toggle',
							'label'   => 'إظهار زر «الموقع على الخريطة»',
							'default' => 1,
						),
						'show_hours'  => array(
							'type'    => 'toggle',
							'label'   => 'إظهار ساعات الدوام',
							'default' => 1,
						),
					),
				),
				$cta(
					'لم تجد فرعاً قريباً؟',
					'تواصل معنا وسنرشدك إلى أقرب نقطة بيع أو نرتّب لك طلباً مباشراً من المصنع.',
					'تواصل معنا'
				),
			),
		),

		'jobs' => array(
			'label'     => 'الوظائف',
			'menu'      => 'إعدادات الوظائف',
			'icon'      => 'dashicons-businessperson',
			'post_type' => 'qaf_job',
			'desc'      => 'شكل صفحة الوظائف ونموذج التقديم.',
			'groups'    => array(
				$header(
					'الوظائف الشاغرة',
					'CAREERS',
					'نبحث باستمرار عن حِرَفيين ومشرفين وكوادر بيع وتسويق. إن لم تجد شاغراً مناسباً الآن، أرسل سيرتك الذاتية وسنحتفظ بها.'
				),
				array(
					'title'  => 'العرض والتقديم',
					'fields' => array(
						'cols'      => array(
							'type'    => 'select',
							'label'   => 'عدد الأعمدة',
							'default' => '2',
							'options' => array(
								'1' => 'قائمة بعمود واحد',
								'2' => 'عمودان',
								'3' => 'ثلاثة أعمدة',
							),
						),
						'apply_txt' => array(
							'type'    => 'text',
							'label'   => 'نص زر التقديم',
							'default' => 'قدّم على الوظيفة',
						),
						'apply_mail' => array(
							'type'    => 'email',
							'label'   => 'بريد استقبال الطلبات',
							'default' => 'info@qafesheh.com',
						),
						'form_code' => array(
							'type'  => 'text',
							'label' => 'شورت كود نموذج التقديم',
							'help'  => 'انسخ الشورت كود من Contact Form 7 والصقه هنا، مثال: [contact-form-7 id="123"]',
						),
					),
				),
			),
		),

		'articles' => array(
			'label'     => 'المقالات والأخبار',
			'menu'      => 'إعدادات المقالات',
			'icon'      => 'dashicons-media-document',
			'post_type' => 'post',
			'desc'      => 'شكل صفحة المقالات والأخبار.',
			'groups'    => array(
				$header(
					'المقالات والأخبار',
					'NEWS & ARTICLES',
					'أخبار المجموعة ومقالاتٌ عن الفروة والبشت والمطرزات والعناية بها.'
				),
				array(
					'title'  => 'العرض',
					'fields' => array(
						'cols'       => $cols,
						'show_date'  => array(
							'type'    => 'toggle',
							'label'   => 'إظهار تاريخ النشر',
							'default' => 1,
						),
						'show_excerpt' => array(
							'type'    => 'toggle',
							'label'   => 'إظهار المقتطف',
							'default' => 1,
						),
						'excerpt_len' => array(
							'type'    => 'number',
							'label'   => 'عدد كلمات المقتطف',
							'default' => 20,
							'min'     => 8,
							'max'     => 60,
						),
					),
				),
			),
		),

		'complaints' => array(
			'label'     => 'الشكاوى والاقتراحات',
			'menu'      => 'إعدادات الشكاوى',
			'icon'      => 'dashicons-megaphone',
			'post_type' => 'qaf_complaint',
			'desc'      => 'نصوص صفحة الشكاوى وبريد الاستقبال.',
			'groups'    => array(
				$header(
					'الشكاوى والاقتراحات',
					'FEEDBACK',
					'رأيك يصل مباشرة إلى فريق المجموعة. كل رسالة تُسجَّل في نظامنا بحيث لا تضيع أي ملاحظة.'
				),
				array(
					'title'  => 'النموذج',
					'fields' => array(
						'types'     => array(
							'type'    => 'text',
							'label'   => 'أنواع الرسائل',
							'default' => 'شكوى، اقتراح، استفسار، شكر',
							'help'    => 'افصل بينها بفاصلة. تظهر كقائمة اختيار في النموذج.',
						),
						'to_mail'   => array(
							'type'    => 'email',
							'label'   => 'بريد استقبال الرسائل',
							'default' => 'info@qafesheh.com',
						),
						'thanks'    => array(
							'type'    => 'textarea',
							'label'   => 'رسالة الشكر بعد الإرسال',
							'default' => 'تم استلام رسالتك، شكراً لك. سنعود إليك في أقرب وقت.',
						),
						'privacy'   => array(
							'type'    => 'text',
							'label'   => 'سطر الخصوصية تحت النموذج',
							'default' => 'بياناتك تُستخدم للردّ على رسالتك فقط ولا تُشارك مع أي جهة.',
						),
					),
				),
			),
		),
	);

	return $sections;
}

/**
 * مفتاح الخيار لقسم معيّن.
 *
 * @param string $section معرّف القسم.
 * @return string
 */
function qafesheh_sec_key( $section ) {
	return 'qafesheh_sec_' . sanitize_key( $section );
}

/**
 * حقول قسم مسطّحة.
 *
 * @param string $section معرّف القسم.
 * @return array
 */
function qafesheh_sec_fields( $section ) {
	$sections = qafesheh_sections();
	if ( empty( $sections[ $section ]['groups'] ) ) {
		return array();
	}

	$fields = array();
	foreach ( $sections[ $section ]['groups'] as $group ) {
		foreach ( (array) ( $group['fields'] ?? array() ) as $key => $field ) {
			$fields[ $key ] = $field;
		}
	}
	return $fields;
}

/**
 * خيارات قسم كاملة مدموجة مع الافتراضيات.
 *
 * @param string $section معرّف القسم.
 * @return array
 */
function qafesheh_sec_options( $section ) {
	static $cache = array();
	if ( isset( $cache[ $section ] ) ) {
		return $cache[ $section ];
	}

	$defaults = array();
	foreach ( qafesheh_sec_fields( $section ) as $key => $field ) {
		$defaults[ $key ] = $field['default'] ?? '';
	}

	$saved = get_option( qafesheh_sec_key( $section ), array() );
	$saved = is_array( $saved ) ? $saved : array();

	$cache[ $section ] = array_merge( $defaults, $saved );
	return $cache[ $section ];
}

/**
 * قراءة خيار قسم.
 *
 * @param string $section  القسم.
 * @param string $key      المفتاح.
 * @param mixed  $fallback بديل.
 * @return mixed
 */
function qafesheh_sec( $section, $key, $fallback = '' ) {
	$options = qafesheh_sec_options( $section );
	if ( ! array_key_exists( $key, $options ) ) {
		return $fallback;
	}
	$value = $options[ $key ];
	return ( '' === $value || null === $value ) ? $fallback : $value;
}

/**
 * صورة من خيارات قسم.
 *
 * @param string $section القسم.
 * @param string $key     المفتاح.
 * @param string $size    الحجم.
 * @return int
 */
function qafesheh_sec_image_id( $section, $key = 'arch_image', $size = 'full' ) {
	unset( $size );
	return absint( qafesheh_sec( $section, $key, 0 ) );
}

/**
 * تسجيل خيارات كل قسم.
 */
function qafesheh_register_section_settings() {
	foreach ( array_keys( qafesheh_sections() ) as $section ) {
		register_setting(
			'qafesheh_sec_group_' . $section,
			qafesheh_sec_key( $section ),
			array(
				'type'              => 'array',
				'sanitize_callback' => function ( $input ) use ( $section ) {
					return qafesheh_sanitize_fields( $input, qafesheh_sec_fields( $section ) );
				},
				'show_in_rest'      => false,
			)
		);
	}
}
add_action( 'admin_init', 'qafesheh_register_section_settings' );

/**
 * مسح كاش القسم عند الحفظ.
 *
 * @param string $option اسم الخيار.
 */
function qafesheh_sec_purge( $option ) {
	if ( 0 !== strpos( (string) $option, 'qafesheh_sec_' ) ) {
		return;
	}
	do_action( 'litespeed_purge_all' );
	wp_cache_flush();
}
add_action( 'updated_option', 'qafesheh_sec_purge' );
add_action( 'added_option', 'qafesheh_sec_purge' );
