<?php
/**
 * أصناف الودجات.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

if ( ! did_action( 'elementor/loaded' ) ) {
	return;
}

/**
 * قائمة الأصناف المسجّلة.
 *
 * @return array
 */
function qafesheh_widget_classes() {
	return array(
		'Qafesheh_Widget_Hero_Slider',
		'Qafesheh_Widget_Section_Head',
		'Qafesheh_Widget_About',
		'Qafesheh_Widget_Caps_Split',
		'Qafesheh_Widget_Standards',
		'Qafesheh_Widget_Branches_Split',
		'Qafesheh_Widget_Companies',
		'Qafesheh_Widget_Services',
		'Qafesheh_Widget_Branches',
		'Qafesheh_Widget_Articles',
		'Qafesheh_Widget_Jobs',
		'Qafesheh_Widget_Stats',
		'Qafesheh_Widget_Caps',
		'Qafesheh_Widget_Contact',
		'Qafesheh_Widget_Cta',
	);
}

/**
 * الأساس المشترك لكل ودجات الموقع.
 */
abstract class Qafesheh_Widget_Base extends \Elementor\Widget_Base {

	/**
	 * التصنيف.
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'qafesheh' );
	}

	/**
	 * كلمات البحث.
	 *
	 * @return array
	 */
	public function get_keywords() {
		return array( 'qafesheh', 'قفيشة', 'qb' );
	}

	/**
	 * خيار عدد الأعمدة.
	 *
	 * @param string $default الافتراضي.
	 */
	protected function add_cols_control( $default = '3' ) {
		$this->add_control(
			'cols',
			array(
				'label'   => 'عدد الأعمدة',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => $default,
				'options' => array(
					'1' => 'عمود واحد',
					'2' => 'عمودان',
					'3' => 'ثلاثة أعمدة',
					'4' => 'أربعة أعمدة',
				),
			)
		);
	}

	/**
	 * ملاحظة إرشادية داخل الودجت.
	 *
	 * @param string $key  المفتاح.
	 * @param string $text النص.
	 */
	protected function add_note( $key, $text ) {
		$this->add_control(
			$key,
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => $text,
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);
	}

	/* ------------------------------------------------ نمط القسم (الشريط) */

	/**
	 * خلفية القسم الافتراضية لهذه الودجت.
	 *
	 * @return string
	 */
	protected function band_default() {
		return 'none';
	}

	/**
	 * كل ودجت تسجّل خياراتها هنا.
	 */
	abstract protected function register_widget_controls();

	/**
	 * كل ودجت ترسم محتواها هنا — الغلاف يتكفّل به الأساس.
	 */
	abstract protected function render_body();

	/**
	 * الخيارات: خيارات الودجت ثم نمط القسم.
	 */
	protected function register_controls() {
		$this->register_widget_controls();

		$this->start_controls_section(
			'qafesheh_band',
			array(
				'label' => 'نمط القسم',
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_note(
			'band_note',
			'هذه الخيارات تحافظ على شكل التصميم المعتمد: خلفية القسم وحدوده ومساحاته وعرض المحتوى. اتركها كما هي إلا لسببٍ واضح.'
		);

		$this->add_control(
			'band',
			array(
				'label'   => 'خلفية القسم',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => $this->band_default(),
				'options' => array(
					'none'   => 'بلا غلاف (داخل تخطيط خاص)',
					'paper'  => 'ورقي فاتح',
					'paper2' => 'ورقي ثانٍ',
					'ink'    => 'حبر داكن',
				),
			)
		);

		$this->add_control(
			'pad',
			array(
				'label'     => 'المساحة الرأسية',
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'normal',
				'options'   => array(
					'normal' => 'كاملة',
					'tight'  => 'مضغوطة',
					'none'   => 'بلا',
				),
				'condition' => array( 'band!' => 'none' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * فتح غلاف القسم.
	 */
	protected function band_open() {
		$settings = $this->get_settings_for_display();
		$band     = $settings['band'] ?? 'none';

		if ( 'none' === $band ) {
			return;
		}

		$classes = array( 'q-sec', 'q-sec--' . $band );
		$pad     = $settings['pad'] ?? 'normal';

		if ( 'tight' === $pad ) {
			$classes[] = 'q-sec--tight';
		} elseif ( 'none' === $pad ) {
			$classes[] = 'q-sec--flat';
		}

		printf( '<section class="%s"><div class="q-wrap">', esc_attr( implode( ' ', $classes ) ) );
	}

	/**
	 * إغلاق غلاف القسم.
	 */
	protected function band_close() {
		$settings = $this->get_settings_for_display();

		if ( 'none' === ( $settings['band'] ?? 'none' ) ) {
			return;
		}

		echo '</div></section>';
	}

	/**
	 * التصيير النهائي — غلاف موحّد حول محتوى كل ودجت.
	 */
	protected function render() {
		$this->band_open();
		$this->render_body();
		$this->band_close();
	}
}

/* ============================================================ رأس قسم */

/**
 * رأس قسم.
 */
class Qafesheh_Widget_Section_Head extends Qafesheh_Widget_Base {

	/**
	 * الاسم.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'qb_section_head';
	}

	/**
	 * العنوان.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'QB — رأس قسم';
	}

	/**
	 * الأيقونة.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-t-letter';
	}

	/**
	 * الخيارات.
	 */
	protected function register_widget_controls() {
		$this->start_controls_section( 'content', array( 'label' => 'المحتوى' ) );

		$this->add_control(
			'num',
			array(
				'label'       => 'رقم القسم',
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '٠١',
				'description' => 'يظهر داخل مربّع بإطار ذهبي. اتركه فارغاً لإخفائه.',
			)
		);

		$this->add_control(
			'label',
			array(
				'label'   => 'الكلمة اللاتينية بجانب الرقم',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'المجموعة',
			)
		);

		$this->add_control(
			'title',
			array(
				'label'   => 'العنوان',
				'type'    => \Elementor\Controls_Manager::TEXTAREA,
				'rows'    => 2,
				'default' => 'مجموعةٌ صناعية أردنية في الأزياء التراثية الفاخرة',
			)
		);

		$this->add_control(
			'text',
			array(
				'label'   => 'الفقرة',
				'type'    => \Elementor\Controls_Manager::TEXTAREA,
				'rows'    => 4,
				'default' => 'ثلاث علاماتٍ متخصصة، ومصنعٌ واحد في مدينة الملك عبدالله الثاني الصناعية بسحاب، يخدمان السوق المحلي وأسواق الخليج والوطن العربي.',
			)
		);

		$this->add_control(
			'link_txt',
			array(
				'label'       => 'رابط جانبي — النص',
				'type'        => \Elementor\Controls_Manager::TEXT,
				'description' => 'يظهر بدل الفقرة عندما تكون الفقرة فارغة.',
			)
		);

		$this->add_control(
			'link_url',
			array(
				'label' => 'رابط جانبي — الوجهة',
				'type'  => \Elementor\Controls_Manager::URL,
			)
		);

		$this->end_controls_section();
	}

	/**
	 * التصيير.
	 */
	protected function render_body() {
		$settings = $this->get_settings_for_display();

		qafesheh_render_section_head(
			array(
				'num'      => $settings['num'] ?? '',
				'label'    => $settings['label'] ?? '',
				'title'    => $settings['title'] ?? '',
				'text'     => $settings['text'] ?? '',
				'link_txt' => $settings['link_txt'] ?? '',
				'link_url' => $settings['link_url']['url'] ?? '',
			)
		);
	}
}

/* ============================================================ الشركات */

/**
 * شبكة الشركات.
 */
class Qafesheh_Widget_Companies extends Qafesheh_Widget_Base {

	/**
	 * الخلفية الافتراضية.
	 *
	 * @return string
	 */
	protected function band_default() {
		return 'ink';
	}

	/**
	 * الاسم.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'qb_companies';
	}

	/**
	 * العنوان.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'QB — شبكة الشركات';
	}

	/**
	 * الأيقونة.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	/**
	 * الخيارات.
	 */
	protected function register_widget_controls() {
		$this->start_controls_section( 'content', array( 'label' => 'العرض' ) );

		$this->add_note( 'note', 'البيانات تُسحب من قائمة <strong>الشركات</strong>. لتعديل اسم أو لون أو رابط متجر: الشركات ← كل الشركات.' );

		$this->add_cols_control( '3' );

		$this->add_control(
			'show_shop',
			array(
				'label'     => 'زر «زيارة المتجر»',
				'type'      => \Elementor\Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'label_on'  => 'ظاهر',
				'label_off' => 'مخفي',
			)
		);

		$this->add_control(
			'shop_txt',
			array(
				'label'     => 'نص الزر',
				'type'      => \Elementor\Controls_Manager::TEXT,
				'default'   => 'زيارة المتجر',
				'condition' => array( 'show_shop' => 'yes' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * التصيير.
	 */
	protected function render_body() {
		$settings = $this->get_settings_for_display();

		qafesheh_render_companies(
			array(
				'cols'      => $settings['cols'],
				'show_shop' => ( 'yes' === $settings['show_shop'] ),
				'shop_txt'  => $settings['shop_txt'],
			)
		);
	}
}

/* ============================================================ الخدمات */

/**
 * شبكة الخدمات.
 */
class Qafesheh_Widget_Services extends Qafesheh_Widget_Base {

	/**
	 * الخلفية الافتراضية.
	 *
	 * @return string
	 */
	protected function band_default() {
		return 'paper';
	}

	/**
	 * الاسم.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'qb_services';
	}

	/**
	 * العنوان.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'QB — الخدمات';
	}

	/**
	 * الأيقونة.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-settings';
	}

	/**
	 * الخيارات.
	 */
	protected function register_widget_controls() {
		$this->start_controls_section( 'content', array( 'label' => 'العرض' ) );

		$this->add_note( 'note', 'الخدمات تُدار من: <strong>الخدمات ← لوحة الخدمات</strong> — إضافة بسطر واحد وترتيب بالسحب.' );

		$this->add_cols_control( '3' );

		$this->add_control(
			'limit',
			array(
				'label'   => 'عدد الخدمات',
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 8,
				'min'     => 1,
				'max'     => 48,
			)
		);

		$this->add_control(
			'show_num',
			array(
				'label'   => 'إظهار رقم الخدمة',
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * التصيير.
	 */
	protected function render_body() {
		$settings = $this->get_settings_for_display();

		qafesheh_render_services(
			array(
				'cols'     => $settings['cols'],
				'limit'    => (int) $settings['limit'],
				'show_num' => ( 'yes' === $settings['show_num'] ),
			)
		);
	}
}

/* ============================================================ الفروع */

/**
 * بطاقات الفروع.
 */
class Qafesheh_Widget_Branches extends Qafesheh_Widget_Base {

	/**
	 * الخلفية الافتراضية.
	 *
	 * @return string
	 */
	protected function band_default() {
		return 'paper';
	}

	/**
	 * الاسم.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'qb_branches';
	}

	/**
	 * العنوان.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'QB — الفروع';
	}

	/**
	 * الأيقونة.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-map-pin';
	}

	/**
	 * الخيارات.
	 */
	protected function register_widget_controls() {
		$this->start_controls_section( 'content', array( 'label' => 'العرض' ) );

		$this->add_note( 'note', 'الفرع يُدخل <strong>مرة واحدة</strong> في قائمة الفروع، وتُحدَّد علاماته من صندوق «العلامة التجارية».' );

		$this->add_cols_control( '3' );

		$this->add_control(
			'show_filter',
			array(
				'label'   => 'فلتر العلامات',
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'brand',
			array(
				'label'       => 'اعرض علامة واحدة فقط',
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => '',
				'options'     => array(
					''         => 'كل الفروع',
					'qafesheh' => 'قفيشة',
					'aljazi'   => 'الجازي',
					'makarem'  => 'مكارم',
				),
				'description' => 'مفيد داخل الصفحة التعريفية لكل علامة.',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * التصيير.
	 */
	protected function render_body() {
		$settings = $this->get_settings_for_display();

		qafesheh_render_branches(
			array(
				'cols'        => $settings['cols'],
				'show_filter' => ( 'yes' === $settings['show_filter'] ),
				'brand'       => $settings['brand'],
			)
		);
	}
}

/* ============================================================ المقالات */

/**
 * شبكة المقالات.
 */
class Qafesheh_Widget_Articles extends Qafesheh_Widget_Base {

	/**
	 * الخلفية الافتراضية.
	 *
	 * @return string
	 */
	protected function band_default() {
		return 'paper';
	}

	/**
	 * الاسم.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'qb_articles';
	}

	/**
	 * العنوان.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'QB — المقالات';
	}

	/**
	 * الأيقونة.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * الخيارات.
	 */
	protected function register_widget_controls() {
		$this->start_controls_section( 'content', array( 'label' => 'العرض' ) );

		$this->add_control(
			'layout',
			array(
				'label'       => 'الشكل',
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'rows',
				'options'     => array(
					'rows'  => 'صفوف أفقية (كما في الرئيسية)',
					'cards' => 'بطاقات شبكية (كما في الأرشيف)',
				),
			)
		);

		$this->add_cols_control( '3' );

		$this->add_control(
			'limit',
			array(
				'label'   => 'عدد المقالات',
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 3,
				'min'     => 1,
				'max'     => 12,
			)
		);

		$this->end_controls_section();
	}

	/**
	 * التصيير.
	 */
	protected function render_body() {
		$settings = $this->get_settings_for_display();

		qafesheh_render_articles(
			array(
				'cols'   => $settings['cols'],
				'limit'  => (int) $settings['limit'],
				'layout' => $settings['layout'] ?? 'rows',
			)
		);
	}
}

/* ============================================================ الوظائف */

/**
 * قائمة الوظائف.
 */
class Qafesheh_Widget_Jobs extends Qafesheh_Widget_Base {

	/**
	 * الخلفية الافتراضية.
	 *
	 * @return string
	 */
	protected function band_default() {
		return 'paper';
	}

	/**
	 * الاسم.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'qb_jobs';
	}

	/**
	 * العنوان.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'QB — الوظائف';
	}

	/**
	 * الأيقونة.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-person';
	}

	/**
	 * الخيارات.
	 */
	protected function register_widget_controls() {
		$this->start_controls_section( 'content', array( 'label' => 'العرض' ) );

		$this->add_note( 'note', 'الشواغر من قائمة <strong>الوظائف</strong>. الوظيفة المنتهية اجعلها «مسودة» بدل حذفها.' );

		$this->add_cols_control( '2' );

		$this->add_control(
			'limit',
			array(
				'label'   => 'عدد الوظائف (-1 = الكل)',
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => -1,
			)
		);

		$this->end_controls_section();
	}

	/**
	 * التصيير.
	 */
	protected function render_body() {
		$settings = $this->get_settings_for_display();

		qafesheh_render_jobs(
			array(
				'cols'  => $settings['cols'],
				'limit' => (int) $settings['limit'],
			)
		);
	}
}

/* ============================================================ الأرقام */

/**
 * منصّة الأرقام.
 */
class Qafesheh_Widget_Stats extends Qafesheh_Widget_Base {

	/**
	 * الاسم.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'qb_stats';
	}

	/**
	 * العنوان.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'QB — الأرقام';
	}

	/**
	 * الأيقونة.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-counter';
	}

	/**
	 * الخيارات.
	 */
	protected function register_widget_controls() {
		$this->start_controls_section( 'content', array( 'label' => 'الأرقام' ) );
		$this->add_note( 'note', 'الأرقام الأربعة تُعدَّل من: <strong>مجموعة قفيشة ← إعدادات الموقع ← الرئيسية ← منصّة الأرقام</strong>، فتتغيّر في كل مكان دفعةً واحدة.' );
		$this->end_controls_section();
	}

	/**
	 * التصيير.
	 */
	protected function render_body() {
		qafesheh_render_stats();
	}
}

/* ============================================================ القدرات */

/**
 * جدول القدرات التصنيعية.
 */
class Qafesheh_Widget_Caps extends Qafesheh_Widget_Base {

	/**
	 * الخلفية الافتراضية.
	 *
	 * @return string
	 */
	protected function band_default() {
		return 'paper2';
	}

	/**
	 * الاسم.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'qb_caps';
	}

	/**
	 * العنوان.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'QB — جدول القدرات';
	}

	/**
	 * الأيقونة.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-table';
	}

	/**
	 * الخيارات.
	 */
	protected function register_widget_controls() {
		$this->start_controls_section( 'content', array( 'label' => 'المحتوى' ) );

		$this->add_note( 'note', 'الصفوف الخمسة تُعدَّل من: <strong>إعدادات الموقع ← الرئيسية ← القدرات التصنيعية</strong>.' );

		$this->add_control(
			'title',
			array(
				'label'   => 'العنوان',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'مصنعٌ واحد يخدم العلامات الثلاث',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * التصيير.
	 */
	protected function render_body() {
		$settings = $this->get_settings_for_display();
		qafesheh_render_capabilities( array( 'title' => $settings['title'] ) );
	}
}

/* ============================================================ التواصل */

/**
 * بطاقات التواصل.
 */
class Qafesheh_Widget_Contact extends Qafesheh_Widget_Base {

	/**
	 * الخلفية الافتراضية.
	 *
	 * @return string
	 */
	protected function band_default() {
		return 'paper';
	}

	/**
	 * الاسم.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'qb_contact';
	}

	/**
	 * العنوان.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'QB — بطاقات التواصل';
	}

	/**
	 * الأيقونة.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-envelope';
	}

	/**
	 * الخيارات.
	 */
	protected function register_widget_controls() {
		$this->start_controls_section( 'content', array( 'label' => 'المحتوى' ) );
		$this->add_note( 'note', 'العنوان والهاتف والبريد والدوام تُقرأ تلقائياً من: <strong>إعدادات الموقع ← التواصل</strong>. لا تكتبها يدوياً في الصفحة.' );
		$this->end_controls_section();
	}

	/**
	 * التصيير.
	 */
	protected function render_body() {
		qafesheh_render_contact_cards();
	}
}

/* ============================================================ دعوة تواصل */

/**
 * دعوة التواصل.
 */
class Qafesheh_Widget_Cta extends Qafesheh_Widget_Base {

	/**
	 * الاسم.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'qb_cta';
	}

	/**
	 * العنوان.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'QB — دعوة تواصل';
	}

	/**
	 * الأيقونة.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-call-to-action';
	}

	/**
	 * الخيارات.
	 */
	protected function register_widget_controls() {
		$this->start_controls_section( 'content', array( 'label' => 'المحتوى' ) );

		$this->add_control(
			'title',
			array(
				'label'   => 'العنوان',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'للاستفسارات التجارية وطلبات الجملة والتصدير',
			)
		);

		$this->add_control(
			'text',
			array(
				'label'   => 'النص',
				'type'    => \Elementor\Controls_Manager::TEXTAREA,
				'rows'    => 3,
				'default' => 'فريق المجموعة يستقبل طلبات الشراكة والتوريد على مدار العام.',
			)
		);

		$this->add_control(
			'b1_t',
			array(
				'label'   => 'الزر الأول — النص',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'تواصل معنا',
			)
		);

		$this->add_control(
			'b1_u',
			array(
				'label'       => 'الزر الأول — الرابط',
				'type'        => \Elementor\Controls_Manager::URL,
				'default'     => array( 'url' => '/contact/' ),
			)
		);

		$this->add_control(
			'b2_t',
			array(
				'label'   => 'الزر الثاني — النص',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'الوظائف',
			)
		);

		$this->add_control(
			'b2_u',
			array(
				'label'   => 'الزر الثاني — الرابط',
				'type'    => \Elementor\Controls_Manager::URL,
				'default' => array( 'url' => '/careers/' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * التصيير.
	 */
	protected function render_body() {
		$settings = $this->get_settings_for_display();

		qafesheh_render_cta(
			array(
				'title' => $settings['title'],
				'text'  => $settings['text'],
				'b1_t'  => $settings['b1_t'],
				'b1_u'  => $settings['b1_u']['url'] ?? '',
				'b2_t'  => $settings['b2_t'],
				'b2_u'  => $settings['b2_u']['url'] ?? '',
			)
		);
	}
}

/* ============================================================ سلايدر الهيرو */

/**
 * سلايدر الهيرو.
 */
class Qafesheh_Widget_Hero_Slider extends Qafesheh_Widget_Base {

	/**
	 * الاسم.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'qb_hero_slider';
	}

	/**
	 * العنوان.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'QB — سلايدر الهيرو';
	}

	/**
	 * الأيقونة.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-slider-push';
	}

	/**
	 * الخيارات.
	 */
	protected function register_widget_controls() {

		$this->start_controls_section( 'content', array( 'label' => 'الشرائح' ) );

		$this->add_note(
			'note',
			'أول شريحة هي عنصر LCP — ارفع لها صورة بعرض ٢٥٦٠px ولا تفعّل لها lazy load. الصور تُقصّ تلقائياً على مقاس الهيرو.'
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image',
			array(
				'label' => 'صورة الخلفية',
				'type'  => \Elementor\Controls_Manager::MEDIA,
			)
		);

		$repeater->add_control(
			'eyebrow',
			array(
				'label'   => 'السطر العلوي (لاتيني)',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'EST. 1968 — SAHAB, JORDAN',
			)
		);

		$repeater->add_control(
			'title',
			array(
				'label'       => 'العنوان',
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'rows'        => 3,
				'description' => 'كل سطر في سطرٍ منفصل — كل سطر يُكشف على حدة في الحركة.',
				'default'     => "مجموعةٌ صناعية أردنية\nفي الأزياء التراثية الفاخرة",
			)
		);

		$repeater->add_control(
			'text',
			array(
				'label'   => 'النص',
				'type'    => \Elementor\Controls_Manager::TEXTAREA,
				'rows'    => 4,
				'default' => 'ثلاث علاماتٍ متخصصة، ومصنعٌ واحد في مدينة الملك عبدالله الثاني الصناعية بسحاب، يخدمان السوق المحلي وأسواق الخليج والوطن العربي.',
			)
		);

		$repeater->add_control(
			'b1',
			array(
				'label'   => 'الزر الأول — النص',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'شركات المجموعة',
			)
		);

		$repeater->add_control(
			'b1_url',
			array(
				'label'   => 'الزر الأول — الرابط',
				'type'    => \Elementor\Controls_Manager::URL,
				'default' => array( 'url' => '/companies/' ),
			)
		);

		$repeater->add_control(
			'b2',
			array(
				'label'   => 'الزر الثاني — النص',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'نبذة عن المجموعة',
			)
		);

		$repeater->add_control(
			'b2_url',
			array(
				'label'   => 'الزر الثاني — الرابط',
				'type'    => \Elementor\Controls_Manager::URL,
				'default' => array( 'url' => '/about/' ),
			)
		);

		$defaults = array();
		foreach ( qafesheh_data_slides() as $slide ) {
			$defaults[] = array(
				'eyebrow' => $slide['eyebrow'],
				'title'   => $slide['title'],
				'text'    => $slide['text'],
				'b1'      => $slide['b1'],
				'b1_url'  => array( 'url' => $slide['b1_url'] ),
				'b2'      => $slide['b2'],
				'b2_url'  => array( 'url' => $slide['b2_url'] ),
			);
		}

		$this->add_control(
			'slides',
			array(
				'label'       => 'الشرائح',
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => $defaults,
				'title_field' => '{{{ title.split("\n")[0] }}}',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section( 'behaviour', array( 'label' => 'السلوك' ) );

		$this->add_control(
			'autoplay',
			array(
				'label'       => 'التبديل التلقائي (بالمللي ثانية)',
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'default'     => 6500,
				'min'         => 0,
				'max'         => 20000,
				'step'        => 250,
				'description' => 'صفر = بلا تبديل تلقائي. يتوقّف تلقائياً عند مرور المؤشر أو إخفاء التبويب.',
			)
		);

		$this->add_control(
			'arrows',
			array(
				'label'   => 'أسهم التنقّل',
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'dots',
			array(
				'label'   => 'مؤشرات الشرائح',
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * التصيير.
	 */
	protected function render_body() {
		$settings = $this->get_settings_for_display();
		$slides   = array();

		foreach ( (array) ( $settings['slides'] ?? array() ) as $slide ) {
			$slides[] = array(
				'image'   => absint( $slide['image']['id'] ?? 0 ),
				'eyebrow' => $slide['eyebrow'] ?? '',
				'title'   => $slide['title'] ?? '',
				'text'    => $slide['text'] ?? '',
				'b1'      => $slide['b1'] ?? '',
				'b1_url'  => $slide['b1_url']['url'] ?? '',
				'b2'      => $slide['b2'] ?? '',
				'b2_url'  => $slide['b2_url']['url'] ?? '',
			);
		}

		qafesheh_render_hero_slider(
			array(
				'slides'   => $slides,
				'autoplay' => (int) ( $settings['autoplay'] ?? 6500 ),
				'arrows'   => ( 'yes' === ( $settings['arrows'] ?? 'yes' ) ),
				'dots'     => ( 'yes' === ( $settings['dots'] ?? 'yes' ) ),
			)
		);
	}
}

/* ============================================================ نبذة المجموعة */

/**
 * قسم نبذة المجموعة (٠١).
 */
class Qafesheh_Widget_About extends Qafesheh_Widget_Base {

	/**
	 * الاسم.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'qb_about';
	}

	/**
	 * العنوان.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'QB — نبذة المجموعة';
	}

	/**
	 * الأيقونة.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-text-align-justify';
	}

	/**
	 * الخلفية الافتراضية.
	 *
	 * @return string
	 */
	protected function band_default() {
		return 'paper';
	}

	/**
	 * الخيارات.
	 */
	protected function register_widget_controls() {
		$this->start_controls_section( 'content', array( 'label' => 'المحتوى' ) );

		$this->add_note(
			'note',
			'العنوان والفقرتان تُقرأ من: <strong>إعدادات الموقع ← الرئيسية ← قسم المجموعة</strong> — فتتغيّر في كل مكان دفعةً واحدة.'
		);

		$this->add_control(
			'num',
			array(
				'label'   => 'رقم القسم',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => '٠١',
			)
		);

		$this->add_control(
			'label',
			array(
				'label'   => 'الكلمة اللاتينية',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'المجموعة',
			)
		);

		$this->add_control(
			'btn',
			array(
				'label'   => 'نص زر «نبذة كاملة»',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'نبذة كاملة عن المجموعة',
			)
		);

		$this->add_control(
			'link',
			array(
				'label'       => 'رابط الزر',
				'type'        => \Elementor\Controls_Manager::URL,
				'default'     => array( 'url' => '/about/' ),
				'description' => 'اتركه فارغاً لإخفاء الزر.',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * التصيير.
	 */
	protected function render_body() {
		$settings = $this->get_settings_for_display();

		qafesheh_render_about(
			array(
				'num'   => $settings['num'] ?? '٠١',
				'label' => $settings['label'] ?? '',
				'btn'   => $settings['btn'] ?? '',
				'link'  => $settings['link']['url'] ?? '',
			)
		);
	}
}

/* ============================================================ القدرات بعمودين */

/**
 * قسم القدرات التصنيعية بعمودين.
 */
class Qafesheh_Widget_Caps_Split extends Qafesheh_Widget_Base {

	/**
	 * الاسم.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'qb_caps_split';
	}

	/**
	 * العنوان.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'QB — القدرات التصنيعية';
	}

	/**
	 * الأيقونة.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-image-box';
	}

	/**
	 * الخلفية الافتراضية.
	 *
	 * @return string
	 */
	protected function band_default() {
		return 'paper2';
	}

	/**
	 * الخيارات.
	 */
	protected function register_widget_controls() {
		$this->start_controls_section( 'content', array( 'label' => 'المحتوى' ) );

		$this->add_note(
			'note',
			'الصفوف الخمسة والعنوان من: <strong>إعدادات الموقع ← الرئيسية ← القدرات التصنيعية</strong>.'
		);

		$this->add_control(
			'num',
			array(
				'label'   => 'رقم القسم',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => '٠٣',
			)
		);

		$this->add_control(
			'label',
			array(
				'label'   => 'الكلمة اللاتينية',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'القدرات التصنيعية',
			)
		);

		$this->add_control(
			'image',
			array(
				'label'       => 'صورة القسم',
				'type'        => \Elementor\Controls_Manager::MEDIA,
				'description' => 'اتركها فارغة لاستخدام الصورة المحفوظة في إعدادات الموقع.',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * التصيير.
	 */
	protected function render_body() {
		$settings = $this->get_settings_for_display();
		$image    = absint( $settings['image']['id'] ?? 0 );

		qafesheh_render_caps_split(
			array(
				'num'   => $settings['num'] ?? '٠٣',
				'label' => $settings['label'] ?? '',
				'image' => $image ? $image : absint( qafesheh_opt( 'cap_image', 0 ) ),
			)
		);
	}
}

/* ============================================================ المعايير */

/**
 * صفوف المعايير.
 */
class Qafesheh_Widget_Standards extends Qafesheh_Widget_Base {

	/**
	 * الخلفية الافتراضية.
	 *
	 * @return string
	 */
	protected function band_default() {
		return 'ink';
	}

	/**
	 * الاسم.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'qb_standards';
	}

	/**
	 * العنوان.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'QB — المعايير';
	}

	/**
	 * الأيقونة.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-bullet-list';
	}

	/**
	 * الخيارات.
	 */
	protected function register_widget_controls() {
		$this->start_controls_section( 'content', array( 'label' => 'المحتوى' ) );

		$this->add_control(
			'num',
			array(
				'label'   => 'رقم القسم',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => '٠٥',
			)
		);

		$this->add_control(
			'label',
			array(
				'label'   => 'التسمية',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'المعايير',
			)
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title',
			array(
				'label'   => 'العنوان',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'الجودة قبل الكمّ',
			)
		);

		$repeater->add_control(
			'text',
			array(
				'label'   => 'النص',
				'type'    => \Elementor\Controls_Manager::TEXTAREA,
				'rows'    => 3,
				'default' => '',
			)
		);

		$defaults = array();
		foreach ( qafesheh_data_standards() as $row ) {
			$defaults[] = array(
				'title' => $row['title'],
				'text'  => $row['text'],
			);
		}

		$this->add_control(
			'rows',
			array(
				'label'       => 'الصفوف',
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => $defaults,
				'title_field' => '{{{ title }}}',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * التصيير.
	 */
	protected function render_body() {
		$settings = $this->get_settings_for_display();
		$rows     = array();

		foreach ( (array) ( $settings['rows'] ?? array() ) as $row ) {
			$rows[] = array(
				'title' => $row['title'] ?? '',
				'text'  => $row['text'] ?? '',
			);
		}
		?>
		<div class="q-lay">
			<?php qafesheh_rail( $settings['num'] ?? '٠٥', $settings['label'] ?? '' ); ?>
			<div class="q-lay__body"><?php qafesheh_render_standards( array( 'rows' => $rows ) ); ?></div>
		</div>
		<?php
	}
}

/* ============================================================ الفروع بنصفين */

/**
 * الفروع: نص وخريطة.
 */
class Qafesheh_Widget_Branches_Split extends Qafesheh_Widget_Base {

	/**
	 * الاسم.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'qb_branches_split';
	}

	/**
	 * العنوان.
	 *
	 * @return string
	 */
	public function get_title() {
		return 'QB — الفروع (نصفان)';
	}

	/**
	 * الأيقونة.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-image-before-after';
	}

	/**
	 * الخيارات.
	 */
	protected function register_widget_controls() {
		$this->start_controls_section( 'content', array( 'label' => 'المحتوى' ) );

		$this->add_note( 'note', 'الفروع من قائمة <strong>الفروع</strong>. هذا القسم يعرض أقصرها ويقود إلى الأرشيف.' );

		$this->add_control(
			'num',
			array(
				'label'   => 'رقم القسم',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => '٠٧',
			)
		);

		$this->add_control(
			'label',
			array(
				'label'   => 'التسمية',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'الفروع',
			)
		);

		$this->add_control(
			'title',
			array(
				'label'       => 'العنوان',
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'rows'        => 2,
				'default'     => "سبعةُ معارضَ\nومصنعٌ واحد",
				'description' => 'كل سطر في سطرٍ منفصل.',
			)
		);

		$this->add_control(
			'limit',
			array(
				'label'   => 'عدد الفروع المعروضة',
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 5,
				'min'     => 2,
				'max'     => 12,
			)
		);

		$this->add_control(
			'image',
			array(
				'label' => 'الصورة الجانبية',
				'type'  => \Elementor\Controls_Manager::MEDIA,
			)
		);

		$this->end_controls_section();
	}

	/**
	 * التصيير.
	 */
	protected function render_body() {
		$settings = $this->get_settings_for_display();

		qafesheh_render_branches_split(
			array(
				'num'   => $settings['num'] ?? '٠٧',
				'label' => $settings['label'] ?? '',
				'title' => $settings['title'] ?? '',
				'limit' => (int) ( $settings['limit'] ?? 5 ),
				'image' => absint( $settings['image']['id'] ?? 0 ),
			)
		);
	}
}
