<?php
/**
 * ودجات Elementor الخاصة بالموقع — كلها تبدأ بـ«QB —» في لوحة الودجات.
 * كل ودجت تُصيَّر عبر نفس دوال inc/renderers.php المستخدمة في القوالب،
 * وقيمها الافتراضية هي بيانات المجموعة الحقيقية لا نصوص وهمية.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * تصنيف خاص بالودجات.
 *
 * @param object $manager مدير التصنيفات.
 */
function qafesheh_elementor_category( $manager ) {
	$manager->add_category(
		'qafesheh',
		array(
			'title' => 'مجموعة قفيشة',
			'icon'  => 'eicon-woocommerce',
		)
	);
}
add_action( 'elementor/elements/categories_registered', 'qafesheh_elementor_category' );

/**
 * تحميل وتسجيل الودجات.
 *
 * @param object $widgets مسجّل الودجات.
 */
function qafesheh_register_elementor_widgets( $widgets ) {
	require_once QAFESHEH_DIR . 'inc/elementor/widgets.php';

	foreach ( qafesheh_widget_classes() as $class ) {
		if ( class_exists( $class ) ) {
			$widgets->register( new $class() );
		}
	}
}
add_action( 'elementor/widgets/register', 'qafesheh_register_elementor_widgets' );

/**
 * تفعيل Elementor على أنواع المحتوى الخاصة بنا.
 *
 * @param array $types الأنواع.
 * @return array
 */
function qafesheh_elementor_cpt_support( $types ) {
	$ours = array( 'qaf_company', 'qaf_service', 'qaf_branch', 'qaf_job' );
	return array_values( array_unique( array_merge( (array) $types, $ours ) ) );
}
add_filter( 'elementor/utils/get_public_post_types', 'qafesheh_elementor_cpt_support' );
