<?php
/**
 * تخطيط الصفحة الرئيسية بـElementor.
 *
 * كل قسم = سكشن بعرض كامل بلا حشوات، وبداخله ودجت QB واحدة تحمل غلافها
 * الخاص (خلفية القسم ومساحاته وعرض المحتوى) — فيبقى التصميم المعتمد
 * محفوظاً حتى لو عبث أحدهم بإعدادات السكشن.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * مُعرّف عشوائي بصيغة Elementor.
 *
 * @return string
 */
function qafesheh_el_id() {
	return substr( md5( uniqid( (string) wp_rand(), true ) ), 0, 7 );
}

/**
 * سكشن بعرض كامل يحوي ودجت واحدة.
 *
 * @param array $widget تعريف الودجت.
 * @param array $extra  إعدادات إضافية للسكشن.
 * @return array
 */
function qafesheh_el_section( $widget, $extra = array() ) {
	$zero = array(
		'unit'     => 'px',
		'top'      => '0',
		'right'    => '0',
		'bottom'   => '0',
		'left'     => '0',
		'isLinked' => true,
	);

	$settings = array_merge(
		array(
			'layout'         => 'full_width',
			'gap'            => 'no',
			'content_width'  => array(
				'unit' => 'px',
				'size' => '',
			),
			'padding'        => $zero,
			'margin'         => $zero,
			'structure'      => '10',
		),
		$extra
	);

	return array(
		'id'       => qafesheh_el_id(),
		'elType'   => 'section',
		'settings' => $settings,
		'elements' => array(
			array(
				'id'       => qafesheh_el_id(),
				'elType'   => 'column',
				'settings' => array(
					'_column_size' => 100,
					'_inline_size' => null,
					'padding'      => $zero,
					'margin'       => $zero,
				),
				'elements' => array( $widget ),
			),
		),
		'isInner'  => false,
	);
}

/**
 * ودجت QB.
 *
 * @param string $type     اسم الودجت.
 * @param array  $settings الإعدادات.
 * @return array
 */
function qafesheh_el_widget( $type, $settings = array() ) {
	return array(
		'id'         => qafesheh_el_id(),
		'elType'     => 'widget',
		'widgetType' => $type,
		'settings'   => $settings,
		'elements'   => array(),
	);
}

/**
 * بيانات الصفحة الرئيسية الكاملة لـElementor.
 *
 * @return array
 */
function qafesheh_elementor_home_layout() {

	/* ------------------------------------------------ الشرائح */

	$map    = qafesheh_data_media_map();
	$slides = array();

	foreach ( array_values( qafesheh_data_slides() ) as $i => $slide ) {

		/* صورة الشريحة من الصور المرفوعة، إن وُجدت */
		$image_id  = 0;
		$image_url = '';

		if ( function_exists( 'qafesheh_demo_image_id' ) && isset( $map['slides'][ $i ] ) ) {
			$image_id = qafesheh_demo_image_id( $map['slides'][ $i ] );
			if ( $image_id ) {
				$src       = wp_get_attachment_image_src( $image_id, 'qafesheh_hero' );
				$image_url = $src ? $src[0] : '';
			}
		}

		$slides[] = array(
			'_id'     => qafesheh_el_id(),
			'image'   => array(
				'url' => $image_url,
				'id'  => $image_id ? $image_id : '',
			),
			'eyebrow' => $slide['eyebrow'],
			'title'   => $slide['title'],
			'text'    => $slide['text'],
			'b1'      => $slide['b1'],
			'b1_url'  => array(
				'url'         => home_url( $slide['b1_url'] ),
				'is_external' => '',
				'nofollow'    => '',
			),
			'b2'      => $slide['b2'],
			'b2_url'  => array(
				'url'         => home_url( $slide['b2_url'] ),
				'is_external' => '',
				'nofollow'    => '',
			),
		);
	}

	/* صورة قسم الفروع */
	$branch_img = 0;
	$branch_url = '';

	if ( function_exists( 'qafesheh_demo_image_id' ) && ! empty( $map['branches'] ) ) {
		$branch_img = qafesheh_demo_image_id( $map['branches'] );
		if ( $branch_img ) {
			$src        = wp_get_attachment_image_src( $branch_img, 'qafesheh_card' );
			$branch_url = $src ? $src[0] : '';
		}
	}

	$sections = array();

	/* الهيرو + منصّة الأرقام داخله */
	$sections[] = qafesheh_el_section(
		qafesheh_el_widget(
			'qb_hero_slider',
			array(
				'slides'   => $slides,
				'autoplay' => 6500,
				'arrows'   => 'yes',
				'dots'     => 'yes',
				'band'     => 'none',
			)
		)
	);

	/* ٠١ — بيان المجموعة */
	$sections[] = qafesheh_el_section(
		qafesheh_el_widget(
			'qb_about',
			array(
				'num'   => '٠١',
				'label' => 'المجموعة',
				'btn'   => 'نبذة كاملة عن المجموعة',
				'link'  => array( 'url' => home_url( '/about/' ) ),
				'band'  => 'paper',
				'pad'   => 'normal',
			)
		)
	);

	/* ٠٢ — قطاعات الأعمال */
	$sections[] = qafesheh_el_section(
		qafesheh_el_widget(
			'qb_section_head',
			array(
				'num'   => '٠٢',
				'label' => 'قطاعات الأعمال',
				'title' => 'ثلاث علاماتٍ متخصصة',
				'text'  => 'كل علامةٍ تخدم قطاعها الخاص، وتشترك مع المجموعة في المصنع والخامة ومعايير الجودة.',
				'band'  => 'ink',
				'pad'   => 'normal',
			)
		),
		array( 'css_classes' => 'q-sec-merge-down' )
	);

	$sections[] = qafesheh_el_section(
		qafesheh_el_widget(
			'qb_companies',
			array(
				'cols'      => '3',
				'show_shop' => 'yes',
				'shop_txt'  => 'زيارة المتجر',
				'band'      => 'ink',
				'pad'       => 'none',
			)
		),
		array( 'css_classes' => 'q-sec-merge-up' )
	);

	/* ٠٣ — القدرات التصنيعية */
	$sections[] = qafesheh_el_section(
		qafesheh_el_widget(
			'qb_caps_split',
			array(
				'num'   => '٠٣',
				'label' => 'القدرات التصنيعية',
				'band'  => 'paper2',
				'pad'   => 'normal',
			)
		)
	);

	/* ٠٤ — الخدمات */
	$sections[] = qafesheh_el_section(
		qafesheh_el_widget(
			'qb_section_head',
			array(
				'num'      => '٠٤',
				'label'    => 'الخدمات',
				'title'    => 'ما نقدّمه للتجّار والأفراد',
				'text'     => '',
				'link_txt' => 'كل الخدمات',
				'link_url' => array( 'url' => home_url( '/services/' ) ),
				'band'     => 'paper',
				'pad'      => 'normal',
			)
		),
		array( 'css_classes' => 'q-sec-merge-down' )
	);

	$sections[] = qafesheh_el_section(
		qafesheh_el_widget(
			'qb_services',
			array(
				'cols'     => '3',
				'limit'    => 6,
				'show_num' => 'yes',
				'band'     => 'paper',
				'pad'      => 'none',
			)
		),
		array( 'css_classes' => 'q-sec-merge-up' )
	);

	/* ٠٥ — المعايير */
	$sections[] = qafesheh_el_section(
		qafesheh_el_widget(
			'qb_standards',
			array(
				'num'   => '٠٥',
				'label' => 'المعايير',
				'band'  => 'ink',
				'pad'   => 'normal',
			)
		)
	);

	/* ٠٦ — المقالات */
	$sections[] = qafesheh_el_section(
		qafesheh_el_widget(
			'qb_section_head',
			array(
				'num'      => '٠٦',
				'label'    => 'المقالات والأخبار',
				'title'    => 'آخر ما نشرناه',
				'text'     => '',
				'link_txt' => 'الأرشيف',
				'link_url' => array( 'url' => home_url( '/blog/' ) ),
				'band'     => 'paper',
				'pad'      => 'normal',
			)
		),
		array( 'css_classes' => 'q-sec-merge-down' )
	);

	$sections[] = qafesheh_el_section(
		qafesheh_el_widget(
			'qb_articles',
			array(
				'layout' => 'rows',
				'cols'   => '3',
				'limit'  => 3,
				'band'   => 'paper',
				'pad'    => 'none',
			)
		),
		array( 'css_classes' => 'q-sec-merge-up' )
	);

	/* ٠٧ — الفروع */
	$sections[] = qafesheh_el_section(
		qafesheh_el_widget(
			'qb_branches_split',
			array(
				'num'   => '٠٧',
				'label' => 'الفروع',
				'title' => "سبعةُ معارضَ\nومصنعٌ واحد",
				'limit' => 5,
				'image' => array( 'id' => $branch_img ? $branch_img : '', 'url' => $branch_url ),
				'band'  => 'none',
			)
		)
	);

	/* دعوة التواصل */
	$sections[] = qafesheh_el_section(
		qafesheh_el_widget(
			'qb_cta',
			array(
				'title' => qafesheh_opt( 'cta_title', 'للاستفسارات التجارية وطلبات الجملة والتصدير' ),
				'text'  => qafesheh_opt( 'cta_text', 'فريق المجموعة يستقبل طلبات الشراكة والتوريد على مدار العام.' ),
				'b1_t'  => 'تواصل معنا',
				'b1_u'  => array( 'url' => home_url( '/contact/' ) ),
				'b2_t'  => 'الوظائف',
				'b2_u'  => array( 'url' => home_url( '/careers/' ) ),
				'band'  => 'none',
			)
		)
	);

	return $sections;
}
