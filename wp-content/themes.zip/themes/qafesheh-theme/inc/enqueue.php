<?php
/**
 * تحميل الأصول: ملف أساسي واحد + ملفات مشروطة حسب نوع الصفحة.
 * الإصدار من filemtime دائماً — لا كاش قديم بعد أي تعديل.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * تسجيل ملف CSS إن كان موجوداً فعلاً.
 *
 * @param string $handle المعرّف.
 * @param string $rel    مسار نسبي.
 * @param array  $deps   اعتماديات.
 */
function qafesheh_style( $handle, $rel, $deps = array() ) {
	if ( ! file_exists( QAFESHEH_DIR . $rel ) ) {
		return;
	}
	wp_enqueue_style( $handle, qafesheh_url( $rel ), $deps, qafesheh_asset_ver( $rel ) );
}

/**
 * تسجيل ملف JS إن كان موجوداً فعلاً.
 *
 * @param string $handle المعرّف.
 * @param string $rel    مسار نسبي.
 * @param array  $deps   اعتماديات.
 */
function qafesheh_script( $handle, $rel, $deps = array() ) {
	if ( ! file_exists( QAFESHEH_DIR . $rel ) ) {
		return;
	}
	wp_enqueue_script(
		$handle,
		qafesheh_url( $rel ),
		$deps,
		qafesheh_asset_ver( $rel ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
}

/**
 * أصول الواجهة.
 */
function qafesheh_enqueue_front() {
	/* لا نستخدم base-rtl.css — الاتجاه مُدار بالخصائص المنطقية داخل base.css نفسه */
	qafesheh_style( 'qafesheh-base', 'assets/css/base.css' );

	/* تُحمَّل دائماً — إطفاء الحركة يتم بكلاس q-no-motion على الجسم لا بمنع الملف،
	   حتى لا يختفي نظام الحركة كله بسبب خيار واحد. */
	qafesheh_style( 'qafesheh-motion', 'assets/css/motion.css', array( 'qafesheh-base' ) );

	if ( is_front_page() ) {
		qafesheh_style( 'qafesheh-home', 'assets/css/home.css', array( 'qafesheh-base' ) );
	} else {
		qafesheh_style( 'qafesheh-inner', 'assets/css/inner.css', array( 'qafesheh-base' ) );
	}

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	qafesheh_script( 'qafesheh-app', 'assets/js/app.js' );
	qafesheh_script( 'qafesheh-motion', 'assets/js/motion.js' );

	/* السلايدر والستايل الخاص به يُحمَّلان فقط حيث توجد ودجت السلايدر */
	wp_register_style( 'qafesheh-slider', qafesheh_url( 'assets/css/slider.css' ), array( 'qafesheh-base' ), qafesheh_asset_ver( 'assets/css/slider.css' ) );
	wp_register_script( 'qafesheh-slider', qafesheh_url( 'assets/js/slider.js' ), array(), qafesheh_asset_ver( 'assets/js/slider.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );

	if ( qafesheh_needs_slider() ) {
		wp_enqueue_style( 'qafesheh-slider' );
		wp_enqueue_script( 'qafesheh-slider' );
	}

	wp_localize_script(
		'qafesheh-app',
		'QAFESHEH',
		array(
			'ajax'       => admin_url( 'admin-ajax.php' ),
			'nonce'      => wp_create_nonce( 'qafesheh_front' ),
			'motion'     => (int) qafesheh_opt( 'motion_on', 1 ),
			'lazyOffset' => (int) qafesheh_opt( 'lazy_offset', 200 ),
			'rtl'        => is_rtl() ? 1 : 0,
			'i18n'       => array(
				'loading' => __( 'جارٍ التحميل…', 'qafesheh' ),
				'more'    => __( 'عرض المزيد', 'qafesheh' ),
				'end'     => __( 'لا يوجد المزيد', 'qafesheh' ),
				'error'   => __( 'حدث خطأ، حاول مجدداً.', 'qafesheh' ),
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'qafesheh_enqueue_front' );

/**
 * علم الجافاسكربت — يُطبع قبل أي ستايل.
 * كل إخفاء في motion.css مشروط بهذا الكلاس، فإن تعطّل الجافاسكربت
 * لأي سبب يظهر المحتوى كاملاً بدل أن تبقى الأقسام فارغة.
 */
function qafesheh_js_flag() {
	echo '<script>document.documentElement.className+=" q-js";</script>' . "\n";
}
add_action( 'wp_head', 'qafesheh_js_flag', 0 );

/**
 * Preload لصورة الهيرو — أهم عنصر في LCP.
 */
function qafesheh_preload_hero() {
	if ( ! is_front_page() || ! qafesheh_opt( 'preload_hero', 1 ) ) {
		return;
	}

	$hero = qafesheh_opt_image( 'hero_image', 'qafesheh_hero' );
	if ( empty( $hero['url'] ) ) {
		return;
	}

	printf(
		'<link rel="preload" as="image" href="%s" fetchpriority="high">' . "\n",
		esc_url( $hero['url'] )
	);
}
add_action( 'wp_head', 'qafesheh_preload_hero', 3 );

/**
 * أكواد المتابعة من تاب «متقدّم».
 */
function qafesheh_head_code() {
	$code = qafesheh_opt( 'head_code', '' );
	if ( $code ) {
		echo $code . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}
add_action( 'wp_head', 'qafesheh_head_code', 99 );

/**
 * كود بعد فتح body.
 */
function qafesheh_body_code() {
	$code = qafesheh_opt( 'body_code', '' );
	if ( $code ) {
		echo $code . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}
add_action( 'wp_body_open', 'qafesheh_body_code', 1 );

/**
 * كلاسات جسم الصفحة التي يعتمد عليها الستايل.
 *
 * @param array $classes الكلاسات.
 * @return array
 */
function qafesheh_body_class( $classes ) {
	$classes[] = 'q-body';

	if ( qafesheh_opt( 'header_sticky', 1 ) ) {
		$classes[] = 'q-sticky-header';
	}
	if ( ! qafesheh_opt( 'motion_on', 1 ) ) {
		$classes[] = 'q-no-motion';
	}
	if ( is_front_page() ) {
		$classes[] = 'q-home';
	}

	return $classes;
}
add_filter( 'body_class', 'qafesheh_body_class' );

/**
 * ستايل محرر Elementor يرث نفس التوكنز.
 */
function qafesheh_elementor_tokens() {
	if ( ! did_action( 'elementor/loaded' ) ) {
		return;
	}
	printf( "<style id=\"qafesheh-tokens-editor\">%s</style>\n", qafesheh_tokens_css() ); // phpcs:ignore WordPress.Security.EscapeOutput
}
add_action( 'elementor/editor/wp_head', 'qafesheh_elementor_tokens' );

/**
 * هل تحتاج هذه الصفحة أصول السلايدر؟
 *
 * @return bool
 */
function qafesheh_needs_slider() {
	if ( is_front_page() ) {
		return true;
	}

	if ( ! is_singular() ) {
		return false;
	}

	$data = (string) get_post_meta( get_the_ID(), '_elementor_data', true );

	return ( $data && false !== strpos( $data, 'qb_hero_slider' ) );
}

/**
 * تحميل أصول السلايدر عند تصييره خارج الحالات المتوقّعة.
 */
function qafesheh_force_slider_assets() {
	if ( ! wp_style_is( 'qafesheh-slider', 'enqueued' ) ) {
		wp_enqueue_style( 'qafesheh-slider' );
	}
	if ( ! wp_script_is( 'qafesheh-slider', 'enqueued' ) ) {
		wp_enqueue_script( 'qafesheh-slider' );
	}
}
