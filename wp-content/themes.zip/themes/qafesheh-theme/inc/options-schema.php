<?php
/**
 * مصدر الحقيقة الوحيد لإعدادات الثيم: تابات → مجموعات → حقول.
 * كل ما يضاف هنا يظهر تلقائياً في لوحة التحكم ويُحفظ ويُعقَّم بلا كود إضافي.
 *
 * أنواع الحقول المدعومة:
 * text, textarea, number, color, image, select, toggle, url, email, tel, heading
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * مخطط الإعدادات.
 *
 * @return array
 */
function qafesheh_options_schema() {
	$schema = array(

		/* ------------------------------------------------------------ الهوية */
		'identity' => array(
			'label' => 'الهوية والشعارات',
			'icon'  => 'dashicons-art',
			'desc'  => 'شعارات الموقع واسم المجموعة. كل ما يُرفع هنا يظهر في الهيدر والفوتر تلقائياً.',
			'groups' => array(
				array(
					'title'  => 'شعار المجموعة',
					'fields' => array(
						'logo_dark'  => array( 'type' => 'image', 'label' => 'الشعار على خلفية داكنة', 'help' => 'يظهر في الهيدر والفوتر. يفضّل PNG شفاف أو SVG.' ),
						'logo_light' => array( 'type' => 'image', 'label' => 'الشعار على خلفية فاتحة', 'help' => 'يُستخدم في الصفحات الفاتحة والطباعة.' ),
						'favicon'    => array( 'type' => 'image', 'label' => 'أيقونة المتصفح (Favicon)', 'help' => '512×512 مربعة.' ),
					),
				),
				array(
					'title'  => 'الاسم والوصف',
					'fields' => array(
						'brand_ar'   => array( 'type' => 'text', 'label' => 'اسم المجموعة بالعربي', 'default' => 'مجموعة قفيشة الصناعية' ),
						'brand_en'   => array( 'type' => 'text', 'label' => 'الاسم اللاتيني تحت الشعار', 'default' => 'QAFESHEH INDUSTRIAL GROUP' ),
						'est_year'   => array( 'type' => 'text', 'label' => 'سنة التأسيس', 'default' => '1968' ),
						'tagline'    => array( 'type' => 'textarea', 'label' => 'وصف قصير للمجموعة', 'default' => 'ثلاث علاماتٍ في الأزياء التراثية الفاخرة، من مصنعنا في سحاب إلى الخليج والوطن العربي.' ),
					),
				),
			),
		),

		/* ------------------------------------------------------------ الألوان */
		'colors' => array(
			'label' => 'الألوان والخطوط',
			'icon'  => 'dashicons-admin-appearance',
			'desc'  => 'تغيير أي لون هنا يغيّر الموقع كله فوراً — لا حاجة لتعديل أي كود.',
			'groups' => array(
				array(
					'title'  => 'ألوان المجموعة',
					'fields' => array(
						'c_ink'    => array( 'type' => 'color', 'label' => 'الحبر (الأسود الأساسي)', 'default' => '#0F0E0C' ),
						'c_ink_2'  => array( 'type' => 'color', 'label' => 'الأسود الأعمق (الشريط العلوي والفوتر)', 'default' => '#0A0906' ),
						'c_paper'  => array( 'type' => 'color', 'label' => 'الورق (الخلفية الأساسية)', 'default' => '#F2EEE7' ),
						'c_paper2' => array( 'type' => 'color', 'label' => 'الورق الثاني (الأقسام المتناوبة)', 'default' => '#E8E2D7' ),
						'c_gold'   => array( 'type' => 'color', 'label' => 'الذهبي', 'default' => '#B8912F' ),
						'c_rule'   => array( 'type' => 'color', 'label' => 'لون الخطوط الفاصلة', 'default' => '#D6CDBD' ),
						'c_text'   => array( 'type' => 'color', 'label' => 'لون النص', 'default' => '#3A362E' ),
						'c_muted'  => array( 'type' => 'color', 'label' => 'لون النص الثانوي', 'default' => '#7A7263' ),
					),
				),
				array(
					'title'  => 'ألوان العلامات',
					'fields' => array(
						'c_qafesheh' => array( 'type' => 'color', 'label' => 'قفيشة', 'default' => '#C9A227' ),
						'c_aljazi'   => array( 'type' => 'color', 'label' => 'الجازي', 'default' => '#E7E1D3' ),
						'c_makarem'  => array( 'type' => 'color', 'label' => 'مكارم', 'default' => '#A51E25' ),
					),
				),
				array(
					'title'  => 'الخطوط',
					'fields' => array(
						'font_display' => array(
							'type'    => 'select',
							'label'   => 'خط العناوين',
							'default' => 'naskh',
							'options' => array(
								'naskh' => 'Noto Naskh Arabic — نسخ رسمي (المعتمد)',
								'amiri' => 'Amiri — نسخ كلاسيكي',
								'plex'  => 'IBM Plex Sans Arabic — بلا زخرفة',
							),
						),
						'font_scale' => array( 'type' => 'number', 'label' => 'مقياس حجم الخط %', 'default' => 100, 'min' => 85, 'max' => 120, 'help' => 'يكبّر أو يصغّر كل النصوص بنسبة واحدة.' ),
					),
				),
			),
		),

		/* ------------------------------------------------------------ الهيدر */
		'header' => array(
			'label' => 'الهيدر',
			'icon'  => 'dashicons-menu-alt',
			'desc'  => 'الشريط العلوي وزر التواصل. القوائم نفسها من المظهر ← القوائم.',
			'groups' => array(
				array(
					'title'  => 'الشريط العلوي',
					'fields' => array(
						'top_address' => array( 'type' => 'text', 'label' => 'العنوان المختصر', 'default' => 'المدينة الصناعية — سحاب، عمّان، الأردن' ),
						'top_phone'   => array( 'type' => 'tel', 'label' => 'الهاتف', 'default' => '+962 79 881 7390' ),
						'top_link_1'  => array( 'type' => 'text', 'label' => 'رابط علوي ١ — النص', 'default' => 'بوابة التجّار' ),
						'top_url_1'   => array( 'type' => 'url', 'label' => 'رابط علوي ١ — الرابط' ),
						'top_link_2'  => array( 'type' => 'text', 'label' => 'رابط علوي ٢ — النص', 'default' => 'شكاوى واقتراحات' ),
						'top_url_2'   => array( 'type' => 'url', 'label' => 'رابط علوي ٢ — الرابط' ),
					),
				),
				array(
					'title'  => 'زر التواصل',
					'fields' => array(
						'header_cta_text' => array( 'type' => 'text', 'label' => 'نص الزر', 'default' => 'تواصل معنا' ),
						'header_cta_url'  => array( 'type' => 'url', 'label' => 'رابط الزر' ),
						'header_sticky'   => array( 'type' => 'toggle', 'label' => 'تثبيت الهيدر عند التمرير', 'default' => 1 ),
					),
				),
			),
		),

		/* ------------------------------------------------------------ الرئيسية */
		'home' => array(
			'label' => 'الصفحة الرئيسية',
			'icon'  => 'dashicons-admin-home',
			'desc'  => 'محتوى الأقسام الثابتة في الرئيسية.',
			'groups' => array(
				array(
					'title'  => 'الهيرو',
					'fields' => array(
						'hero_image'    => array( 'type' => 'image', 'label' => 'صورة الخلفية', 'help' => 'عرض 2560px على الأقل. لا تُحمَّل بكسل — هي عنصر LCP.' ),
						'hero_eyebrow'  => array( 'type' => 'text', 'label' => 'السطر العلوي', 'default' => 'EST. 1968 — AMMAN, JORDAN' ),
						'hero_title'    => array( 'type' => 'textarea', 'label' => 'العنوان', 'default' => "مجموعةٌ صناعية أردنية\nفي الأزياء التراثية الفاخرة", 'help' => 'كل سطر في سطر منفصل.' ),
						'hero_text'     => array( 'type' => 'textarea', 'label' => 'النص تحت العنوان', 'default' => 'ثلاث علاماتٍ متخصصة، ومصنعٌ واحد في المدينة الصناعية بسحاب، يخدمان السوق المحلي وأسواق الخليج والوطن العربي منذ عقود.' ),
						'hero_btn1_txt' => array( 'type' => 'text', 'label' => 'الزر الأول — النص', 'default' => 'قطاعات الأعمال' ),
						'hero_btn1_url' => array( 'type' => 'url', 'label' => 'الزر الأول — الرابط' ),
						'hero_btn2_txt' => array( 'type' => 'text', 'label' => 'الزر الثاني — النص', 'default' => 'نبذة عن المجموعة' ),
						'hero_btn2_url' => array( 'type' => 'url', 'label' => 'الزر الثاني — الرابط' ),
					),
				),
				array(
					'title'  => 'منصّة الأرقام',
					'fields' => array(
						'stat1_num' => array( 'type' => 'text', 'label' => 'الرقم ١', 'default' => '100+' ),
						'stat1_lbl' => array( 'type' => 'text', 'label' => 'الوصف ١', 'default' => 'عاملٌ وحِرَفي' ),
						'stat2_num' => array( 'type' => 'text', 'label' => 'الرقم ٢', 'default' => '03' ),
						'stat2_lbl' => array( 'type' => 'text', 'label' => 'الوصف ٢', 'default' => 'علامات تجارية' ),
						'stat3_num' => array( 'type' => 'text', 'label' => 'الرقم ٣', 'default' => '05' ),
						'stat3_lbl' => array( 'type' => 'text', 'label' => 'الوصف ٣', 'default' => 'معارض في المملكة' ),
						'stat4_num' => array( 'type' => 'text', 'label' => 'الرقم ٤', 'default' => '01' ),
						'stat4_lbl' => array( 'type' => 'text', 'label' => 'الوصف ٤', 'default' => 'مصنع في سحاب' ),
					),
				),
				array(
					'title'  => 'قسم المجموعة (٠١)',
					'fields' => array(
						'about_title' => array( 'type' => 'textarea', 'label' => 'العنوان', 'default' => 'بدأ المصنع بأيدٍ عاملةٍ قليلة وماكيناتٍ قليلة، واستمرّ بالتطوّر إلى يومنا هذا.' ),
						'about_col1'  => array( 'type' => 'textarea', 'label' => 'العمود الأول', 'default' => 'أصبح عدد الأيدي العاملة يتجاوز مئة عاملٍ من الطراز الأول، مع أحدث الماكينات والآلات والمعدات المتخصصة التي تساعدنا في التطوّر والابتكار.' ),
						'about_col2'  => array( 'type' => 'textarea', 'label' => 'العمود الثاني', 'default' => 'تم بيع ملايين الفروات في الأسواق المحلية والعالمية، ونسعى دائماً للوصول إلى أكبر عددٍ ممكن من التجّار والزبائن وتلبية جميع احتياجاتهم.' ),
						'about_link'  => array( 'type' => 'url', 'label' => 'رابط «نبذة كاملة»' ),
					),
				),
				array(
					'title'  => 'القدرات التصنيعية (٠٣)',
					'fields' => array(
						'cap_title' => array( 'type' => 'text', 'label' => 'العنوان', 'default' => 'مصنعٌ واحد يخدم العلامات الثلاث' ),
						'cap_image' => array( 'type' => 'image', 'label' => 'صورة القسم' ),
						'cap_r1_k'  => array( 'type' => 'text', 'label' => 'صف ١ — العنوان', 'default' => 'الموقع' ),
						'cap_r1_v'  => array( 'type' => 'text', 'label' => 'صف ١ — القيمة', 'default' => 'مدينة الملك عبدالله الثاني الصناعية — سحاب' ),
						'cap_r2_k'  => array( 'type' => 'text', 'label' => 'صف ٢ — العنوان', 'default' => 'القوى العاملة' ),
						'cap_r2_v'  => array( 'type' => 'text', 'label' => 'صف ٢ — القيمة', 'default' => 'أكثر من ١٠٠ عامل وحِرَفي' ),
						'cap_r3_k'  => array( 'type' => 'text', 'label' => 'صف ٣ — العنوان', 'default' => 'خطوط الإنتاج' ),
						'cap_r3_v'  => array( 'type' => 'text', 'label' => 'صف ٣ — القيمة', 'default' => 'فروات · بشوت · أثواب · مطرزات' ),
						'cap_r4_k'  => array( 'type' => 'text', 'label' => 'صف ٤ — العنوان', 'default' => 'الدوام' ),
						'cap_r4_v'  => array( 'type' => 'text', 'label' => 'صف ٤ — القيمة', 'default' => '٧:٠٠ — ١٩:٠٠' ),
						'cap_r5_k'  => array( 'type' => 'text', 'label' => 'صف ٥ — العنوان', 'default' => 'المنشأ' ),
						'cap_r5_v'  => array( 'type' => 'text', 'label' => 'صف ٥ — القيمة', 'default' => 'صناعة أردنية ١٠٠٪' ),
					),
				),
				array(
					'title'  => 'دعوة التواصل أسفل الرئيسية',
					'fields' => array(
						'cta_title' => array( 'type' => 'text', 'label' => 'العنوان', 'default' => 'للاستفسارات التجارية وطلبات الجملة والتصدير' ),
						'cta_text'  => array( 'type' => 'text', 'label' => 'النص', 'default' => 'فريق المجموعة يستقبل طلبات الشراكة والتوريد على مدار العام.' ),
						'cta_b1_t'  => array( 'type' => 'text', 'label' => 'الزر ١ — النص', 'default' => 'تواصل معنا' ),
						'cta_b1_u'  => array( 'type' => 'url', 'label' => 'الزر ١ — الرابط' ),
						'cta_b2_t'  => array( 'type' => 'text', 'label' => 'الزر ٢ — النص', 'default' => 'الوظائف' ),
						'cta_b2_u'  => array( 'type' => 'url', 'label' => 'الزر ٢ — الرابط' ),
					),
				),
			),
		),

		/* ------------------------------------------------------------ التواصل */
		'contact' => array(
			'label' => 'بيانات التواصل',
			'icon'  => 'dashicons-phone',
			'desc'  => 'تظهر في الفوتر وصفحة التواصل والشريط العلوي.',
			'groups' => array(
				array(
					'title'  => 'المجموعة',
					'fields' => array(
						'c_email'   => array( 'type' => 'email', 'label' => 'البريد الإلكتروني', 'default' => 'info@qafesheh.com' ),
						'c_phone'   => array( 'type' => 'tel', 'label' => 'الهاتف', 'default' => '+962 79 881 7390' ),
						'c_address' => array( 'type' => 'text', 'label' => 'العنوان', 'default' => 'المدينة الصناعية — سحاب، عمّان' ),
						'c_map'     => array( 'type' => 'url', 'label' => 'رابط الموقع على الخرائط' ),
					),
				),
				array(
					'title'  => 'وسائل التواصل الاجتماعي',
					'fields' => array(
						's_instagram' => array( 'type' => 'url', 'label' => 'إنستغرام' ),
						's_facebook'  => array( 'type' => 'url', 'label' => 'فيسبوك' ),
						's_youtube'   => array( 'type' => 'url', 'label' => 'يوتيوب' ),
						's_whatsapp'  => array( 'type' => 'tel', 'label' => 'واتساب (رقم دولي بلا رموز)' ),
					),
				),
			),
		),

		/* ------------------------------------------------------------ الفوتر */
		'footer' => array(
			'label' => 'الفوتر',
			'icon'  => 'dashicons-align-wide',
			'desc'  => 'نصوص الفوتر الثابتة. أعمدة الروابط من المظهر ← القوائم.',
			'groups' => array(
				array(
					'title'  => 'النصوص',
					'fields' => array(
						'footer_about'   => array( 'type' => 'textarea', 'label' => 'الوصف تحت الشعار', 'default' => 'ثلاث علاماتٍ في الأزياء التراثية الفاخرة، من مصنعنا في سحاب إلى الخليج والوطن العربي.' ),
						'footer_copy'    => array( 'type' => 'text', 'label' => 'سطر الحقوق', 'default' => '© ٢٠٢٦ مجموعة قفيشة الصناعية — جميع الحقوق محفوظة' ),
						'footer_credit'  => array( 'type' => 'text', 'label' => 'سطر التطوير', 'default' => 'تطوير QB Studio' ),
						'footer_stitch'  => array( 'type' => 'toggle', 'label' => 'إظهار شريط الغرز الزخرفي', 'default' => 1 ),
					),
				),
			),
		),

		/* ------------------------------------------------------------ متقدم */
		'advanced' => array(
			'label' => 'إعدادات متقدمة',
			'icon'  => 'dashicons-admin-generic',
			'desc'  => 'لا تلمس هذه الإعدادات إلا إذا كنت تعرف ماذا تفعل.',
			'groups' => array(
				array(
					'title'  => 'الأداء والحركة',
					'fields' => array(
						'motion_on'   => array( 'type' => 'toggle', 'label' => 'تفعيل حركات الدخول', 'default' => 1 ),
						'preload_hero'=> array( 'type' => 'toggle', 'label' => 'Preload لصورة الهيرو', 'default' => 1 ),
						'lazy_offset' => array( 'type' => 'number', 'label' => 'مسافة التحميل الكسول (px)', 'default' => 200, 'min' => 0, 'max' => 1200 ),
					),
				),
				array(
					'title'  => 'أكواد إضافية',
					'fields' => array(
						'head_code' => array( 'type' => 'textarea', 'label' => 'كود داخل <head>', 'help' => 'مثل Google Analytics. يُطبع كما هو.' ),
						'body_code' => array( 'type' => 'textarea', 'label' => 'كود بعد فتح <body>' ),
					),
				),
			),
		),
	);

	/**
	 * تعديل المخطط من بلجن أو ملف فرعي.
	 *
	 * @param array $schema المخطط.
	 */
	return apply_filters( 'qafesheh_options_schema', $schema );
}

/**
 * قائمة مسطّحة: المفتاح => تعريف الحقل.
 *
 * @return array
 */
function qafesheh_options_flat() {
	static $flat = null;
	if ( null !== $flat ) {
		return $flat;
	}

	$flat = array();
	foreach ( qafesheh_options_schema() as $tab ) {
		if ( empty( $tab['groups'] ) ) {
			continue;
		}
		foreach ( $tab['groups'] as $group ) {
			if ( empty( $group['fields'] ) ) {
				continue;
			}
			foreach ( $group['fields'] as $key => $field ) {
				$flat[ $key ] = $field;
			}
		}
	}
	return $flat;
}
