<?php
/**
 * الاستيراد والإعداد السريع — زرٌّ واحد يبني الموقع كاملاً:
 * الإعدادات، الصفحات، القوائم، الشركات، الخدمات، الفروع، الوظائف، المقالات.
 * كل خطوة قابلة للتشغيل وحدها، وكلها آمنة عند التكرار (لا تُنشئ نسخاً مكررة).
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * سجلّ ما تم استيراده.
 *
 * @return array
 */
function qafesheh_import_log() {
	$log = get_option( 'qafesheh_imported', array() );
	return is_array( $log ) ? $log : array();
}

/**
 * تحديث سجلّ الاستيراد.
 *
 * @param string $group المجموعة.
 * @param string $key   المفتاح.
 * @param int    $id    المعرّف.
 */
function qafesheh_import_remember( $group, $key, $id ) {
	$log = qafesheh_import_log();
	if ( empty( $log[ $group ] ) || ! is_array( $log[ $group ] ) ) {
		$log[ $group ] = array();
	}
	$log[ $group ][ $key ] = (int) $id;
	update_option( 'qafesheh_imported', $log, false );
}

/**
 * جلب معرّف عنصر مستورد سابقاً إن كان لا يزال موجوداً.
 *
 * @param string $group المجموعة.
 * @param string $key   المفتاح.
 * @return int
 */
function qafesheh_import_id( $group, $key ) {
	$log = qafesheh_import_log();
	$id  = absint( $log[ $group ][ $key ] ?? 0 );

	if ( $id && get_post( $id ) && 'trash' !== get_post_status( $id ) ) {
		return $id;
	}
	return 0;
}

/**
 * خطوات الاستيراد.
 *
 * @return array
 */
function qafesheh_import_steps() {
	return array(
		'options'   => array(
			'label' => 'الإعدادات الأساسية',
			'desc'  => 'اسم المجموعة، بيانات التواصل، نصوص الرئيسية، روابط السوشال — كلها بالبيانات الحقيقية.',
			'icon'  => 'dashicons-admin-generic',
		),
		'pages'     => array(
			'label' => 'الصفحات',
			'desc'  => '١٢ صفحة: الرئيسية، من نحن، المصنع، شركاتنا، الخدمات، الفروع، المقالات، الوظائف، الشكاوى، تواصل معنا، والسياسات.',
			'icon'  => 'dashicons-admin-page',
		),
		'companies' => array(
			'label' => 'الشركات الثلاث',
			'desc'  => 'قفيشة، الجازي، مكارم — بصفحاتها التعريفية وألوانها وروابط متاجرها.',
			'icon'  => 'dashicons-building',
		),
		'services'  => array(
			'label' => 'الخدمات',
			'desc'  => '٨ خدمات من التصنيع والتطريز إلى الجملة والتصدير والعلامات الخاصة.',
			'icon'  => 'dashicons-admin-tools',
		),
		'branches'  => array(
			'label' => 'الفروع والمعارض',
			'desc'  => '٧ فروع بعناوينها وهواتفها ودوامها، وكل فرع مربوط بعلاماته.',
			'icon'  => 'dashicons-store',
		),
		'jobs'      => array(
			'label' => 'الوظائف',
			'desc'  => '٦ شواغر بأوصافٍ كاملة ومتطلبات.',
			'icon'  => 'dashicons-businessperson',
		),
		'articles'  => array(
			'label' => 'المقالات والأخبار',
			'desc'  => '٦ مقالات جاهزة عن المصنع والفروة والعناية والمقاسات.',
			'icon'  => 'dashicons-media-document',
		),
		'media'     => array(
			'label' => 'الصور',
			'desc'  => '١٣ صورة من صور العميل تُرفع لمكتبة الوسائط وتُوزَّع على الهيرو والعلامات والمقالات والبانرات تلقائياً.',
			'icon'  => 'dashicons-format-gallery',
		),
		'elementor' => array(
			'label' => 'بناء الرئيسية بـElementor',
			'desc'  => 'يحوّل الصفحة الرئيسية إلى تخطيط Elementor كامل بودجات QB بالترتيب المعتمد، جاهزة للتعديل بالسحب.',
			'icon'  => 'dashicons-layout',
		),
		'menus'     => array(
			'label' => 'القوائم',
			'desc'  => '٦ قوائم: الرئيسية، الشريط العلوي، وأربعة أعمدة للفوتر — مربوطة بأماكنها تلقائياً.',
			'icon'  => 'dashicons-menu-alt',
		),
		'finalize'  => array(
			'label' => 'الضبط النهائي',
			'desc'  => 'تعيين الصفحة الرئيسية وصفحة المقالات، وإعادة بناء الروابط الدائمة.',
			'icon'  => 'dashicons-yes-alt',
		),
	);
}

/**
 * صفحة الاستيراد.
 */
function qafesheh_render_import_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$steps = qafesheh_import_steps();
	$log   = qafesheh_import_log();
	$done  = ! empty( $log['pages'] );
	?>
	<div class="wrap q-opt q-imp" id="q-imp">

		<?php qafesheh_admin_topbar( 'الاستيراد والإعداد السريع', 'يبني الموقع كاملاً بالبيانات الحقيقية في خطوةٍ واحدة', false ); ?>

		<div class="q-imp__in">

			<div class="q-imp__intro">
				<h2>ابدأ من هنا</h2>
				<p>
					هذا الزر ينشئ الصفحات والقوائم والشركات والخدمات والفروع والوظائف والمقالات دفعةً واحدة،
					ويملأها بمحتوىً عربي حقيقي مأخوذ من بيانات المجموعة — لا نصوص وهمية.
					بعدها تعدّل ما تشاء كأي محتوى عادي.
				</p>
				<p class="q-imp__safe">
					<span class="dashicons dashicons-shield"></span>
					آمن عند التكرار: تشغيل الاستيراد مرة أخرى يُحدّث ما أنشأه سابقاً ولا يُنشئ نسخاً مكررة،
					ولا يمسّ أي محتوى أضفته أنت.
				</p>

				<div class="q-imp__actions">
					<button type="button" class="q-opt__save" id="q-imp-all">استيراد كل شيء</button>
					<span class="q-imp__status" id="q-imp-status"><?php echo $done ? 'تم الاستيراد سابقاً — يمكنك إعادة التشغيل بأمان.' : 'لم يتم الاستيراد بعد.'; ?></span>
				</div>

				<div class="q-imp__progress" id="q-imp-progress" hidden><span></span></div>
			</div>

			<div class="q-imp__grid">
				<?php foreach ( $steps as $id => $step ) : ?>
					<div class="q-imp__card" data-step="<?php echo esc_attr( $id ); ?>">
						<span class="dashicons <?php echo esc_attr( $step['icon'] ); ?>"></span>
						<strong><?php echo esc_html( $step['label'] ); ?></strong>
						<p><?php echo esc_html( $step['desc'] ); ?></p>
						<button type="button" class="q-opt__btn q-imp__run">تشغيل هذه الخطوة</button>
						<span class="q-imp__result"></span>
					</div>
				<?php endforeach; ?>
			</div>

			<div class="q-imp__after">
				<h2>بعد الاستيراد — ماذا يبقى عليك؟</h2>
				<ol>
					<li>أضف <strong>رابط الخريطة</strong> لكل فرع (خرائط جوجل ← مشاركة ← نسخ الرابط) — هذا الحقل الوحيد الفارغ بعد الاستيراد.</li>
					<li>استبدل <strong>صور العميل</strong> بالصور النهائية عالية الدقة عند وصولها — الصور الحالية موزّعة تلقائياً في أماكنها.</li>
					<li>أنشئ نموذج Contact Form 7 وضع الشورت كود في: إعدادات الوظائف / صفحة تواصل معنا.</li>
					<li>راجع <strong>سياسة الخصوصية والشروط</strong> قانونياً قبل الإطلاق.</li>
					<li>افتح <strong>دليل الصفحات</strong> لترتيب ودجات Elementor في الصفحات الداخلية.</li>
				</ol>
				<a class="q-opt__btn" href="<?php echo esc_url( admin_url( 'admin.php?page=qafesheh-guide' ) ); ?>">افتح دليل الصفحات</a>
			</div>

		</div>
	</div>
	<?php
}

/**
 * تنفيذ خطوة عبر AJAX.
 */
function qafesheh_ajax_import() {
	check_ajax_referer( 'qafesheh_admin', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'صلاحيات غير كافية.' ), 403 );
	}

	$step  = sanitize_key( $_POST['step'] ?? '' );
	$steps = qafesheh_import_steps();

	if ( ! isset( $steps[ $step ] ) ) {
		wp_send_json_error( array( 'message' => 'خطوة غير معروفة.' ), 400 );
	}

	$callback = 'qafesheh_import_' . $step;

	if ( ! function_exists( $callback ) ) {
		wp_send_json_error( array( 'message' => 'الخطوة غير منفّذة.' ), 500 );
	}

	$result = call_user_func( $callback );

	if ( is_array( $result ) ) {
		wp_send_json_success( $result );
	}

	wp_send_json_success( array( 'message' => $result ) );
}
add_action( 'wp_ajax_qafesheh_import', 'qafesheh_ajax_import' );

/**
 * نقل ملف من أصول الثيم إلى مكتبة الوسائط مرة واحدة فقط.
 *
 * @param string $rel   مسار نسبي داخل الثيم.
 * @param string $title عنوان المرفق.
 * @return int معرّف المرفق أو 0.
 */
function qafesheh_import_attachment( $rel, $title ) {
	$key      = sanitize_key( str_replace( array( '/', '.' ), '-', $rel ) );
	$existing = absint( qafesheh_import_log()['media'][ $key ] ?? 0 );

	if ( $existing && get_post( $existing ) ) {
		return $existing;
	}

	$source = QAFESHEH_DIR . ltrim( $rel, '/' );
	if ( ! file_exists( $source ) ) {
		return 0;
	}

	$bits = file_get_contents( $source ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( false === $bits ) {
		return 0;
	}

	$upload = wp_upload_bits( basename( $source ), null, $bits );
	if ( ! empty( $upload['error'] ) ) {
		return 0;
	}

	$type = wp_check_filetype( $upload['file'] );

	$id = wp_insert_attachment(
		array(
			'post_mime_type' => $type['type'] ? $type['type'] : 'image/png',
			'post_title'     => $title,
			'post_status'    => 'inherit',
		),
		$upload['file']
	);

	if ( is_wp_error( $id ) || ! $id ) {
		return 0;
	}

	require_once ABSPATH . 'wp-admin/includes/image.php';
	wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $upload['file'] ) );
	update_post_meta( $id, '_wp_attachment_image_alt', $title );

	qafesheh_import_remember( 'media', $key, $id );

	return (int) $id;
}

/* ========================================================== الخطوات */

/**
 * ١ — الإعدادات.
 *
 * @return string
 */
function qafesheh_import_options() {
	$current = get_option( QAFESHEH_OPTION_KEY, array() );
	$current = is_array( $current ) ? $current : array();

	/* الافتراضيات أولاً، ثم بيانات المجموعة، ثم ما عدّله المستخدم — بهذا الترتيب.
	   بدون الافتراضيات هنا كانت كل المفاتيح (الحركة، التثبيت…) تُحفظ صفراً. */
	$merged = array_merge( qafesheh_option_defaults(), qafesheh_data_options(), $current );
	$merged = qafesheh_sanitize_options( $merged );

	/* الشعار المرفق مع الثيم يُنقل لمكتبة الوسائط ويُربط تلقائياً */
	if ( empty( $merged['logo_dark'] ) ) {
		$logo = qafesheh_import_attachment( 'assets/images/logo-qafesheh.png', 'شعار مجموعة قفيشة' );
		if ( $logo ) {
			$merged['logo_dark'] = $logo;
			$merged['logo_light'] = $logo;
		}
	}

	update_option( QAFESHEH_OPTION_KEY, $merged );

	return 'تم ضبط ' . count( qafesheh_data_options() ) . ' إعداداً بالبيانات الحقيقية، وربط الشعار.';
}

/**
 * ٢ — الصفحات.
 *
 * @return string
 */
function qafesheh_import_pages() {
	$pages = qafesheh_data_pages();
	$count = 0;

	foreach ( $pages as $key => $page ) {
		$existing = qafesheh_import_id( 'pages', $key );

		if ( ! $existing ) {
			$by_path = get_page_by_path( $page['slug'] );
			$existing = $by_path ? $by_path->ID : 0;
		}

		$args = array(
			'post_title'   => $page['title'],
			'post_name'    => $page['slug'],
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_content' => $page['content'],
			'menu_order'   => (int) $page['order'],
		);

		if ( $existing ) {
			$args['ID'] = $existing;
			/* لا نمسح محتوى عدّله المستخدم */
			$stored = get_post_field( 'post_content', $existing );
			if ( trim( (string) $stored ) !== trim( (string) $page['content'] ) && '' !== trim( (string) $stored ) ) {
				unset( $args['post_content'] );
			}
			$id = wp_update_post( $args );
		} else {
			$id = wp_insert_post( $args );
			++$count;
		}

		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_qafesheh_page_key', $key );
			update_post_meta( $id, '_qafesheh_builder', $page['builder'] );

			/* قوالب الصفحات الخاصة */
			$templates = array( 'complaints' => 'page-complaints.php' );
			if ( isset( $templates[ $key ] ) ) {
				update_post_meta( $id, '_wp_page_template', $templates[ $key ] );
			}

			if ( ! empty( $page['note'] ) ) {
				update_post_meta( $id, '_qafesheh_note', $page['note'] );
			}

			qafesheh_import_remember( 'pages', $key, $id );
		}
	}

	return sprintf( 'تم تجهيز %d صفحة (%d جديدة).', count( $pages ), $count );
}

/**
 * ٣ — الشركات.
 *
 * @return string
 */
function qafesheh_import_companies() {
	$new = 0;

	foreach ( qafesheh_data_companies() as $company ) {
		$existing = qafesheh_import_id( 'companies', $company['slug'] );

		$args = array(
			'post_title'   => $company['title'],
			'post_name'    => $company['slug'],
			'post_type'    => 'qaf_company',
			'post_status'  => 'publish',
			'post_content' => $company['content'],
			'post_excerpt' => $company['excerpt'],
		);

		if ( $existing ) {
			$args['ID'] = $existing;
			$id         = wp_update_post( $args );
		} else {
			$id = wp_insert_post( $args );
			++$new;
		}

		if ( ! $id || is_wp_error( $id ) ) {
			continue;
		}

		update_post_meta( $id, 'q_company_en', $company['en'] );
		update_post_meta( $id, 'q_company_tag', $company['tag'] );
		update_post_meta( $id, 'q_company_color', $company['color'] );
		update_post_meta( $id, 'q_company_url', $company['shop'] );
		update_post_meta( $id, 'q_company_cats', $company['cats'] );

		if ( ! get_post_meta( $id, 'q_company_logo', true ) ) {
			$logo = qafesheh_import_attachment(
				'assets/images/logo-' . $company['slug'] . '.png',
				'شعار ' . $company['title']
			);
			if ( $logo ) {
				update_post_meta( $id, 'q_company_logo', $logo );
			}
		}

		wp_set_object_terms( $id, array( $company['brand'] ), 'qaf_brand' );
		qafesheh_import_remember( 'companies', $company['slug'], $id );
	}

	return sprintf( 'تم تجهيز ٣ شركات (%d جديدة) مع شعاراتها.', $new );
}

/**
 * ٤ — الخدمات.
 *
 * @return string
 */
function qafesheh_import_services() {
	$new   = 0;
	$order = 0;

	foreach ( qafesheh_data_services() as $service ) {
		++$order;
		$key      = sanitize_title( $service['title'] );
		$existing = qafesheh_import_id( 'services', $key );

		$args = array(
			'post_title'   => $service['title'],
			'post_type'    => 'qaf_service',
			'post_status'  => 'publish',
			'post_content' => $service['content'],
			'post_excerpt' => $service['excerpt'],
			'menu_order'   => $order,
		);

		if ( $existing ) {
			$args['ID'] = $existing;
			$id         = wp_update_post( $args );
		} else {
			$id = wp_insert_post( $args );
			++$new;
		}

		if ( ! $id || is_wp_error( $id ) ) {
			continue;
		}

		update_post_meta( $id, 'q_service_num', $service['num'] );
		qafesheh_import_remember( 'services', $key, $id );
	}

	return sprintf( 'تم تجهيز ٨ خدمات (%d جديدة).', $new );
}

/**
 * ٥ — الفروع.
 *
 * @return string
 */
function qafesheh_import_branches() {
	$new   = 0;
	$order = 0;

	foreach ( qafesheh_data_branches() as $branch ) {
		++$order;
		$key      = sanitize_title( $branch['title'] );
		$existing = qafesheh_import_id( 'branches', $key );

		$args = array(
			'post_title'   => $branch['title'],
			'post_type'    => 'qaf_branch',
			'post_status'  => 'publish',
			'post_content' => $branch['note'] ? '<p>' . $branch['note'] . '</p>' : '',
			'menu_order'   => $order,
		);

		if ( $existing ) {
			$args['ID'] = $existing;
			$id         = wp_update_post( $args );
		} else {
			$id = wp_insert_post( $args );
			++$new;
		}

		if ( ! $id || is_wp_error( $id ) ) {
			continue;
		}

		update_post_meta( $id, 'q_branch_city', $branch['city'] );
		update_post_meta( $id, 'q_branch_addr', $branch['addr'] );
		update_post_meta( $id, 'q_branch_phone', $branch['phone'] );
		update_post_meta( $id, 'q_branch_hours', $branch['hours'] );

		wp_set_object_terms( $id, $branch['brands'], 'qaf_brand' );
		qafesheh_import_remember( 'branches', $key, $id );
	}

	return sprintf( 'تم تجهيز ٧ فروع (%d جديدة). ينقصها رابط الخريطة فقط.', $new );
}

/**
 * ٦ — الوظائف.
 *
 * @return string
 */
function qafesheh_import_jobs() {
	$new = 0;

	foreach ( qafesheh_data_jobs() as $job ) {
		$key      = sanitize_title( $job['title'] );
		$existing = qafesheh_import_id( 'jobs', $key );

		$args = array(
			'post_title'   => $job['title'],
			'post_type'    => 'qaf_job',
			'post_status'  => 'publish',
			'post_content' => $job['content'],
		);

		if ( $existing ) {
			$args['ID'] = $existing;
			$id         = wp_update_post( $args );
		} else {
			$id = wp_insert_post( $args );
			++$new;
		}

		if ( ! $id || is_wp_error( $id ) ) {
			continue;
		}

		update_post_meta( $id, 'q_job_dept', $job['dept'] );
		update_post_meta( $id, 'q_job_location', $job['location'] );
		update_post_meta( $id, 'q_job_type', $job['type'] );

		qafesheh_import_remember( 'jobs', $key, $id );
	}

	return sprintf( 'تم تجهيز ٦ وظائف (%d جديدة).', $new );
}

/**
 * ٧ — المقالات.
 *
 * @return string
 */
function qafesheh_import_articles() {
	$new  = 0;
	$days = 0;

	foreach ( qafesheh_data_articles() as $article ) {
		$days    += 6;
		$key      = sanitize_title( $article['title'] );
		$existing = qafesheh_import_id( 'articles', $key );

		$args = array(
			'post_title'   => $article['title'],
			'post_type'    => 'post',
			'post_status'  => 'publish',
			'post_content' => $article['content'],
			'post_excerpt' => $article['excerpt'],
		);

		if ( $existing ) {
			$args['ID'] = $existing;
			$id         = wp_update_post( $args );
		} else {
			$args['post_date'] = gmdate( 'Y-m-d H:i:s', strtotime( '-' . $days . ' days' ) );
			$id                = wp_insert_post( $args );
			++$new;
		}

		if ( $id && ! is_wp_error( $id ) ) {
			qafesheh_import_remember( 'articles', $key, $id );
		}
	}

	return sprintf( 'تم تجهيز ٦ مقالات (%d جديدة).', $new );
}

/**
 * ٨ — القوائم.
 *
 * @return string
 */
function qafesheh_import_menus() {
	$menus     = qafesheh_data_menus();
	$locations = get_theme_mod( 'nav_menu_locations', array() );
	$locations = is_array( $locations ) ? $locations : array();
	$built     = 0;

	foreach ( $menus as $location => $menu ) {

		$object = wp_get_nav_menu_object( $menu['name'] );
		$menu_id = $object ? (int) $object->term_id : (int) wp_create_nav_menu( $menu['name'] );

		if ( is_wp_error( $menu_id ) || ! $menu_id ) {
			continue;
		}

		/* تنظيف العناصر التي أنشأها الاستيراد سابقاً فقط */
		$items = wp_get_nav_menu_items( $menu_id );
		if ( $items ) {
			foreach ( $items as $item ) {
				wp_delete_post( $item->ID, true );
			}
		}

		foreach ( $menu['items'] as $entry ) {
			$parent_id = qafesheh_add_menu_item( $menu_id, $entry, 0 );

			if ( ! empty( $entry['children'] ) && $parent_id ) {
				foreach ( $entry['children'] as $child ) {
					$parts = explode( ':', $child );
					qafesheh_add_menu_item(
						$menu_id,
						array( $parts[0] => $parts[1] ?? '' ),
						$parent_id
					);
				}
			}
		}

		$locations[ $location ] = $menu_id;
		++$built;
	}

	set_theme_mod( 'nav_menu_locations', $locations );

	return sprintf( 'تم بناء %d قوائم وربطها بأماكنها.', $built );
}

/**
 * إضافة عنصر قائمة.
 *
 * @param int   $menu_id  معرّف القائمة.
 * @param array $entry    تعريف العنصر.
 * @param int   $parent   العنصر الأب.
 * @return int
 */
function qafesheh_add_menu_item( $menu_id, $entry, $parent = 0 ) {

	if ( ! empty( $entry['page'] ) ) {
		$object_id = qafesheh_import_id( 'pages', $entry['page'] );
		$type      = 'page';
	} elseif ( ! empty( $entry['company'] ) ) {
		$object_id = qafesheh_import_id( 'companies', $entry['company'] );
		$type      = 'qaf_company';
	} else {
		return 0;
	}

	if ( ! $object_id ) {
		return 0;
	}

	$args = array(
		'menu-item-object-id' => $object_id,
		'menu-item-object'    => $type,
		'menu-item-type'      => 'post_type',
		'menu-item-status'    => 'publish',
		'menu-item-parent-id' => $parent,
	);

	if ( ! empty( $entry['label'] ) ) {
		$args['menu-item-title'] = $entry['label'];
	}

	$item_id = wp_update_nav_menu_item( $menu_id, 0, $args );

	return is_wp_error( $item_id ) ? 0 : (int) $item_id;
}

/**
 * ٩ — الضبط النهائي.
 *
 * @return string
 */
function qafesheh_import_finalize() {
	$home = qafesheh_import_id( 'pages', 'home' );
	$blog = qafesheh_import_id( 'pages', 'blog' );

	if ( $home ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $home );
	}
	if ( $blog ) {
		update_option( 'page_for_posts', $blog );
	}

	/* روابط دائمة نظيفة */
	if ( ! get_option( 'permalink_structure' ) ) {
		update_option( 'permalink_structure', '/%postname%/' );
	}

	qafesheh_register_post_types();
	qafesheh_register_taxonomies();
	flush_rewrite_rules();

	do_action( 'litespeed_purge_all' );

	return 'تم تعيين الرئيسية وصفحة المقالات وإعادة بناء الروابط.';
}

/**
 * ٩ — بناء الرئيسية بـElementor.
 *
 * @return string
 */
function qafesheh_import_elementor() {
	$home = qafesheh_import_id( 'pages', 'home' );

	if ( ! $home ) {
		return 'شغّل خطوة «الصفحات» أولاً.';
	}

	if ( ! did_action( 'elementor/loaded' ) ) {
		return 'Elementor غير مفعّل — فعّله ثم أعد تشغيل هذه الخطوة. الرئيسية تعمل حالياً بالقالب الجاهز.';
	}

	/* لا ندهس عملاً يدوياً موجوداً إلا إذا كان تخطيطنا نفسه */
	$existing = (string) get_post_meta( $home, '_elementor_data', true );
	$stamp    = (string) get_post_meta( $home, '_qafesheh_el_built', true );

	if ( $existing && '[]' !== trim( $existing ) && ! $stamp ) {
		return 'الرئيسية مبنية يدوياً بـElementor — لم نلمسها. احذف تخطيطها أولاً إن أردت إعادة البناء.';
	}

	$layout = qafesheh_elementor_home_layout();

	update_post_meta( $home, '_elementor_data', wp_slash( wp_json_encode( $layout ) ) );
	update_post_meta( $home, '_elementor_edit_mode', 'builder' );
	update_post_meta( $home, '_elementor_template_type', 'wp-page' );
	update_post_meta( $home, '_wp_page_template', 'default' );
	update_post_meta( $home, '_qafesheh_el_built', gmdate( 'c' ) );
	update_post_meta( $home, '_qafesheh_no_banner', 1 );

	if ( defined( 'ELEMENTOR_VERSION' ) ) {
		update_post_meta( $home, '_elementor_version', ELEMENTOR_VERSION );
	}

	/* تفريغ كاش Elementor حتى يعاد توليد CSS الصفحة */
	if ( class_exists( '\\Elementor\\Plugin' ) ) {
		\Elementor\Plugin::$instance->files_manager->clear_cache();
	}

	do_action( 'litespeed_purge_all' );

	return sprintf( 'تم بناء الرئيسية بـ%d أقسام Elementor بودجات QB.', count( $layout ) );
}

/**
 * معرّف صورة مرفقة مع الثيم بعد رفعها.
 *
 * @param string $slug اسم الملف بلا امتداد.
 * @return int
 */
function qafesheh_demo_image_id( $slug ) {
	$rel = 'assets/images/demo/' . (string) $slug . '.jpg';
	$key = sanitize_key( str_replace( array( '/', '.' ), '-', $rel ) );

	return absint( qafesheh_import_log()['media'][ $key ] ?? 0 );
}

/**
 * ٨ — الصور: رفعها وتوزيعها.
 *
 * @return string
 */
function qafesheh_import_media() {
	$files = qafesheh_data_media();
	$map   = qafesheh_data_media_map();

	/* توليد المقاسات لـ١٣ صورة دفعةً واحدة قد يتجاوز مهلة التنفيذ،
	   لذلك نرفع على دفعات ونطلب من الواجهة إعادة النداء حتى تكتمل. */
	$batch   = 4;
	$done    = 0;
	$new     = 0;
	$pending = 0;

	foreach ( $files as $slug => $title ) {
		if ( qafesheh_demo_image_id( $slug ) ) {
			++$done;
			continue;
		}

		if ( $new >= $batch ) {
			++$pending;
			continue;
		}

		if ( qafesheh_import_attachment( 'assets/images/demo/' . $slug . '.jpg', $title ) ) {
			++$new;
			++$done;
		} else {
			++$done; /* ملف مفقود — لا نعلق عليه */
		}
	}

	if ( $pending > 0 ) {
		return array(
			'message' => sprintf( 'رُفعت %d من %d صورة… (يتبع)', $done, count( $files ) ),
			'repeat'  => true,
		);
	}

	$assigned = 0;

	/* الهيرو وقسم القدرات — في خيارات الموقع */
	$options = get_option( QAFESHEH_OPTION_KEY, array() );
	$options = is_array( $options ) ? $options : array();

	if ( empty( $options['hero_image'] ) ) {
		$hero = qafesheh_demo_image_id( $map['slides'][0] );
		if ( $hero ) {
			$options['hero_image'] = $hero;
			++$assigned;
		}
	}

	if ( empty( $options['cap_image'] ) ) {
		$cap = qafesheh_demo_image_id( $map['cap_image'] );
		if ( $cap ) {
			$options['cap_image'] = $cap;
			++$assigned;
		}
	}

	update_option( QAFESHEH_OPTION_KEY, $options );

	/* الصور الرئيسية للعلامات */
	foreach ( (array) $map['companies'] as $slug => $file ) {
		$post_id = qafesheh_import_id( 'companies', $slug );
		$image   = qafesheh_demo_image_id( $file );

		if ( $post_id && $image && ! has_post_thumbnail( $post_id ) ) {
			set_post_thumbnail( $post_id, $image );
			++$assigned;
		}
	}

	/* الصور الرئيسية للمقالات */
	$articles = qafesheh_data_articles();
	foreach ( array_values( (array) $map['articles'] ) as $i => $file ) {
		if ( ! isset( $articles[ $i ] ) ) {
			break;
		}

		$post_id = qafesheh_import_id( 'articles', sanitize_title( $articles[ $i ]['title'] ) );
		$image   = qafesheh_demo_image_id( $file );

		if ( $post_id && $image && ! has_post_thumbnail( $post_id ) ) {
			set_post_thumbnail( $post_id, $image );
			++$assigned;
		}
	}

	/* بانرات الصفحات الداخلية */
	foreach ( (array) $map['banners'] as $section => $file ) {
		$image = qafesheh_demo_image_id( $file );
		if ( ! $image ) {
			continue;
		}

		$key     = qafesheh_sec_key( $section );
		$current = get_option( $key, array() );
		$current = is_array( $current ) ? $current : array();

		if ( empty( $current['arch_image'] ) ) {
			$current['arch_image'] = $image;
			update_option( $key, $current );
			++$assigned;
		}
	}

	do_action( 'litespeed_purge_all' );

	return sprintf( 'جاهز: %d صورة في المكتبة، وعُيّنت %d صورة في أماكنها.', $done, $assigned );
}
