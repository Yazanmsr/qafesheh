<?php
/**
 * أعمدة القوائم والملاحظات الإرشادية.
 * الهدف: من يدخل الداتا يفهم الشاشة من أول نظرة بلا شرحٍ شفوي.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * تعريف الأعمدة لكل نوع.
 *
 * @return array
 */
function qafesheh_columns_map() {
	return array(
		'qaf_company'   => array(
			'q_logo'  => 'الشعار',
			'q_en'    => 'الاسم اللاتيني',
			'q_color' => 'اللون',
			'q_shop'  => 'المتجر',
			'q_order' => 'الترتيب',
		),
		'qaf_service'   => array(
			'q_num'     => 'الرقم',
			'q_summary' => 'الوصف المختصر',
			'q_order'   => 'الترتيب',
		),
		'qaf_branch'    => array(
			'q_city'   => 'المدينة',
			'q_addr'   => 'العنوان',
			'q_phone'  => 'الهاتف',
			'q_hours'  => 'الدوام',
			'q_order'  => 'الترتيب',
		),
		'qaf_job'       => array(
			'q_dept'     => 'القسم',
			'q_location' => 'الموقع',
			'q_type'     => 'الدوام',
		),
		'qaf_complaint' => array(
			'q_ctype'  => 'النوع',
			'q_cname'  => 'المُرسِل',
			'q_cmail'  => 'البريد',
			'q_cphone' => 'الهاتف',
		),
	);
}

/**
 * إضافة الأعمدة.
 */
function qafesheh_register_columns() {
	foreach ( qafesheh_columns_map() as $type => $columns ) {

		add_filter(
			'manage_' . $type . '_posts_columns',
			function ( $existing ) use ( $columns ) {
				$out = array();

				foreach ( $existing as $key => $label ) {
					if ( 'comments' === $key ) {
						continue;
					}
					$out[ $key ] = $label;

					if ( 'title' === $key ) {
						foreach ( $columns as $col_key => $col_label ) {
							$out[ $col_key ] = $col_label;
						}
					}
				}

				return $out;
			}
		);

		add_action(
			'manage_' . $type . '_posts_custom_column',
			'qafesheh_render_column',
			10,
			2
		);
	}
}
add_action( 'admin_init', 'qafesheh_register_columns' );

/**
 * محتوى الأعمدة.
 *
 * @param string $column  اسم العمود.
 * @param int    $post_id معرّف المقال.
 */
function qafesheh_render_column( $column, $post_id ) {
	switch ( $column ) {

		case 'q_logo':
			$logo = absint( get_post_meta( $post_id, 'q_company_logo', true ) );
			if ( ! $logo ) {
				$logo = get_post_thumbnail_id( $post_id );
			}
			if ( $logo ) {
				echo wp_get_attachment_image( $logo, array( 60, 60 ), false, array( 'class' => 'q-col-logo' ) );
			} else {
				echo '<span class="q-col-dash">—</span>';
			}
			break;

		case 'q_en':
			echo esc_html( get_post_meta( $post_id, 'q_company_en', true ) ?: '—' );
			break;

		case 'q_color':
			$color = (string) get_post_meta( $post_id, 'q_company_color', true );
			if ( $color ) {
				printf(
					'<span class="q-col-swatch" style="background:%s"></span><code>%s</code>',
					esc_attr( $color ),
					esc_html( $color )
				);
			} else {
				echo '<span class="q-col-dash">—</span>';
			}
			break;

		case 'q_shop':
			$url = (string) get_post_meta( $post_id, 'q_company_url', true );
			if ( $url ) {
				printf( '<a href="%s" target="_blank" rel="noopener">زيارة ↗</a>', esc_url( $url ) );
			} else {
				echo '<span class="q-col-dash">—</span>';
			}
			break;

		case 'q_num':
			echo '<strong class="q-col-num">' . esc_html( get_post_meta( $post_id, 'q_service_num', true ) ?: '—' ) . '</strong>';
			break;

		case 'q_summary':
			echo esc_html( wp_trim_words( get_the_excerpt( $post_id ), 14, '…' ) );
			break;

		case 'q_city':
			echo esc_html( get_post_meta( $post_id, 'q_branch_city', true ) ?: '—' );
			break;

		case 'q_addr':
			echo esc_html( wp_trim_words( (string) get_post_meta( $post_id, 'q_branch_addr', true ), 10, '…' ) ?: '—' );
			break;

		case 'q_phone':
			$phone = (string) get_post_meta( $post_id, 'q_branch_phone', true );
			echo $phone ? '<span dir="ltr">' . esc_html( $phone ) . '</span>' : '<span class="q-col-dash">—</span>';
			break;

		case 'q_hours':
			echo esc_html( get_post_meta( $post_id, 'q_branch_hours', true ) ?: '—' );
			break;

		case 'q_dept':
			echo esc_html( get_post_meta( $post_id, 'q_job_dept', true ) ?: '—' );
			break;

		case 'q_location':
			echo esc_html( get_post_meta( $post_id, 'q_job_location', true ) ?: '—' );
			break;

		case 'q_type':
			$type = (string) get_post_meta( $post_id, 'q_job_type', true );
			echo $type ? '<span class="q-col-pill">' . esc_html( $type ) . '</span>' : '<span class="q-col-dash">—</span>';
			break;

		case 'q_ctype':
			echo '<span class="q-col-pill">' . esc_html( get_post_meta( $post_id, 'q_c_type', true ) ?: 'رسالة' ) . '</span>';
			break;

		case 'q_cname':
			echo esc_html( get_post_meta( $post_id, 'q_c_name', true ) ?: '—' );
			break;

		case 'q_cmail':
			$mail = (string) get_post_meta( $post_id, 'q_c_email', true );
			echo $mail ? '<a dir="ltr" href="mailto:' . esc_attr( $mail ) . '">' . esc_html( $mail ) . '</a>' : '<span class="q-col-dash">—</span>';
			break;

		case 'q_cphone':
			$phone = (string) get_post_meta( $post_id, 'q_c_phone', true );
			echo $phone ? '<span dir="ltr">' . esc_html( $phone ) . '</span>' : '<span class="q-col-dash">—</span>';
			break;

		case 'q_order':
			$post = get_post( $post_id );
			echo '<span class="q-col-order">' . esc_html( (string) ( $post ? $post->menu_order : 0 ) ) . '</span>';
			break;
	}
}

/**
 * ترتيب القوائم حسب «الترتيب» بدل التاريخ.
 *
 * @param WP_Query $query الاستعلام.
 */
function qafesheh_admin_order( $query ) {
	if ( ! is_admin() || ! $query->is_main_query() ) {
		return;
	}

	$type = $query->get( 'post_type' );

	if ( in_array( $type, array( 'qaf_company', 'qaf_service', 'qaf_branch' ), true ) && ! $query->get( 'orderby' ) ) {
		$query->set( 'orderby', 'menu_order title' );
		$query->set( 'order', 'ASC' );
	}
}
add_action( 'pre_get_posts', 'qafesheh_admin_order' );

/**
 * ملاحظات إرشادية أعلى كل شاشة — قابلة للإخفاء لكل مستخدم.
 */
function qafesheh_screen_notices() {
	$screen = get_current_screen();
	if ( ! $screen ) {
		return;
	}

	$notes = array(
		'edit-qaf_company'   => 'كل علامة تجارية هنا تظهر كبطاقة في الصفحة الرئيسية وفي صفحة «شركاتنا». رتّب البطاقات بتغيير حقل <strong>الترتيب</strong> من «خصائص الصفحة» داخل كل علامة.',
		'edit-qaf_service'   => 'الطريقة الأسرع لإضافة وترتيب الخدمات هي <strong>لوحة الخدمات</strong> — إضافة بسطر واحد وسحبٌ وإفلات للترتيب.',
		'edit-qaf_branch'    => 'الفرع الواحد يُدخل <strong>مرة واحدة فقط</strong> هنا، وتُحدَّد العلامات التي تبيع فيه من صندوق «العلامة التجارية» على اليمين. لا تكرّر الفرع لكل علامة.',
		'edit-qaf_job'       => 'الوظيفة المنتهية: انقلها إلى «مسودة» بدل حذفها، حتى تبقى في الأرشيف الداخلي.',
		'edit-qaf_complaint' => 'هذه الرسائل تصل من نموذج الموقع تلقائياً ولا تُضاف يدوياً. بعد معالجة الرسالة انقلها إلى المهملات لإبقاء القائمة نظيفة.',
		'qaf_branch'         => 'رابط الخريطة: افتح الموقع على خرائط جوجل ← مشاركة ← انسخ الرابط والصقه في حقل «رابط الخريطة».',
		'qaf_company'        => 'الصورة الرئيسية للعلامة هي الخلفية التي تظهر خلف بطاقتها في الرئيسية. الشعار حقل منفصل بالأسفل.',
	);

	$id = $screen->id;
	if ( empty( $notes[ $id ] ) ) {
		return;
	}

	$dismissed = (array) get_user_meta( get_current_user_id(), 'qafesheh_dismissed_notes', true );
	if ( in_array( $id, $dismissed, true ) ) {
		return;
	}

	printf(
		'<div class="notice q-note is-dismissible" data-q-note="%s"><span class="dashicons dashicons-lightbulb"></span><p>%s</p></div>',
		esc_attr( $id ),
		wp_kses_post( $notes[ $id ] )
	);
}
add_action( 'admin_notices', 'qafesheh_screen_notices' );

/**
 * تخزين إخفاء الملاحظة.
 */
function qafesheh_dismiss_note() {
	check_ajax_referer( 'qafesheh_admin', 'nonce' );

	$id = sanitize_key( $_POST['note'] ?? '' );
	if ( ! $id ) {
		wp_send_json_error();
	}

	$user      = get_current_user_id();
	$dismissed = (array) get_user_meta( $user, 'qafesheh_dismissed_notes', true );
	$dismissed = array_values( array_unique( array_merge( $dismissed, array( $id ) ) ) );

	update_user_meta( $user, 'qafesheh_dismissed_notes', $dismissed );
	wp_send_json_success();
}
add_action( 'wp_ajax_qafesheh_dismiss_note', 'qafesheh_dismiss_note' );
