<?php
/**
 * دليل بناء الصفحات — يشرح لكل صفحة ماذا تضع فيها وبأي ترتيب.
 * مكتوب لمن سيُدخل البيانات، لا للمبرمج.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * خطة كل صفحة.
 *
 * @return array
 */
function qafesheh_guide_plan() {
	return array(

		'home' => array(
			'title'  => 'الرئيسية',
			'kind'   => 'elementor',
			'lead'   => 'مبنيّة بـElementor بالكامل عبر خطوة «بناء الرئيسية» في الاستيراد. الترتيب أدناه هو ما يُبنى تلقائياً — عدّل أو أعد الترتيب بالسحب كما تشاء. النصوص تبقى مربوطة بإعدادات الموقع فلا تتكرّر في مكانين.',
			'widgets' => array(
				array( 'QB — سلايدر الهيرو', '٣ شرائح جاهزة بالنصوص الحقيقية. ارفع صورة لكل شريحة (٢٥٦٠px). الشريحة الأولى هي عنصر LCP' ),
				array( 'QB — الأرقام', 'منصّة الأرقام الأربعة، تتداخل مع الهيرو تلقائياً. أرقامها من إعدادات الموقع' ),
				array( 'QB — نبذة المجموعة', 'قسم ٠١ — نصوصه من: إعدادات الموقع ← الرئيسية ← قسم المجموعة' ),
				array( 'QB — رأس قسم', 'قسم ٠٢ على خلفية حبر داكن: «ثلاث علاماتٍ تحت مظلّةٍ واحدة»' ),
				array( 'QB — شبكة الشركات', 'البطاقات الثلاث بألوان علاماتها، تُسحب من قائمة الشركات' ),
				array( 'QB — القدرات التصنيعية', 'قسم ٠٣ — جدول القدرات مقابل صورة المصنع' ),
				array( 'QB — رأس قسم', 'قسم ٠٤: «آخر أخبار المجموعة»' ),
				array( 'QB — المقالات', 'آخر ثلاثة مقالات تلقائياً' ),
				array( 'QB — دعوة تواصل', 'الشريط الأخير قبل الفوتر' ),
			),
		),

		'about' => array(
			'title'  => 'من نحن',
			'kind'   => 'elementor',
			'lead'   => 'ابنِها بـElementor بهذا الترتيب. كل ودجت اسمها يبدأ بـ«QB —» في لوحة الودجات.',
			'widgets' => array(
				array( 'QB — رأس قسم', 'رقم ٠١ + عنوان «مجموعةٌ صناعية أردنية» + فقرة تعريفية' ),
				array( 'Elementor — Text Editor', 'فقرات البداية والتطوّر (المحتوى موجود جاهزاً في الصفحة)' ),
				array( 'QB — الأرقام', 'يسحب الأرقام الأربعة من إعدادات الموقع تلقائياً' ),
				array( 'Elementor — Image', 'صورة المصنع من مكتبة الوسائط' ),
				array( 'QB — رأس قسم', 'رقم ٠٢ + عنوان «ما يهمّنا حقاً»' ),
				array( 'QB — شبكة الشركات', 'العلامات الثلاث كبطاقات' ),
				array( 'QB — دعوة تواصل', 'زر «تواصل معنا» + زر «الوظائف»' ),
			),
		),

		'factory' => array(
			'title'  => 'المصنع',
			'kind'   => 'elementor',
			'lead'   => 'صفحة بصرية بالدرجة الأولى — الصور أهم من النص.',
			'widgets' => array(
				array( 'QB — رأس قسم', 'رقم ٠١ + «مصنعٌ واحد يخدم العلامات الثلاث»' ),
				array( 'Elementor — Image Carousel', 'شريط صور المصنع الأفقي' ),
				array( 'QB — جدول القدرات', 'الموقع · القوى العاملة · خطوط الإنتاج · الدوام · المنشأ' ),
				array( 'Elementor — Text Editor', 'فقرة الجودة' ),
				array( 'QB — دعوة تواصل', 'للاستفسارات التجارية' ),
			),
		),

		'companies' => array(
			'title'  => 'شركاتنا',
			'kind'   => 'elementor',
			'lead'   => 'صفحة قصيرة — البطاقات هي المحتوى.',
			'widgets' => array(
				array( 'QB — رأس قسم', '«ثلاث علاماتٍ تحت مظلّةٍ واحدة»' ),
				array( 'QB — شبكة الشركات', 'ثلاثة أعمدة، مع أزرار «زيارة المتجر»' ),
				array( 'QB — دعوة تواصل', 'اختياري' ),
			),
		),

		'services' => array(
			'title'  => 'الخدمات',
			'kind'   => 'elementor',
			'lead'   => 'الخدمات تُدار من قائمة «الخدمات» ← لوحة الخدمات. هنا نعرضها فقط.',
			'widgets' => array(
				array( 'QB — رأس قسم', 'يقرأ العنوان والفقرة من «إعدادات الخدمات» تلقائياً' ),
				array( 'QB — الخدمات', 'شبكة الخدمات — عدد الأعمدة من «إعدادات الخدمات»' ),
				array( 'QB — دعوة تواصل', 'عنوان ونص من «إعدادات الخدمات»' ),
			),
		),

		'branches' => array(
			'title'  => 'الفروع',
			'kind'   => 'elementor',
			'lead'   => 'الفروع تُدخل مرة واحدة في قائمة «الفروع»، وتُحدَّد علاماتها من صندوق «العلامة التجارية».',
			'widgets' => array(
				array( 'QB — رأس قسم', 'من «إعدادات الفروع»' ),
				array( 'QB — الفروع', 'بطاقات الفروع + فلتر العلامات' ),
				array( 'Elementor — Google Maps', 'خريطة عامة اختيارية' ),
			),
		),

		'careers' => array(
			'title'  => 'الوظائف',
			'kind'   => 'elementor',
			'lead'   => 'الشواغر من قائمة «الوظائف». نموذج التقديم من Contact Form 7.',
			'widgets' => array(
				array( 'QB — رأس قسم', 'من «إعدادات الوظائف»' ),
				array( 'QB — الوظائف', 'قائمة الشواغر المفتوحة' ),
				array( 'Contact Form 7', 'نموذج التقديم مع حقل رفع السيرة الذاتية' ),
			),
		),

		'contact' => array(
			'title'  => 'تواصل معنا',
			'kind'   => 'elementor',
			'lead'   => 'بيانات التواصل تُقرأ من إعدادات الموقع — لا تكتبها يدوياً هنا.',
			'widgets' => array(
				array( 'QB — رأس قسم', '«تواصل مع المجموعة»' ),
				array( 'QB — بطاقات التواصل', 'العنوان · الهاتف · البريد · الدوام — تلقائياً من الإعدادات' ),
				array( 'Contact Form 7', 'نموذج الرسائل' ),
				array( 'Elementor — Google Maps', 'موقع المصنع في سحاب' ),
			),
		),

		'blog' => array(
			'title' => 'المقالات والأخبار',
			'kind'  => 'template',
			'lead'  => 'أرشيف تلقائي — لا يُحرَّر. شكله من: المقالات والأخبار ← إعدادات المقالات.',
			'rows'  => array(
				array( 'رأس الصفحة', 'العنوان والفقرة وصورة البانر', 'إعدادات المقالات ← رأس الصفحة' ),
				array( 'الشبكة', 'عدد الأعمدة والتاريخ وطول المقتطف', 'إعدادات المقالات ← العرض' ),
			),
		),

		'complaints' => array(
			'title' => 'الشكاوى والاقتراحات',
			'kind'  => 'template',
			'lead'  => 'النموذج مبني داخل القالب ويحفظ الرسائل في قائمة «الشكاوى والاقتراحات».',
			'rows'  => array(
				array( 'نصوص الصفحة', 'العنوان والفقرة وأنواع الرسائل ورسالة الشكر', 'الشكاوى ← إعدادات الشكاوى' ),
				array( 'بريد الاستقبال', 'البريد الذي تصله نسخة من كل رسالة', 'الشكاوى ← إعدادات الشكاوى ← النموذج' ),
			),
		),
	);
}

/**
 * صفحة الدليل.
 */
function qafesheh_render_guide_page() {
	if ( ! current_user_can( 'edit_pages' ) ) {
		return;
	}

	$plan = qafesheh_guide_plan();
	?>
	<div class="wrap q-opt q-guide" id="q-guide">

		<?php qafesheh_admin_topbar( 'دليل بناء الصفحات', 'ماذا تضع في كل صفحة، وبأي ترتيب', false ); ?>

		<div class="q-guide__in">

			<div class="q-note q-note--inline">
				<span class="dashicons dashicons-info"></span>
				<p>
					بعض الصفحات <strong>جاهزة تلقائياً</strong> ولا تُفتح بالمحرر — تُعدَّل من صفحة إعداداتها.
					والباقي <strong>تُبنى بـElementor</strong> بترتيب الودجات الموضّح أدناه.
					كل ودجت تبدأ بـ«QB —» مكتوبة خصيصاً لهذا الموقع وتسحب بياناتها تلقائياً.
				</p>
			</div>

			<?php foreach ( $plan as $key => $page ) : ?>
				<?php
				$page_id   = function_exists( 'qafesheh_import_id' ) ? qafesheh_import_id( 'pages', $key ) : 0;
				$is_elem   = ( 'elementor' === $page['kind'] );
				?>
				<section class="q-guide__page">

					<header class="q-guide__head">
						<div>
							<h2><?php echo esc_html( $page['title'] ); ?></h2>
							<span class="q-guide__kind q-guide__kind--<?php echo esc_attr( $page['kind'] ); ?>">
								<?php echo $is_elem ? 'تُبنى بـElementor' : 'جاهزة تلقائياً'; ?>
							</span>
						</div>
						<div class="q-guide__links">
							<?php if ( $page_id ) : ?>
								<a class="q-opt__btn q-opt__btn--ghost" href="<?php echo esc_url( get_permalink( $page_id ) ); ?>" target="_blank" rel="noopener">معاينة</a>
								<?php if ( $is_elem ) : ?>
									<a class="q-opt__btn" href="<?php echo esc_url( admin_url( 'post.php?post=' . $page_id . '&action=elementor' ) ); ?>">افتح بـElementor</a>
								<?php else : ?>
									<a class="q-opt__btn" href="<?php echo esc_url( get_edit_post_link( $page_id ) ); ?>">فتح الصفحة</a>
								<?php endif; ?>
							<?php else : ?>
								<span class="q-guide__missing">الصفحة غير موجودة — شغّل الاستيراد</span>
							<?php endif; ?>
						</div>
					</header>

					<p class="q-guide__lead"><?php echo esc_html( $page['lead'] ); ?></p>

					<?php if ( $is_elem ) : ?>
						<ol class="q-guide__steps">
							<?php foreach ( $page['widgets'] as $i => $widget ) : ?>
								<li>
									<span class="q-guide__n"><?php echo esc_html( str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
									<strong><?php echo esc_html( $widget[0] ); ?></strong>
									<em><?php echo esc_html( $widget[1] ); ?></em>
								</li>
							<?php endforeach; ?>
						</ol>
					<?php else : ?>
						<table class="q-guide__table">
							<thead>
								<tr><th>القسم</th><th>ماذا يحتوي</th><th>من أين تعدّله</th></tr>
							</thead>
							<tbody>
								<?php foreach ( $page['rows'] as $row ) : ?>
									<tr>
										<td><strong><?php echo esc_html( $row[0] ); ?></strong></td>
										<td><?php echo esc_html( $row[1] ); ?></td>
										<td><code><?php echo esc_html( $row[2] ); ?></code></td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					<?php endif; ?>

				</section>
			<?php endforeach; ?>

			<section class="q-guide__page q-guide__page--rules">
				<h2>قواعد إدخال البيانات</h2>
				<ol class="q-guide__rules">
					<li><strong>الفرع يُدخل مرة واحدة.</strong> إذا كان المعرض يبيع أكثر من علامة، اختر كل العلامات في صندوق «العلامة التجارية» بدل تكرار الفرع.</li>
					<li><strong>الصورة الرئيسية إلزامية</strong> لكل مقال وشركة وخدمة — بدونها تظهر البطاقة بخلفية مخطّطة.</li>
					<li><strong>المقاس المطلوب للصور:</strong> بانر ٢٥٦٠×٧٦٠ · بطاقة ١٤٠٠×١٠٠٠ · هيرو ٢٥٦٠×١١٠٠. ارفع أكبر من ذلك ودع ووردبريس يقصّ.</li>
					<li><strong>الوصف المختصر</strong> هو ما يظهر على البطاقة — اكتبه دائماً، سطر أو سطران يكفيان.</li>
					<li><strong>لا تحذف، بل اجعلها مسودة.</strong> الوظيفة المنتهية أو الخدمة الموقوفة تبقى في النظام كمسودة.</li>
					<li><strong>الأرقام العربية</strong> (٠١، ٠٢) هي المعتمدة في أرقام الأقسام والخدمات، حفاظاً على شكل التصميم.</li>
					<li><strong>بيانات التواصل</strong> تُكتب في مكان واحد: إعدادات الموقع ← التواصل. كل الصفحات تقرأ منه.</li>
					<li><strong>بعد أي تعديل كبير</strong> امسح الكاش من LiteSpeed — والثيم يمسحه تلقائياً عند حفظ الإعدادات.</li>
					<li><strong>الحركات تلقائية.</strong> لكل قسم حركة دخول تناسبه، ولا تحتاج ضبطاً في Elementor. لإطفائها كلها: إعدادات الموقع ← متقدّم ← تفعيل حركات الدخول.</li>
					<li><strong>خلفية كل قسم</strong> تُضبط من داخل الودجت نفسها: تاب Style ← نمط القسم. لا تضع خلفية على سكشن Elementor حتى لا تتضاعف المساحات.</li>
				</ol>
			</section>

		</div>
	</div>
	<?php
}
