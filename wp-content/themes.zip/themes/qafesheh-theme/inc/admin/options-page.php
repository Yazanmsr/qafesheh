<?php
/**
 * صفحات الإعدادات — تُبنى بالكامل من المخططات.
 * نفس المُصيّر يخدم إعدادات الموقع العامة وإعدادات كل قسم على حدة.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * الشريط العلوي المشترك لكل صفحات الثيم في لوحة التحكم.
 *
 * @param string $title    العنوان.
 * @param string $subtitle سطر تحته.
 * @param bool   $search   إظهار مربع البحث.
 */
function qafesheh_admin_topbar( $title, $subtitle = '', $search = true ) {
	$logo     = qafesheh_opt_image( 'logo_dark', 'medium' );
	$logo_src = $logo['url'] ? $logo['url'] : qafesheh_url( 'assets/images/logo-qafesheh.png' );
	?>
	<div class="q-opt__top">
		<div class="q-opt__brand">
			<img src="<?php echo esc_url( $logo_src ); ?>" alt="" class="q-opt__logo">
			<div>
				<h1><?php echo esc_html( $title ); ?></h1>
				<span><?php echo esc_html( $subtitle ? $subtitle : qafesheh_opt( 'brand_en', 'QAFESHEH INDUSTRIAL GROUP' ) . ' · EST. ' . qafesheh_opt( 'est_year', '1968' ) ); ?></span>
			</div>
		</div>
		<div class="q-opt__top-actions">
			<?php if ( $search ) : ?>
				<input type="search" id="q-opt-search" class="q-opt__search" placeholder="ابحث عن أي إعداد…" autocomplete="off">
			<?php endif; ?>
			<a class="q-opt__ghost" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener">معاينة الموقع</a>
		</div>
	</div>
	<?php
}

/**
 * صفحة الإعدادات العامة للموقع.
 */
function qafesheh_render_options_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$schema  = qafesheh_options_schema();
	$options = qafesheh_options();
	?>
	<div class="wrap q-opt" id="q-opt">

		<?php qafesheh_admin_topbar( qafesheh_opt( 'brand_ar', 'مجموعة قفيشة الصناعية' ) ); ?>

		<?php settings_errors(); ?>

		<form method="post" action="options.php" class="q-opt__form" id="q-opt-form">
			<?php settings_fields( 'qafesheh_options_group' ); ?>

			<div class="q-opt__layout">

				<nav class="q-opt__rail" aria-label="أقسام الإعدادات">
					<?php
					$first = true;
					foreach ( $schema as $tab_id => $tab ) :
						?>
						<button type="button"
							class="q-opt__tab<?php echo $first ? ' is-active' : ''; ?>"
							data-tab="<?php echo esc_attr( $tab_id ); ?>">
							<span class="dashicons <?php echo esc_attr( $tab['icon'] ?? 'dashicons-admin-generic' ); ?>"></span>
							<span class="q-opt__tab-label"><?php echo esc_html( $tab['label'] ); ?></span>
						</button>
						<?php
						$first = false;
					endforeach;
					?>
				</nav>

				<div class="q-opt__panels">
					<?php
					$first = true;
					foreach ( $schema as $tab_id => $tab ) :
						?>
						<section class="q-opt__panel<?php echo $first ? ' is-active' : ''; ?>" data-panel="<?php echo esc_attr( $tab_id ); ?>">

							<header class="q-opt__panel-head">
								<h2><?php echo esc_html( $tab['label'] ); ?></h2>
								<?php if ( ! empty( $tab['desc'] ) ) : ?>
									<p><?php echo esc_html( $tab['desc'] ); ?></p>
								<?php endif; ?>
							</header>

							<?php
							foreach ( (array) ( $tab['groups'] ?? array() ) as $group ) {
								qafesheh_render_group( $group, $options, QAFESHEH_OPTION_KEY );
							}
							?>

						</section>
						<?php
						$first = false;
					endforeach;
					?>

					<p class="q-opt__empty" id="q-opt-empty" hidden>لا توجد نتائج مطابقة.</p>
				</div>
			</div>

			<?php qafesheh_save_bar(); ?>
		</form>
	</div>
	<?php
}

/**
 * صفحة إعدادات قسم واحد (الخدمات، الشركات، الفروع…).
 *
 * @param string $section معرّف القسم.
 */
function qafesheh_render_section_page( $section ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$sections = qafesheh_sections();
	if ( empty( $sections[ $section ] ) ) {
		return;
	}

	$config  = $sections[ $section ];
	$options = qafesheh_sec_options( $section );
	$key     = qafesheh_sec_key( $section );
	?>
	<div class="wrap q-opt q-opt--section" id="q-opt">

		<?php qafesheh_admin_topbar( 'إعدادات ' . $config['label'], $config['desc'] ?? '', false ); ?>

		<?php settings_errors(); ?>

		<?php if ( ! empty( $config['post_type'] ) ) : ?>
			<div class="q-opt__jump">
				<span class="dashicons <?php echo esc_attr( $config['icon'] ); ?>"></span>
				<p>هذه الصفحة تتحكم بـ<strong>شكل</strong> القسم فقط. لإضافة أو تعديل المحتوى نفسه:</p>
				<a class="q-opt__btn" href="<?php echo esc_url( 'post' === $config['post_type'] ? admin_url( 'edit.php' ) : admin_url( 'edit.php?post_type=' . $config['post_type'] ) ); ?>">
					إدارة <?php echo esc_html( $config['label'] ); ?>
				</a>
			</div>
		<?php endif; ?>

		<form method="post" action="options.php" class="q-opt__form" id="q-opt-form">
			<?php settings_fields( 'qafesheh_sec_group_' . $section ); ?>

			<div class="q-opt__panels q-opt__panels--full">
				<?php
				foreach ( (array) ( $config['groups'] ?? array() ) as $group ) {
					qafesheh_render_group( $group, $options, $key );
				}
				?>
			</div>

			<?php qafesheh_save_bar(); ?>
		</form>
	</div>
	<?php
}

/**
 * مجموعة حقول.
 *
 * @param array  $group      تعريف المجموعة.
 * @param array  $options    القيم.
 * @param string $option_key مفتاح الخيار في قاعدة البيانات.
 */
function qafesheh_render_group( $group, $options, $option_key ) {
	?>
	<div class="q-opt__group">
		<h3 class="q-opt__group-title"><?php echo esc_html( $group['title'] ?? '' ); ?></h3>
		<div class="q-opt__fields">
			<?php
			foreach ( (array) ( $group['fields'] ?? array() ) as $key => $field ) {
				qafesheh_render_field( $key, $field, $options[ $key ] ?? '', $option_key );
			}
			?>
		</div>
	</div>
	<?php
}

/**
 * شريط الحفظ السفلي.
 */
function qafesheh_save_bar() {
	?>
	<div class="q-opt__bar">
		<span class="q-opt__bar-note">التغييرات لا تُحفظ حتى تضغط الزر.</span>
		<button type="submit" class="q-opt__save">حفظ التغييرات</button>
	</div>
	<?php
}

/**
 * رسم حقل واحد حسب نوعه.
 *
 * @param string $key        المفتاح.
 * @param array  $field      تعريف الحقل.
 * @param mixed  $value      القيمة.
 * @param string $option_key مفتاح الخيار في قاعدة البيانات.
 */
function qafesheh_render_field( $key, $field, $value, $option_key = QAFESHEH_OPTION_KEY ) {
	$type  = $field['type'] ?? 'text';
	$label = $field['label'] ?? $key;
	$help  = $field['help'] ?? '';
	$name  = $option_key . '[' . $key . ']';
	$id    = 'q-f-' . sanitize_key( $option_key ) . '-' . $key;
	$wide  = in_array( $type, array( 'textarea', 'image' ), true ) ? ' q-opt__field--wide' : '';

	if ( 'heading' === $type ) {
		printf( '<h4 class="q-opt__subhead">%s</h4>', esc_html( $label ) );
		return;
	}

	printf(
		'<div class="q-opt__field q-opt__field--%s%s" data-search="%s">',
		esc_attr( $type ),
		esc_attr( $wide ),
		esc_attr( mb_strtolower( $label . ' ' . $help . ' ' . $key ) )
	);

	printf( '<label class="q-opt__label" for="%s">%s</label>', esc_attr( $id ), esc_html( $label ) );

	switch ( $type ) {

		case 'textarea':
			printf(
				'<textarea id="%s" name="%s" rows="4" class="q-opt__input">%s</textarea>',
				esc_attr( $id ),
				esc_attr( $name ),
				esc_textarea( (string) $value )
			);
			break;

		case 'toggle':
			printf( '<input type="hidden" name="%s" value="0">', esc_attr( $name ) );
			printf(
				'<label class="q-opt__switch"><input type="checkbox" id="%s" name="%s" value="1" %s><span class="q-opt__slider"></span><span class="q-opt__switch-txt">%s</span></label>',
				esc_attr( $id ),
				esc_attr( $name ),
				checked( 1, (int) $value, false ),
				esc_html( $value ? 'مُفعّل' : 'مُعطّل' )
			);
			break;

		case 'select':
			printf( '<select id="%s" name="%s" class="q-opt__input">', esc_attr( $id ), esc_attr( $name ) );
			foreach ( (array) ( $field['options'] ?? array() ) as $opt_value => $opt_label ) {
				printf(
					'<option value="%s" %s>%s</option>',
					esc_attr( $opt_value ),
					selected( $value, $opt_value, false ),
					esc_html( $opt_label )
				);
			}
			echo '</select>';
			break;

		case 'color':
			printf(
				'<div class="q-opt__color"><input type="text" id="%s" name="%s" value="%s" class="q-opt__input q-color" data-default="%s"></div>',
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr( (string) $value ),
				esc_attr( (string) ( $field['default'] ?? '' ) )
			);
			break;

		case 'image':
			$img = $value ? wp_get_attachment_image_src( absint( $value ), 'medium' ) : false;
			printf( '<div class="q-opt__media" data-target="%s">', esc_attr( $id ) );
			printf(
				'<div class="q-opt__media-preview%s">%s</div>',
				$img ? '' : ' is-empty',
				$img ? '<img src="' . esc_url( $img[0] ) . '" alt="">' : '<span>لا توجد صورة</span>'
			);
			echo '<div class="q-opt__media-actions">';
			echo '<button type="button" class="q-opt__btn q-media-pick">اختر صورة</button>';
			printf(
				'<button type="button" class="q-opt__btn q-opt__btn--ghost q-media-clear"%s>إزالة</button>',
				$img ? '' : ' hidden'
			);
			echo '</div>';
			printf(
				'<input type="hidden" id="%s" name="%s" value="%s" class="q-media-input">',
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr( (string) absint( $value ) )
			);
			echo '</div>';
			break;

		case 'number':
			printf(
				'<input type="number" id="%s" name="%s" value="%s" class="q-opt__input q-opt__input--sm"%s%s step="1">',
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr( (string) $value ),
				isset( $field['min'] ) ? ' min="' . esc_attr( (string) $field['min'] ) . '"' : '',
				isset( $field['max'] ) ? ' max="' . esc_attr( (string) $field['max'] ) . '"' : ''
			);
			break;

		default:
			$html_type = 'text';
			if ( 'url' === $type ) {
				$html_type = 'url';
			} elseif ( 'email' === $type ) {
				$html_type = 'email';
			} elseif ( 'tel' === $type ) {
				$html_type = 'tel';
			}
			printf(
				'<input type="%s" id="%s" name="%s" value="%s" class="q-opt__input" dir="%s">',
				esc_attr( $html_type ),
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr( (string) $value ),
				esc_attr( in_array( $type, array( 'url', 'email', 'tel' ), true ) ? 'ltr' : 'auto' )
			);
	}

	if ( $help ) {
		printf( '<p class="q-opt__help">%s</p>', esc_html( $help ) );
	}

	echo '</div>';
}
