<?php
/**
 * هوية لوحة التحكم: قائمة واحدة باسم المجموعة، ستايل بلون الحبر والذهب،
 * شاشة دخول مطابقة للموقع، ومركز تحكم سريع في الرئيسية.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * أيقونة القائمة — SVG مضمّنة (غرزة خيط).
 *
 * @return string
 */
function qafesheh_menu_icon() {
	$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="black" d="M3 4h14v1.6H3V4zm0 4.2h14v1.6H3V8.2zM3 12.4h9v1.6H3v-1.6zM14.2 11.6l1.2 1.2-1.2 1.2 1.2 1.2H13l-1.2-1.2 1.2-1.2-1.2-1.2h2.2z"/></svg>';
	return 'data:image/svg+xml;base64,' . base64_encode( $svg ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
}

/**
 * أصول لوحة التحكم.
 *
 * @param string $hook الصفحة الحالية.
 */
function qafesheh_admin_assets( $hook ) {
	$css = 'assets/admin/admin.css';
	if ( file_exists( QAFESHEH_DIR . $css ) ) {
		wp_enqueue_style( 'qafesheh-admin', qafesheh_url( $css ), array(), qafesheh_asset_ver( $css ) );
	}

	$is_ours = ( false !== strpos( (string) $hook, 'qafesheh' ) );
	$is_edit = in_array( $hook, array( 'post.php', 'post-new.php' ), true );

	$deps = array( 'jquery' );

	if ( $is_ours || $is_edit ) {
		wp_enqueue_media();
		wp_enqueue_style( 'wp-color-picker' );
		$deps[] = 'wp-color-picker';
	}

	if ( false !== strpos( (string) $hook, 'qafesheh-services' ) ) {
		$deps[] = 'jquery-ui-sortable';
	}

	$js = 'assets/admin/admin.js';
	if ( ! file_exists( QAFESHEH_DIR . $js ) ) {
		return;
	}

	wp_enqueue_script( 'qafesheh-admin', qafesheh_url( $js ), $deps, qafesheh_asset_ver( $js ), true );

	wp_localize_script(
		'qafesheh-admin',
		'QAFESHEH_ADMIN',
		array(
			'ajax'    => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'qafesheh_admin' ),
			'choose'  => 'اختر صورة',
			'use'     => 'استخدم هذه الصورة',
			'remove'  => 'إزالة',
			'saved'   => 'تم الحفظ',
			'error'   => 'حدث خطأ، حاول مجدداً.',
			'confirm' => 'متأكد من نقلها إلى المهملات؟',
			'preview' => home_url( '/' ),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'qafesheh_admin_assets' );

/**
 * توكنز الألوان داخل لوحة التحكم أيضاً — الداشبورد يتبع ألوان الموقع.
 */
function qafesheh_admin_tokens() {
	printf( "<style id=\"qafesheh-admin-tokens\">%s</style>\n", qafesheh_tokens_css() ); // phpcs:ignore WordPress.Security.EscapeOutput
}
add_action( 'admin_head', 'qafesheh_admin_tokens', 3 );

/* -------------------------------------------------------------- شاشة الدخول */

/**
 * ستايل شاشة الدخول.
 */
function qafesheh_login_style() {
	$logo = qafesheh_opt_image( 'logo_dark', 'medium' );
	$url  = $logo['url'] ? $logo['url'] : qafesheh_url( 'assets/images/logo-qafesheh.png' );
	?>
	<style id="qafesheh-login">
		body.login{background:var(--q-ink,#0F0E0C);font-family:var(--q-font-body,system-ui);}
		body.login::before{content:"";position:fixed;inset:0;background:
			repeating-linear-gradient(90deg,rgba(184,145,47,.055) 0 1px,transparent 1px 122px);pointer-events:none;}
		#login{width:380px;padding-top:6vh;position:relative;}
		.login h1 a{background-image:url('<?php echo esc_url( $url ); ?>');background-size:contain;
			width:180px;height:92px;margin:0 auto 6px;}
		.login h1::after{content:"<?php echo esc_attr( qafesheh_opt( 'brand_en', 'QAFESHEH INDUSTRIAL GROUP' ) ); ?>";
			display:block;text-align:center;color:#8A8270;font:600 9.5px/1 var(--q-font-latin,Georgia);
			letter-spacing:.34em;margin-bottom:26px;}
		.login form{background:#16140F;border:1px solid rgba(184,145,47,.28);border-radius:0;
			box-shadow:0 30px 70px rgba(0,0,0,.5);padding:28px 24px 24px;}
		.login form::before{content:"";display:block;width:34px;height:3px;background:var(--q-gold,#B8912F);margin:0 0 20px;}
		.login label{color:#CFC8B8;font-size:12.5px;letter-spacing:.02em;}
		.login input[type=text],.login input[type=password]{background:#0D0B08;border:1px solid #2E2A22;
			color:#F5F1E8;border-radius:0;box-shadow:none;padding:10px 12px;font-size:15px;}
		.login input[type=text]:focus,.login input[type=password]:focus{border-color:var(--q-gold,#B8912F);
			box-shadow:0 0 0 1px rgba(184,145,47,.35);outline:0;}
		.login .button-primary{background:var(--q-gold,#B8912F);border:0;border-radius:0;color:#0F0E0C;
			font-weight:700;letter-spacing:.06em;text-shadow:none;box-shadow:none;height:40px;line-height:38px;
			transition:background .25s ease;width:100%;}
		.login .button-primary:hover{background:#D3A939;}
		.login #nav,.login #backtoblog{text-align:center;}
		.login #nav a,.login #backtoblog a,.login .privacy-policy-link{color:#8A8270;font-size:12px;}
		.login #nav a:hover,.login #backtoblog a:hover{color:var(--q-gold,#B8912F);}
		.login .message,.login .notice{border-inline-start-color:var(--q-gold,#B8912F);background:#16140F;color:#CFC8B8;border-radius:0;}
		.login-footer{display:none;}
	</style>
	<?php
}
add_action( 'login_head', 'qafesheh_login_style', 20 );

/**
 * رابط الشعار في شاشة الدخول يعود للموقع.
 *
 * @return string
 */
function qafesheh_login_url() {
	return home_url( '/' );
}
add_filter( 'login_headerurl', 'qafesheh_login_url' );

/**
 * نص الشعار في شاشة الدخول.
 *
 * @return string
 */
function qafesheh_login_title() {
	return (string) qafesheh_opt( 'brand_ar', 'مجموعة قفيشة الصناعية' );
}
add_filter( 'login_headertext', 'qafesheh_login_title' );

/* ------------------------------------------------------- مركز التحكم السريع */

/**
 * تنظيف لوحة الرئيسية وإضافة مربّع المجموعة.
 */
function qafesheh_dashboard_widgets() {
	global $wp_meta_boxes;

	foreach ( array( 'dashboard_primary', 'dashboard_quick_press', 'dashboard_incoming_links', 'dashboard_plugins' ) as $box ) {
		unset( $wp_meta_boxes['dashboard']['side']['core'][ $box ], $wp_meta_boxes['dashboard']['normal']['core'][ $box ] );
	}

	wp_add_dashboard_widget(
		'qafesheh_control',
		'مركز التحكم — مجموعة قفيشة',
		'qafesheh_render_dashboard_widget'
	);

	/* اجعله أول مربّع */
	$normal = $wp_meta_boxes['dashboard']['normal']['core'] ?? array();
	if ( isset( $normal['qafesheh_control'] ) ) {
		$widget = array( 'qafesheh_control' => $normal['qafesheh_control'] );
		unset( $normal['qafesheh_control'] );
		$wp_meta_boxes['dashboard']['normal']['core'] = array_merge( $widget, $normal );
	}
}
add_action( 'wp_dashboard_setup', 'qafesheh_dashboard_widgets', 99 );

/**
 * محتوى مربّع مركز التحكم.
 */
function qafesheh_render_dashboard_widget() {
	$cards = array(
		array(
			'label' => 'إعدادات الموقع',
			'desc'  => 'الشعارات، الألوان، الخطوط، الهيدر والفوتر',
			'url'   => admin_url( 'admin.php?page=' . QAFESHEH_MENU_SLUG ),
			'icon'  => 'dashicons-admin-generic',
		),
		array(
			'label' => 'محتوى الرئيسية',
			'desc'  => 'الهيرو، الأرقام، القدرات، دعوة التواصل',
			'url'   => admin_url( 'admin.php?page=' . QAFESHEH_MENU_SLUG . '#home' ),
			'icon'  => 'dashicons-admin-home',
		),
		array(
			'label' => 'الشركات',
			'desc'  => 'قفيشة · الجازي · مكارم',
			'url'   => admin_url( 'edit.php?post_type=qaf_company' ),
			'icon'  => 'dashicons-building',
		),
		array(
			'label' => 'الفروع والمعارض',
			'desc'  => 'العناوين وساعات العمل والخرائط',
			'url'   => admin_url( 'edit.php?post_type=qaf_branch' ),
			'icon'  => 'dashicons-store',
		),
		array(
			'label' => 'المقالات والأخبار',
			'desc'  => 'أخبار المجموعة والمقالات',
			'url'   => admin_url( 'edit.php' ),
			'icon'  => 'dashicons-media-document',
		),
		array(
			'label' => 'الوظائف',
			'desc'  => 'الشواغر المفتوحة',
			'url'   => admin_url( 'edit.php?post_type=qaf_job' ),
			'icon'  => 'dashicons-businessperson',
		),
		array(
			'label' => 'الشكاوى والاقتراحات',
			'desc'  => 'الرسائل الواردة من الموقع',
			'url'   => admin_url( 'edit.php?post_type=qaf_complaint' ),
			'icon'  => 'dashicons-megaphone',
		),
		array(
			'label' => 'القوائم',
			'desc'  => 'روابط الهيدر وأعمدة الفوتر',
			'url'   => admin_url( 'nav-menus.php' ),
			'icon'  => 'dashicons-menu-alt',
		),
	);

	echo '<div class="q-dash">';

	printf(
		'<div class="q-dash__head"><span class="q-dash__year">%s</span><p>كل ما تحتاج تعديله في الموقع موجود في هذه البطاقات. اضغط على أي بطاقة للوصول مباشرة.</p></div>',
		esc_html( 'EST. ' . qafesheh_opt( 'est_year', '1968' ) )
	);

	echo '<div class="q-dash__grid">';
	foreach ( $cards as $card ) {
		printf(
			'<a class="q-dash__card" href="%s"><span class="dashicons %s"></span><strong>%s</strong><em>%s</em></a>',
			esc_url( $card['url'] ),
			esc_attr( $card['icon'] ),
			esc_html( $card['label'] ),
			esc_html( $card['desc'] )
		);
	}
	echo '</div>';

	printf(
		'<div class="q-dash__foot"><a class="q-dash__btn" href="%s" target="_blank" rel="noopener">معاينة الموقع</a><span>تطوير QB Studio</span></div>',
		esc_url( home_url( '/' ) )
	);

	echo '</div>';
}

/**
 * قائمة سريعة في شريط الأدمن العلوي.
 *
 * @param WP_Admin_Bar $bar شريط الأدمن.
 */
function qafesheh_admin_bar( $bar ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$bar->add_node(
		array(
			'id'    => 'qafesheh',
			'title' => 'قفيشة',
			'href'  => admin_url( 'admin.php?page=' . QAFESHEH_MENU_SLUG ),
		)
	);

	$items = array(
		'settings' => array( 'إعدادات الموقع', admin_url( 'admin.php?page=' . QAFESHEH_MENU_SLUG ) ),
		'branches' => array( 'الفروع', admin_url( 'edit.php?post_type=qaf_branch' ) ),
		'jobs'     => array( 'الوظائف', admin_url( 'edit.php?post_type=qaf_job' ) ),
		'menus'    => array( 'القوائم', admin_url( 'nav-menus.php' ) ),
	);

	foreach ( $items as $id => $item ) {
		$bar->add_node(
			array(
				'parent' => 'qafesheh',
				'id'     => 'qafesheh-' . $id,
				'title'  => $item[0],
				'href'   => $item[1],
			)
		);
	}
}
add_action( 'admin_bar_menu', 'qafesheh_admin_bar', 80 );

/**
 * تذييل لوحة التحكم.
 *
 * @return string
 */
function qafesheh_admin_footer() {
	return 'موقع مجموعة قفيشة الصناعية — تطوير <strong>QB Studio</strong>';
}
add_filter( 'admin_footer_text', 'qafesheh_admin_footer' );

/**
 * إخفاء رقم إصدار ووردبريس من التذييل.
 *
 * @return string
 */
function qafesheh_hide_version() {
	return '';
}
add_filter( 'update_footer', 'qafesheh_hide_version', 11 );
