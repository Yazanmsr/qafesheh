<?php
/**
 * بنية قوائم لوحة التحكم.
 * كل قسم له قائمته المستقلة — الخدمات وحدها، الشركات وحدها، وهكذا.
 * «مجموعة قفيشة» تبقى للهوية والألوان والاستيراد والدليل فقط.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * القائمة الأم + صفحات الأقسام.
 */
function qafesheh_admin_menu() {

	/* ---------------------------------------------- مجموعة قفيشة */

	add_menu_page(
		'مجموعة قفيشة',
		'مجموعة قفيشة',
		'manage_options',
		QAFESHEH_MENU_SLUG,
		'qafesheh_render_options_page',
		qafesheh_menu_icon(),
		3
	);

	add_submenu_page(
		QAFESHEH_MENU_SLUG,
		'إعدادات الموقع',
		'إعدادات الموقع',
		'manage_options',
		QAFESHEH_MENU_SLUG,
		'qafesheh_render_options_page'
	);

	add_submenu_page(
		QAFESHEH_MENU_SLUG,
		'الاستيراد والإعداد السريع',
		'الاستيراد والإعداد',
		'manage_options',
		'qafesheh-import',
		'qafesheh_render_import_page'
	);

	add_submenu_page(
		QAFESHEH_MENU_SLUG,
		'دليل بناء الصفحات',
		'دليل الصفحات',
		'edit_pages',
		'qafesheh-guide',
		'qafesheh_render_guide_page'
	);

	add_submenu_page(
		QAFESHEH_MENU_SLUG,
		'القوائم',
		'القوائم',
		'edit_theme_options',
		'nav-menus.php'
	);

	/* ---------------------------------------------- إعدادات كل قسم */

	foreach ( qafesheh_sections() as $section => $config ) {

		$parent = 'post' === $config['post_type']
			? 'edit.php'
			: 'edit.php?post_type=' . $config['post_type'];

		add_submenu_page(
			$parent,
			'إعدادات ' . $config['label'],
			$config['menu'],
			'manage_options',
			'qafesheh-sec-' . $section,
			function () use ( $section ) {
				qafesheh_render_section_page( $section );
			}
		);
	}

	/* ---------------------------------------------- لوحة الخدمات السريعة */

	add_submenu_page(
		'edit.php?post_type=qaf_service',
		'لوحة الخدمات',
		'لوحة الخدمات',
		'edit_posts',
		'qafesheh-services',
		'qafesheh_render_services_manager'
	);
}
add_action( 'admin_menu', 'qafesheh_admin_menu', 9 );

/**
 * ترتيب قائمة الخدمات: لوحة الخدمات أولاً.
 */
function qafesheh_reorder_services_submenu() {
	global $submenu;

	$parent = 'edit.php?post_type=qaf_service';

	if ( empty( $submenu[ $parent ] ) ) {
		return;
	}

	$manager = null;
	foreach ( $submenu[ $parent ] as $index => $item ) {
		if ( isset( $item[2] ) && 'qafesheh-services' === $item[2] ) {
			$manager = $item;
			unset( $submenu[ $parent ][ $index ] );
			break;
		}
	}

	if ( $manager ) {
		array_unshift( $submenu[ $parent ], $manager );
		$submenu[ $parent ] = array_values( $submenu[ $parent ] );
	}
}
add_action( 'admin_menu', 'qafesheh_reorder_services_submenu', 999 );

/**
 * فاصل بصري بين قوائم المجموعة وبقية ووردبريس.
 *
 * @param array $menu_order الترتيب.
 * @return array
 */
function qafesheh_menu_order( $menu_order ) {
	return $menu_order;
}
add_filter( 'custom_menu_order', '__return_true' );
add_filter( 'menu_order', 'qafesheh_menu_order' );
