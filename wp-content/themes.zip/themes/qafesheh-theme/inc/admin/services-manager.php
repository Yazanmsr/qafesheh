<?php
/**
 * لوحة الخدمات — إضافة بسطر واحد، تعديل مباشر، وترتيب بالسحب.
 * الهدف: من يدخل الداتا لا يفتح شاشة تحرير كاملة لكل خدمة.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * جلب كل الخدمات مرتّبة.
 *
 * @return WP_Post[]
 */
function qafesheh_services_all() {
	return get_posts(
		array(
			'post_type'      => 'qaf_service',
			'post_status'    => array( 'publish', 'draft' ),
			'posts_per_page' => -1,
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
		)
	);
}

/**
 * رسم لوحة الخدمات.
 */
function qafesheh_render_services_manager() {
	if ( ! current_user_can( 'edit_posts' ) ) {
		return;
	}

	$services = qafesheh_services_all();
	?>
	<div class="wrap q-opt q-svc" id="q-svc">

		<?php qafesheh_admin_topbar( 'لوحة الخدمات', 'أضف خدمة بسطر واحد · اسحب لإعادة الترتيب · عدّل مباشرةً بلا فتح صفحة', false ); ?>

		<div class="q-svc__in">

			<div class="q-note q-note--inline">
				<span class="dashicons dashicons-lightbulb"></span>
				<p>
					اكتب اسم الخدمة ووصفها المختصر واضغط «إضافة» — تُنشأ فوراً.
					لترتيب الخدمات على الموقع اسحب الخدمة من المقبض <span class="q-svc__handle-demo">⠿</span> إلى مكانها.
					للوصف الطويل والصورة اضغط «تحرير كامل».
				</p>
			</div>

			<form class="q-svc__add" id="q-svc-add">
				<div class="q-svc__add-row">
					<label class="q-svc__f q-svc__f--num">
						<span>الرقم</span>
						<input type="text" name="num" placeholder="٠٩" maxlength="4">
					</label>
					<label class="q-svc__f q-svc__f--title">
						<span>اسم الخدمة</span>
						<input type="text" name="title" placeholder="مثال: التغليف والتجهيز التصديري" required>
					</label>
					<label class="q-svc__f q-svc__f--exc">
						<span>الوصف المختصر</span>
						<input type="text" name="excerpt" placeholder="سطر أو سطران يظهران على البطاقة">
					</label>
					<button type="submit" class="q-opt__save q-svc__add-btn">إضافة</button>
				</div>
				<span class="q-svc__add-note" id="q-svc-add-note"></span>
			</form>

			<div class="q-svc__head">
				<span class="q-svc__col-handle"></span>
				<span class="q-svc__col-num">الرقم</span>
				<span class="q-svc__col-title">اسم الخدمة</span>
				<span class="q-svc__col-exc">الوصف المختصر</span>
				<span class="q-svc__col-act">إجراءات</span>
			</div>

			<div class="q-svc__list" id="q-svc-list">
				<?php foreach ( $services as $service ) : ?>
					<?php qafesheh_service_row( $service ); ?>
				<?php endforeach; ?>
			</div>

			<?php if ( ! $services ) : ?>
				<p class="q-svc__empty" id="q-svc-empty">
					لا توجد خدمات بعد. أضف أول خدمة من الأعلى، أو شغّل
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=qafesheh-import' ) ); ?>">الاستيراد السريع</a>
					لتحصل على ٨ خدمات جاهزة.
				</p>
			<?php endif; ?>

			<div class="q-svc__foot">
				<span id="q-svc-status">كل التعديلات تُحفظ فور الضغط على «حفظ» في السطر.</span>
				<a class="q-opt__ghost q-opt__ghost--dark" href="<?php echo esc_url( admin_url( 'admin.php?page=qafesheh-sec-services' ) ); ?>">إعدادات صفحة الخدمات</a>
			</div>

		</div>
	</div>
	<?php
}

/**
 * سطر خدمة واحد.
 *
 * @param WP_Post $service الخدمة.
 */
function qafesheh_service_row( $service ) {
	$num   = (string) get_post_meta( $service->ID, 'q_service_num', true );
	$draft = ( 'draft' === $service->post_status );
	?>
	<div class="q-svc__row<?php echo $draft ? ' is-draft' : ''; ?>" data-id="<?php echo esc_attr( (string) $service->ID ); ?>">
		<span class="q-svc__handle" title="اسحب لإعادة الترتيب">⠿</span>

		<input type="text" class="q-svc__in-num" value="<?php echo esc_attr( $num ); ?>" maxlength="4" aria-label="الرقم">
		<input type="text" class="q-svc__in-title" value="<?php echo esc_attr( $service->post_title ); ?>" aria-label="اسم الخدمة">
		<input type="text" class="q-svc__in-exc" value="<?php echo esc_attr( $service->post_excerpt ); ?>" aria-label="الوصف المختصر">

		<span class="q-svc__act">
			<button type="button" class="q-opt__btn q-svc__save">حفظ</button>
			<a class="q-opt__btn q-opt__btn--ghost" href="<?php echo esc_url( get_edit_post_link( $service->ID ) ); ?>">تحرير كامل</a>
			<button type="button" class="q-opt__btn q-opt__btn--ghost q-svc__trash" title="نقل إلى المهملات">حذف</button>
		</span>

		<span class="q-svc__flag"><?php echo $draft ? 'مسودة' : ''; ?></span>
	</div>
	<?php
}

/* ========================================================== AJAX */

/**
 * التحقق المشترك.
 */
function qafesheh_svc_guard() {
	check_ajax_referer( 'qafesheh_admin', 'nonce' );

	if ( ! current_user_can( 'edit_posts' ) ) {
		wp_send_json_error( array( 'message' => 'صلاحيات غير كافية.' ), 403 );
	}
}

/**
 * إضافة خدمة.
 */
function qafesheh_svc_add() {
	qafesheh_svc_guard();

	$title = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );
	if ( ! $title ) {
		wp_send_json_error( array( 'message' => 'اكتب اسم الخدمة أولاً.' ), 400 );
	}

	$last  = get_posts(
		array(
			'post_type'      => 'qaf_service',
			'posts_per_page' => 1,
			'orderby'        => 'menu_order',
			'order'          => 'DESC',
			'fields'         => 'ids',
		)
	);
	$order = $last ? ( (int) get_post( $last[0] )->menu_order + 1 ) : 1;

	$id = wp_insert_post(
		array(
			'post_type'    => 'qaf_service',
			'post_status'  => 'publish',
			'post_title'   => $title,
			'post_excerpt' => sanitize_text_field( wp_unslash( $_POST['excerpt'] ?? '' ) ),
			'menu_order'   => $order,
		),
		true
	);

	if ( is_wp_error( $id ) ) {
		wp_send_json_error( array( 'message' => 'تعذّرت الإضافة.' ), 500 );
	}

	$num = sanitize_text_field( wp_unslash( $_POST['num'] ?? '' ) );
	if ( $num ) {
		update_post_meta( $id, 'q_service_num', $num );
	}

	ob_start();
	qafesheh_service_row( get_post( $id ) );

	wp_send_json_success(
		array(
			'html'    => ob_get_clean(),
			'message' => 'أُضيفت «' . $title . '».',
		)
	);
}
add_action( 'wp_ajax_qafesheh_svc_add', 'qafesheh_svc_add' );

/**
 * حفظ سطر.
 */
function qafesheh_svc_save() {
	qafesheh_svc_guard();

	$id = absint( $_POST['id'] ?? 0 );
	if ( ! $id || 'qaf_service' !== get_post_type( $id ) ) {
		wp_send_json_error( array( 'message' => 'خدمة غير موجودة.' ), 404 );
	}
	if ( ! current_user_can( 'edit_post', $id ) ) {
		wp_send_json_error( array( 'message' => 'صلاحيات غير كافية.' ), 403 );
	}

	wp_update_post(
		array(
			'ID'           => $id,
			'post_title'   => sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) ),
			'post_excerpt' => sanitize_text_field( wp_unslash( $_POST['excerpt'] ?? '' ) ),
		)
	);

	$num = sanitize_text_field( wp_unslash( $_POST['num'] ?? '' ) );
	if ( '' === $num ) {
		delete_post_meta( $id, 'q_service_num' );
	} else {
		update_post_meta( $id, 'q_service_num', $num );
	}

	do_action( 'litespeed_purge_all' );

	wp_send_json_success( array( 'message' => 'حُفظت.' ) );
}
add_action( 'wp_ajax_qafesheh_svc_save', 'qafesheh_svc_save' );

/**
 * حفظ الترتيب.
 */
function qafesheh_svc_order() {
	qafesheh_svc_guard();

	$ids = isset( $_POST['ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['ids'] ) ) : array();

	$order = 0;
	foreach ( $ids as $id ) {
		if ( ! $id || 'qaf_service' !== get_post_type( $id ) ) {
			continue;
		}
		++$order;
		wp_update_post(
			array(
				'ID'         => $id,
				'menu_order' => $order,
			)
		);
	}

	do_action( 'litespeed_purge_all' );

	wp_send_json_success( array( 'message' => 'حُفظ الترتيب الجديد.' ) );
}
add_action( 'wp_ajax_qafesheh_svc_order', 'qafesheh_svc_order' );

/**
 * نقل إلى المهملات.
 */
function qafesheh_svc_trash() {
	qafesheh_svc_guard();

	$id = absint( $_POST['id'] ?? 0 );
	if ( ! $id || 'qaf_service' !== get_post_type( $id ) ) {
		wp_send_json_error( array( 'message' => 'خدمة غير موجودة.' ), 404 );
	}
	if ( ! current_user_can( 'delete_post', $id ) ) {
		wp_send_json_error( array( 'message' => 'صلاحيات غير كافية.' ), 403 );
	}

	wp_trash_post( $id );

	wp_send_json_success( array( 'message' => 'نُقلت إلى المهملات.' ) );
}
add_action( 'wp_ajax_qafesheh_svc_trash', 'qafesheh_svc_trash' );
