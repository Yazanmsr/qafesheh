<?php
/**
 * مسار التصيير الموحّد — منقول حرفياً من لوحات التصميم المعتمدة.
 * كل قسم يُرسم هنا مرة واحدة، ويستدعيه القالب وودجت Elementor معاً.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * عمود العنوان الجانبي: لوحة الرقم + التسمية + الشريط الذهبي.
 *
 * @param string $num   رقم القسم (٠١).
 * @param string $label التسمية تحته.
 */
function qafesheh_rail( $num, $label = '' ) {
	?>
	<div class="q-rail">
		<?php if ( $num ) : ?>
			<div class="q-rail__plate" data-q-anim="fade"><?php echo esc_html( $num ); ?></div>
		<?php endif; ?>
		<?php if ( $label ) : ?>
			<div class="q-rail__label" data-q-anim="rise" data-q-d="1"><?php echo esc_html( $label ); ?></div>
		<?php endif; ?>
		<span class="q-rail__bar" data-q-anim="draw" data-q-d="2"></span>
	</div>
	<?php
}

/**
 * سهم التصميم.
 *
 * @param int $size الحجم.
 */
function qafesheh_arrow( $size = 15 ) {
	printf(
		'<svg width="%1$d" height="%1$d" viewBox="0 0 24 24" fill="none" stroke-width="1.6" aria-hidden="true"><path d="M19 12H5M11 18l-6-6 6-6"/></svg>',
		(int) $size
	);
}

/**
 * رابط بخط سفلي ذهبي وسهم.
 *
 * @param string $text  النص.
 * @param string $url   الرابط.
 * @param string $class كلاس إضافي.
 */
function qafesheh_arrow_link( $text, $url, $class = '' ) {
	if ( ! $text ) {
		return;
	}
	printf( '<a class="q-link %s" href="%s"><span>%s</span>', esc_attr( $class ), esc_url( $url ? $url : '#' ), esc_html( $text ) );
	qafesheh_arrow( 15 );
	echo '</a>';
}

/**
 * التوقيع المزدوج: شريط ٣px وخط شعري تحته.
 *
 * @param string $class كلاس إضافي.
 */
function qafesheh_signature( $class = '' ) {
	printf(
		'<div class="q-sig %s" aria-hidden="true"><span class="q-sig__bar" data-q-anim="draw" data-q-d="3"></span><span class="q-sig__line" data-q-anim="draw" data-q-d="4"></span></div>',
		esc_attr( $class )
	);
}

/**
 * رأس المحتوى: عنوان كبير + فقرة جانبية + رابط اختياري.
 *
 * @param array $args المعطيات.
 */
function qafesheh_render_section_head( $args = array() ) {
	$args = wp_parse_args(
		$args,
		array(
			'num'      => '',
			'label'    => '',
			'title'    => '',
			'text'     => '',
			'link_txt' => '',
			'link_url' => '',
			'align'    => 'start',
			'class'    => '',
		)
	);

	if ( ! $args['title'] && ! $args['num'] ) {
		return;
	}
	?>
	<div class="q-lay <?php echo esc_attr( $args['class'] ); ?>">
		<?php qafesheh_rail( $args['num'], $args['label'] ); ?>

		<div class="q-lay__body">
			<div class="q-hd">
				<?php if ( $args['title'] ) : ?>
					<h2 class="q-hd__title q-lines"><?php echo esc_html( $args['title'] ); ?></h2>
				<?php endif; ?>

				<?php if ( $args['text'] ) : ?>
					<p class="q-hd__text" data-q-anim="rise" data-q-d="2"><?php echo esc_html( $args['text'] ); ?></p>
				<?php elseif ( $args['link_txt'] ) : ?>
					<div data-q-anim="rise" data-q-d="2">
						<?php qafesheh_arrow_link( $args['link_txt'], $args['link_url'] ); ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<?php
}

/**
 * منصّة الأرقام.
 *
 * @param array $args المعطيات.
 */
function qafesheh_render_stats( $args = array() ) {
	$args  = wp_parse_args( $args, array( 'class' => 'q-stats' ) );
	$stats = qafesheh_stats();

	if ( ! $stats ) {
		return;
	}
	?>
	<div class="<?php echo esc_attr( $args['class'] ); ?>" data-q-stagger>
		<?php foreach ( $stats as $stat ) : ?>
			<div class="q-plinth__item">
				<div class="q-plinth__num"><?php echo wp_kses( qafesheh_split_num( $stat['num'] ), array( 'i' => array() ) ); ?></div>
				<div class="q-plinth__lbl"><?php echo esc_html( $stat['lbl'] ); ?></div>
			</div>
		<?php endforeach; ?>
	</div>
	<?php
}

/**
 * فصل اللاحقة (+) عن الرقم لتلوينها كما في التصميم.
 *
 * @param string $value القيمة.
 * @return string
 */
function qafesheh_split_num( $value ) {
	$value = (string) $value;

	if ( preg_match( '/^([0-9\x{0660}-\x{0669}]+)(.*)$/u', $value, $m ) ) {
		$suffix = trim( $m[2] );
		return esc_html( $m[1] ) . ( '' !== $suffix ? '<i>' . esc_html( $suffix ) . '</i>' : '' );
	}

	return esc_html( $value );
}

/**
 * سلايدر الهيرو.
 *
 * @param array $args slides, autoplay, arrows, dots.
 */
function qafesheh_render_hero_slider( $args = array() ) {
	if ( function_exists( 'qafesheh_force_slider_assets' ) && ! is_admin() ) {
		qafesheh_force_slider_assets();
	}

	$args = wp_parse_args(
		$args,
		array(
			'slides'   => array(),
			'autoplay' => 6500,
			'arrows'   => true,
			'dots'     => true,
			'plinth'   => true,
		)
	);

	$slides = array_values( array_filter( (array) $args['slides'] ) );

	if ( ! $slides ) {
		$slides = qafesheh_data_slides();
	}

	$total = count( $slides );
	$auto  = max( 0, (int) $args['autoplay'] );
	$multi = ( $total > 1 );
	?>
	<section class="q-hs<?php echo $multi ? '' : ' is-single'; ?>" data-q-slider
		data-autoplay="<?php echo esc_attr( (string) $auto ); ?>"
		tabindex="0" role="region" aria-roledescription="سلايدر" aria-label="عرض المجموعة">

		<div class="q-hs__track" data-q-track>
			<?php foreach ( $slides as $i => $slide ) : ?>
				<?php
				$slide = wp_parse_args(
					(array) $slide,
					array(
						'image'   => 0,
						'eyebrow' => '',
						'title'   => '',
						'text'    => '',
						'b1'      => '',
						'b1_url'  => '',
						'b2'      => '',
						'b2_url'  => '',
					)
				);

				$src = '';
				if ( $slide['image'] ) {
					$img = wp_get_attachment_image_src( absint( $slide['image'] ), 'qafesheh_hero' );
					$src = $img ? $img[0] : '';
				}
				?>
				<article class="q-hero q-hs__slide<?php echo 0 === $i ? ' is-on' : ''; ?>"
					aria-hidden="<?php echo 0 === $i ? 'false' : 'true'; ?>">

					<div class="q-hero__media">
						<?php if ( $src ) : ?>
							<img src="<?php echo esc_url( $src ); ?>" alt=""
								<?php echo 0 === $i ? 'fetchpriority="high" decoding="async"' : 'loading="lazy" decoding="async"'; ?>>
						<?php else : ?>
							<span class="q-ph q-ph--dark" aria-hidden="true"></span>
						<?php endif; ?>
					</div>

					<span class="q-hero__scrim" aria-hidden="true"></span>
					<span class="q-hero__grid" aria-hidden="true"></span>

					<div class="q-wrap q-hero__in">
						<div class="q-hero__body">
							<?php if ( $slide['eyebrow'] ) : ?>
								<span class="q-eyebrow"><?php echo esc_html( $slide['eyebrow'] ); ?></span>
							<?php endif; ?>

							<?php if ( $slide['title'] ) : ?>
								<h1 class="q-hero__title">
									<?php
									foreach ( qafesheh_lines( $slide['title'] ) as $line ) {
										printf( '<span><i>%s</i></span>', esc_html( $line ) );
									}
									?>
								</h1>
							<?php endif; ?>

							<div class="q-sig" aria-hidden="true">
								<span class="q-sig__bar"></span>
								<span class="q-sig__line"></span>
							</div>

							<?php if ( $slide['text'] ) : ?>
								<p class="q-hero__text"><?php echo esc_html( $slide['text'] ); ?></p>
							<?php endif; ?>

							<div class="q-btns q-hero__btns">
								<?php
								qafesheh_button( $slide['b1'], $slide['b1_url'], 'solid' );
								qafesheh_button( $slide['b2'], $slide['b2_url'], 'ghost' );
								?>
							</div>
						</div>
					</div>
				</article>
			<?php endforeach; ?>
		</div>

		<?php if ( $args['plinth'] ) : ?>
			<?php qafesheh_render_stats( array( 'class' => 'q-plinth' ) ); ?>
		<?php endif; ?>

		<?php if ( $multi ) : ?>
			<div class="q-hs__bar">
				<div class="q-wrap q-hs__bar-in">
					<div class="q-hs__count" aria-live="polite">
						<b data-q-now><?php echo esc_html( qafesheh_pad_ar( 1 ) ); ?></b>
						<i aria-hidden="true"></i>
						<span><?php echo esc_html( qafesheh_pad_ar( $total ) ); ?></span>
					</div>

					<?php if ( $args['dots'] ) : ?>
						<div class="q-hs__dots" role="tablist" aria-label="الشرائح">
							<?php for ( $d = 0; $d < $total; $d++ ) : ?>
								<button type="button" role="tab"
									class="q-hs__dot<?php echo 0 === $d ? ' is-on' : ''; ?>"
									aria-selected="<?php echo 0 === $d ? 'true' : 'false'; ?>"
									aria-label="<?php echo esc_attr( sprintf( 'الشريحة %d', $d + 1 ) ); ?>"></button>
							<?php endfor; ?>
						</div>
					<?php endif; ?>

					<?php if ( $args['arrows'] ) : ?>
						<div class="q-hs__nav">
							<button type="button" class="q-hs__arrow" data-q-prev aria-label="السابق">→</button>
							<button type="button" class="q-hs__arrow" data-q-next aria-label="التالي">←</button>
						</div>
					<?php endif; ?>
				</div>
			</div>

			<div class="q-hs__prog" aria-hidden="true"><span data-q-bar></span></div>
		<?php endif; ?>
	</section>
	<?php
}

/**
 * تقسيم نص إلى أسطر نظيفة.
 *
 * @param string $text النص.
 * @return array
 */
function qafesheh_lines( $text ) {
	$lines = preg_split( '/\r\n|\r|\n/', (string) $text );
	$lines = array_map( 'trim', (array) $lines );

	return array_values( array_filter( $lines, 'strlen' ) );
}

/**
 * رقم عربي من خانتين.
 *
 * @param int $n الرقم.
 * @return string
 */
function qafesheh_pad_ar( $n ) {
	$s = ( $n < 10 ? '0' : '' ) . (int) $n;
	return strtr( $s, array( '0' => '٠', '1' => '١', '2' => '٢', '3' => '٣', '4' => '٤', '5' => '٥', '6' => '٦', '7' => '٧', '8' => '٨', '9' => '٩' ) );
}

/**
 * ٠١ — بيان المجموعة.
 *
 * @param array $args المعطيات.
 */
function qafesheh_render_about( $args = array() ) {
	$args = wp_parse_args(
		$args,
		array(
			'num'   => '٠١',
			'label' => 'المجموعة',
			'link'  => qafesheh_opt( 'about_link', '' ),
			'btn'   => 'نبذة كاملة عن المجموعة',
		)
	);

	$title = qafesheh_opt( 'about_title', '' );
	$col1  = qafesheh_opt( 'about_col1', '' );
	$col2  = qafesheh_opt( 'about_col2', '' );

	if ( ! $title && ! $col1 ) {
		qafesheh_render_placeholder( 'نصوص هذا القسم من: إعدادات الموقع ← الرئيسية ← قسم المجموعة.' );
		return;
	}
	?>
	<div class="q-lay">
		<?php qafesheh_rail( $args['num'], $args['label'] ); ?>

		<div class="q-lay__body">
			<?php if ( $title ) : ?>
				<h2 class="q-stmt__title q-lines"><?php echo esc_html( $title ); ?></h2>
			<?php endif; ?>

			<div class="q-stmt__cols" data-q-stagger>
				<?php if ( $col1 ) : ?>
					<p><?php echo esc_html( $col1 ); ?></p>
				<?php endif; ?>
				<?php if ( $col2 ) : ?>
					<p><?php echo esc_html( $col2 ); ?></p>
				<?php endif; ?>
			</div>

			<?php if ( $args['link'] && $args['btn'] ) : ?>
				<div data-q-anim="rise" data-q-d="3">
					<?php qafesheh_arrow_link( $args['btn'], $args['link'] ); ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
	<?php
}

/**
 * ٠٢ — بطاقات العلامات.
 *
 * @param array $args المعطيات.
 */
function qafesheh_render_companies( $args = array() ) {
	$args = wp_parse_args(
		$args,
		array(
			'cols'      => qafesheh_sec( 'companies', 'cols', '3' ),
			'show_shop' => qafesheh_sec( 'companies', 'show_shop', 1 ),
			'shop_txt'  => qafesheh_sec( 'companies', 'shop_txt', 'زيارة المتجر' ),
		)
	);

	$companies = qafesheh_companies();
	if ( ! $companies ) {
		return;
	}

	$cols = ( '2' === (string) $args['cols'] ) ? ' q-brands--2' : '';
	?>
	<div class="q-brands<?php echo esc_attr( $cols ); ?>" data-q-stagger="curtain">
		<?php foreach ( $companies as $i => $company ) : ?>
			<?php
			$image = $company['image'] ? wp_get_attachment_image_src( (int) $company['image'], 'qafesheh_card' ) : false;
			$logo  = $company['logo'] ? wp_get_attachment_image_src( (int) $company['logo'], 'medium' ) : false;
			$color = $company['color'] ? $company['color'] : 'var(--q-gold)';
			$specs = qafesheh_company_specs( $company );
			?>
			<article class="q-brand" style="--brand:<?php echo esc_attr( $color ); ?>">

				<div class="q-brand__media">
					<div class="q-brand__frame">
						<?php if ( $image ) : ?>
							<img src="<?php echo esc_url( $image[0] ); ?>" alt="" loading="lazy" decoding="async">
						<?php else : ?>
							<span class="q-ph q-ph--dark" aria-hidden="true"></span>
						<?php endif; ?>
					</div>
				</div>

				<div class="q-brand__body">
					<div class="q-brand__head">
						<div class="q-brand__names">
							<h3 class="q-brand__title"><?php echo esc_html( $company['title'] ); ?></h3>
							<?php if ( $company['en'] ) : ?>
								<span class="q-brand__en"><?php echo esc_html( $company['en'] ); ?></span>
							<?php endif; ?>
						</div>

						<?php if ( $logo ) : ?>
							<span class="q-brand__mark"><img src="<?php echo esc_url( $logo[0] ); ?>" alt="" loading="lazy"></span>
						<?php endif; ?>
					</div>

					<span class="q-brand__bar" aria-hidden="true"></span>

					<?php if ( $company['tag'] ) : ?>
						<p class="q-brand__text"><?php echo esc_html( $company['tag'] ); ?></p>
					<?php endif; ?>

					<?php if ( $specs ) : ?>
						<dl class="q-brand__specs">
							<?php foreach ( $specs as $spec ) : ?>
								<div class="q-brand__spec">
									<dt><?php echo esc_html( $spec[0] ); ?></dt>
									<dd><?php echo esc_html( $spec[1] ); ?></dd>
								</div>
							<?php endforeach; ?>
						</dl>
					<?php endif; ?>

					<div class="q-brand__foot">
						<?php qafesheh_arrow_link( 'صفحة العلامة', $company['url'] ); ?>
						<span class="q-brand__idx"><?php echo esc_html( sprintf( '%02d', $i + 1 ) ); ?></span>
					</div>
				</div>

				<?php if ( $args['show_shop'] && $company['shop'] ) : ?>
					<a class="q-brand__shop" href="<?php echo esc_url( $company['shop'] ); ?>" target="_blank" rel="noopener">
						<?php echo esc_html( $args['shop_txt'] ); ?> ↗
					</a>
				<?php endif; ?>
			</article>
		<?php endforeach; ?>
	</div>
	<?php
}

/**
 * صفوف المواصفات في بطاقة العلامة.
 *
 * @param array $company بيانات العلامة.
 * @return array
 */
function qafesheh_company_specs( $company ) {
	$specs = array();

	if ( ! empty( $company['cats'] ) ) {
		$specs[] = array( 'التخصص', $company['cats'] );
	}
	if ( ! empty( $company['markets'] ) ) {
		$specs[] = array( 'الأسواق', $company['markets'] );
	}
	if ( ! empty( $company['points'] ) ) {
		$specs[] = array( 'نقاط البيع', $company['points'] );
	}

	return $specs;
}

/**
 * ٠٣ — القدرات التصنيعية.
 *
 * @param array $args المعطيات.
 */
function qafesheh_render_caps_split( $args = array() ) {
	$args = wp_parse_args(
		$args,
		array(
			'num'    => '٠٣',
			'label'  => 'القدرات التصنيعية',
			'title'  => qafesheh_opt( 'cap_title', '' ),
			'image'  => absint( qafesheh_opt( 'cap_image', 0 ) ),
			'thumbs' => true,
		)
	);

	$src = '';
	if ( $args['image'] ) {
		$img = wp_get_attachment_image_src( $args['image'], 'qafesheh_card' );
		$src = $img ? $img[0] : '';
	}
	?>
	<div class="q-lay">
		<?php qafesheh_rail( $args['num'], $args['label'] ); ?>

		<div class="q-lay__body">
			<?php if ( $args['title'] ) : ?>
				<h2 class="q-hd__title q-lines"><?php echo esc_html( $args['title'] ); ?></h2>
			<?php endif; ?>

			<div class="q-caps">
				<div class="q-caps__img q-frame" data-q-anim="zoom">
					<div class="q-frame__in">
						<?php if ( $src ) : ?>
							<img src="<?php echo esc_url( $src ); ?>" alt="" loading="lazy" decoding="async">
						<?php else : ?>
							<span class="q-ph" aria-hidden="true"></span>
						<?php endif; ?>
					</div>
				</div>

				<div>
					<?php qafesheh_render_capabilities(); ?>
				</div>
			</div>
		</div>
	</div>
	<?php
}

/**
 * جدول القدرات وحده.
 *
 * @param array $args المعطيات.
 */
function qafesheh_render_capabilities( $args = array() ) {
	$args = wp_parse_args( $args, array( 'title' => '' ) );

	$rows = array();
	for ( $i = 1; $i <= 5; $i++ ) {
		$key   = qafesheh_opt( 'cap_r' . $i . '_k', '' );
		$value = qafesheh_opt( 'cap_r' . $i . '_v', '' );
		if ( $key || $value ) {
			$rows[] = array( $key, $value );
		}
	}

	if ( ! $rows ) {
		return;
	}
	?>
	<?php if ( $args['title'] ) : ?>
		<h3 class="q-hd__title q-lines"><?php echo esc_html( $args['title'] ); ?></h3>
	<?php endif; ?>

	<dl class="q-caps__list" data-q-stagger="rows">
		<?php foreach ( $rows as $row ) : ?>
			<div class="q-caps__row">
				<dt><?php echo esc_html( $row[0] ); ?></dt>
				<dd><?php echo esc_html( $row[1] ); ?></dd>
			</div>
		<?php endforeach; ?>
	</dl>
	<?php
}

/**
 * ٠٤ — شبكة الخدمات بخطوط شعرية.
 *
 * @param array $args المعطيات.
 */
function qafesheh_render_services( $args = array() ) {
	$args = wp_parse_args(
		$args,
		array(
			'cols'     => qafesheh_sec( 'services', 'cols', '3' ),
			'limit'    => (int) qafesheh_sec( 'services', 'per_page', 12 ),
			'show_num' => qafesheh_sec( 'services', 'show_num', 1 ),
		)
	);

	$services = get_posts(
		array(
			'post_type'      => 'qaf_service',
			'posts_per_page' => (int) $args['limit'],
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
		)
	);

	if ( ! $services ) {
		qafesheh_render_placeholder( 'لم تُضف خدمات بعد. أضفها من: الخدمات ← لوحة الخدمات.' );
		return;
	}

	$cols = in_array( (string) $args['cols'], array( '2', '4' ), true ) ? ' q-svcs--' . $args['cols'] : '';
	?>
	<div class="q-svcs<?php echo esc_attr( $cols ); ?>" data-q-stagger="cells">
		<?php foreach ( $services as $i => $service ) : ?>
			<?php $num = (string) get_post_meta( $service->ID, 'q_service_num', true ); ?>
			<a class="q-svc" href="<?php echo esc_url( get_permalink( $service ) ); ?>">
				<div class="q-svc__top">
					<?php qafesheh_service_icon( $i ); ?>
					<?php if ( $args['show_num'] ) : ?>
						<span class="q-svc__idx"><?php echo esc_html( $num ? $num : sprintf( '%02d', $i + 1 ) ); ?></span>
					<?php endif; ?>
				</div>
				<h3 class="q-svc__title"><?php echo esc_html( get_the_title( $service ) ); ?></h3>
				<p class="q-svc__text"><?php echo esc_html( wp_trim_words( get_the_excerpt( $service ), 18, '…' ) ); ?></p>
			</a>
		<?php endforeach; ?>
	</div>
	<?php
}

/**
 * أيقونات الخدمات — نفس رسومات التصميم.
 *
 * @param int $i الفهرس.
 */
function qafesheh_service_icon( $i ) {
	$paths = array(
		'<path d="M4 21V9l6 4V9l6 4V5l4 2v14z"/>',
		'<path d="M6 3l6 4 6-4v7a6 6 0 01-12 0z"/><path d="M9 14l-2 7M15 14l2 7"/>',
		'<rect x="3" y="7" width="13" height="10"/><path d="M16 10h3l2 3v4h-5z"/><circle cx="7" cy="18" r="1.8"/><circle cx="18" cy="18" r="1.8"/>',
		'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.8 2.6 15.2 0 18M12 3c-2.6 2.8-2.6 15.2 0 18"/>',
		'<path d="M4 7h16v13H4z"/><path d="M9 7V4h6v3"/><path d="M4 12h16"/>',
		'<path d="M12 3l2.6 5.6L21 9.4l-4.5 4.3 1.1 6.3L12 17l-5.6 3 1.1-6.3L3 9.4l6.4-.8z"/>',
		'<path d="M3 20h18M6 20V10M12 20V4M18 20v-7"/>',
		'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
	);

	$path = $paths[ $i % count( $paths ) ];

	printf(
		'<svg class="q-svc__icon" viewBox="0 0 24 24" aria-hidden="true">%s</svg>',
		$path // phpcs:ignore WordPress.Security.EscapeOutput
	);
}

/**
 * ٠٥ — صفوف المعايير.
 *
 * @param array $args rows.
 */
function qafesheh_render_standards( $args = array() ) {
	$args = wp_parse_args( $args, array( 'rows' => array() ) );

	$rows = (array) $args['rows'];

	if ( ! $rows ) {
		$rows = qafesheh_data_standards();
	}
	?>
	<div class="q-std" data-q-stagger="rows">
		<?php foreach ( $rows as $row ) : ?>
			<div class="q-std__row">
				<h3 class="q-std__title"><?php echo esc_html( $row['title'] ); ?></h3>
				<p class="q-std__text"><?php echo esc_html( $row['text'] ); ?></p>
			</div>
		<?php endforeach; ?>
	</div>
	<?php
}

/**
 * ٠٦ — صفوف المقالات الأفقية.
 *
 * @param array $args المعطيات.
 */
function qafesheh_render_articles( $args = array() ) {
	$args = wp_parse_args(
		$args,
		array(
			'limit'  => 3,
			'layout' => 'rows',
			'cols'   => qafesheh_sec( 'articles', 'cols', '3' ),
		)
	);

	$posts = get_posts(
		array(
			'post_type'           => 'post',
			'posts_per_page'      => (int) $args['limit'],
			'ignore_sticky_posts' => true,
		)
	);

	if ( ! $posts ) {
		qafesheh_render_placeholder( 'لم تُنشر مقالات بعد. أضفها من: المقالات والأخبار ← إضافة مقال.' );
		return;
	}

	if ( 'cards' === $args['layout'] ) {
		$cols = in_array( (string) $args['cols'], array( '2', '4' ), true ) ? ' q-cards--' . $args['cols'] : '';
		?>
		<div class="q-cards<?php echo esc_attr( $cols ); ?>" data-q-stagger>
			<?php foreach ( $posts as $post ) { qafesheh_card( $post ); } ?>
		</div>
		<?php
		return;
	}
	?>
	<div class="q-arts" data-q-stagger="rows">
		<?php foreach ( $posts as $post ) : ?>
			<?php
			$thumb = get_the_post_thumbnail_url( $post, 'qafesheh_thumb' );
			$terms = get_the_category( $post->ID );
			$cat   = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
			?>
			<a class="q-art" href="<?php echo esc_url( get_permalink( $post ) ); ?>">
				<div class="q-art__frame q-frame">
					<div class="q-frame__in">
						<?php if ( $thumb ) : ?>
							<img src="<?php echo esc_url( $thumb ); ?>" alt="" loading="lazy" decoding="async">
						<?php else : ?>
							<span class="q-ph" aria-hidden="true"></span>
						<?php endif; ?>
					</div>
				</div>

				<div class="q-art__body">
					<h3 class="q-art__title"><?php echo esc_html( get_the_title( $post ) ); ?></h3>
					<p class="q-art__text"><?php echo esc_html( wp_trim_words( get_the_excerpt( $post ), 14, '…' ) ); ?></p>
				</div>

				<span class="q-art__meta">
					<b><?php echo esc_html( get_the_date( 'j M Y', $post ) ); ?></b><?php echo $cat ? ' — ' . esc_html( $cat ) : ''; ?>
				</span>

				<span class="q-art__more">اقرأ <?php qafesheh_arrow( 14 ); ?></span>
			</a>
		<?php endforeach; ?>
	</div>
	<?php
}

/**
 * ٠٧ — الفروع بنصفين: نص وخريطة.
 *
 * @param array $args المعطيات.
 */
function qafesheh_render_branches_split( $args = array() ) {
	$args = wp_parse_args(
		$args,
		array(
			'num'   => '٠٧',
			'label' => 'الفروع',
			'title' => '',
			'limit' => 5,
			'image' => 0,
		)
	);

	$branches = get_posts(
		array(
			'post_type'      => 'qaf_branch',
			'posts_per_page' => (int) $args['limit'],
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
		)
	);

	if ( ! $branches ) {
		return;
	}

	$total = wp_count_posts( 'qaf_branch' );
	$title = $args['title'] ? $args['title'] : sprintf( 'شبكةُ فروعٍ في %s', qafesheh_opt( 'c_address', 'المملكة' ) );

	$src = '';
	if ( $args['image'] ) {
		$img = wp_get_attachment_image_src( absint( $args['image'] ), 'qafesheh_card' );
		$src = $img ? $img[0] : '';
	}
	unset( $total );
	?>
	<div class="q-split">
		<div class="q-split__txt">
			<div class="q-split__rail">
				<div class="q-rail__plate" data-q-anim="fade"><?php echo esc_html( $args['num'] ); ?></div>
				<div>
					<span class="q-rail__label" data-q-anim="rise" data-q-d="1"><?php echo esc_html( $args['label'] ); ?></span>
					<span class="q-rail__bar" data-q-anim="draw" data-q-d="2"></span>
				</div>
			</div>

			<h2 class="q-split__title q-lines"><?php echo esc_html( $title ); ?></h2>

			<div class="q-blist" data-q-stagger="rows">
				<?php foreach ( $branches as $branch ) : ?>
					<?php
					$city  = (string) get_post_meta( $branch->ID, 'q_branch_city', true );
					$hours = (string) get_post_meta( $branch->ID, 'q_branch_hours', true );
					?>
					<a class="q-blist__row" href="<?php echo esc_url( get_permalink( $branch ) ); ?>">
						<span class="q-blist__name">
							<?php echo esc_html( get_the_title( $branch ) ); ?>
							<?php echo $city ? ' — ' . esc_html( $city ) : ''; ?>
						</span>
						<span class="q-blist__hours"><?php echo esc_html( $hours ); ?></span>
					</a>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="q-split__media">
			<?php if ( $src ) : ?>
				<img src="<?php echo esc_url( $src ); ?>" alt="" loading="lazy" decoding="async">
			<?php else : ?>
				<span class="q-ph" aria-hidden="true"></span>
			<?php endif; ?>
		</div>
	</div>
	<?php
}

/**
 * بطاقات الفروع الكاملة.
 *
 * @param array $args المعطيات.
 */
function qafesheh_render_branches( $args = array() ) {
	$args = wp_parse_args(
		$args,
		array(
			'cols'        => qafesheh_sec( 'branches', 'cols', '3' ),
			'limit'       => -1,
			'show_filter' => qafesheh_sec( 'branches', 'show_filter', 1 ),
			'show_map'    => qafesheh_sec( 'branches', 'show_map', 1 ),
			'show_hours'  => qafesheh_sec( 'branches', 'show_hours', 1 ),
			'brand'       => '',
		)
	);

	$query = array(
		'post_type'      => 'qaf_branch',
		'posts_per_page' => (int) $args['limit'],
		'orderby'        => 'menu_order title',
		'order'          => 'ASC',
	);

	if ( $args['brand'] ) {
		$query['tax_query'] = array(
			array(
				'taxonomy' => 'qaf_brand',
				'field'    => 'slug',
				'terms'    => sanitize_title( $args['brand'] ),
			),
		);
	}

	$branches = get_posts( $query );

	if ( ! $branches ) {
		qafesheh_render_placeholder( 'لم تُضف فروع بعد. أضفها من: الفروع ← إضافة فرع.' );
		return;
	}

	$brands = get_terms(
		array(
			'taxonomy'   => 'qaf_brand',
			'hide_empty' => true,
		)
	);

	$cols = ( '2' === (string) $args['cols'] ) ? ' q-branches--2' : '';
	?>

	<?php if ( $args['show_filter'] && ! is_wp_error( $brands ) && count( $brands ) > 1 ) : ?>
		<div class="q-filter" data-q-filter data-q-anim="rise">
			<button type="button" class="q-filter__b is-on" data-brand="">كل الفروع</button>
			<?php foreach ( $brands as $brand ) : ?>
				<button type="button" class="q-filter__b" data-brand="<?php echo esc_attr( $brand->slug ); ?>">
					<?php echo esc_html( $brand->name ); ?>
				</button>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<div class="q-branches<?php echo esc_attr( $cols ); ?>" data-q-branches data-q-stagger>
		<?php foreach ( $branches as $branch ) : ?>
			<?php
			$terms = wp_get_object_terms( $branch->ID, 'qaf_brand', array( 'fields' => 'all' ) );
			$slugs = is_wp_error( $terms ) ? array() : wp_list_pluck( $terms, 'slug' );
			$city  = (string) get_post_meta( $branch->ID, 'q_branch_city', true );
			$addr  = (string) get_post_meta( $branch->ID, 'q_branch_addr', true );
			$phone = (string) get_post_meta( $branch->ID, 'q_branch_phone', true );
			$hours = (string) get_post_meta( $branch->ID, 'q_branch_hours', true );
			$map   = (string) get_post_meta( $branch->ID, 'q_branch_map', true );
			?>
			<article class="q-branch" data-brands="<?php echo esc_attr( implode( ' ', $slugs ) ); ?>">
				<div class="q-branch__head">
					<h3 class="q-branch__title"><?php echo esc_html( get_the_title( $branch ) ); ?></h3>
					<?php if ( $city ) : ?>
						<span class="q-branch__city"><?php echo esc_html( $city ); ?></span>
					<?php endif; ?>
				</div>

				<?php if ( $addr ) : ?>
					<p class="q-branch__addr"><?php echo esc_html( $addr ); ?></p>
				<?php endif; ?>

				<dl class="q-branch__meta">
					<?php if ( $phone ) : ?>
						<div>
							<dt>الهاتف</dt>
							<dd><a dir="ltr" href="<?php echo esc_url( qafesheh_tel_href( $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></dd>
						</div>
					<?php endif; ?>
					<?php if ( $args['show_hours'] && $hours ) : ?>
						<div><dt>الدوام</dt><dd><?php echo esc_html( $hours ); ?></dd></div>
					<?php endif; ?>
				</dl>

				<?php if ( ! is_wp_error( $terms ) && $terms ) : ?>
					<div class="q-branch__brands">
						<?php foreach ( $terms as $term ) : ?>
							<span class="q-branch__pill"><?php echo esc_html( $term->name ); ?></span>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>

				<?php if ( $args['show_map'] && $map ) : ?>
					<div class="q-branch__map">
						<?php qafesheh_arrow_link( 'الموقع على الخريطة', $map ); ?>
					</div>
				<?php endif; ?>
			</article>
		<?php endforeach; ?>
	</div>
	<?php
}

/**
 * الوظائف.
 *
 * @param array $args المعطيات.
 */
function qafesheh_render_jobs( $args = array() ) {
	$args = wp_parse_args( $args, array( 'limit' => -1 ) );

	$jobs = get_posts(
		array(
			'post_type'      => 'qaf_job',
			'posts_per_page' => (int) $args['limit'],
		)
	);

	if ( ! $jobs ) {
		qafesheh_render_placeholder( 'لا توجد شواغر منشورة حالياً.' );
		return;
	}

	$btn = qafesheh_sec( 'jobs', 'apply_txt', 'قدّم على الوظيفة' );
	?>
	<div class="q-jobs" data-q-stagger="rows">
		<?php foreach ( $jobs as $job ) : ?>
			<?php
			$dept     = (string) get_post_meta( $job->ID, 'q_job_dept', true );
			$location = (string) get_post_meta( $job->ID, 'q_job_location', true );
			$type     = (string) get_post_meta( $job->ID, 'q_job_type', true );
			?>
			<article class="q-job">
				<div>
					<h3 class="q-job__title">
						<a href="<?php echo esc_url( get_permalink( $job ) ); ?>"><?php echo esc_html( get_the_title( $job ) ); ?></a>
					</h3>
					<div class="q-job__meta">
						<?php if ( $dept ) : ?><span><?php echo esc_html( $dept ); ?></span><?php endif; ?>
						<?php if ( $location ) : ?><span><?php echo esc_html( $location ); ?></span><?php endif; ?>
						<?php if ( $type ) : ?><span><?php echo esc_html( $type ); ?></span><?php endif; ?>
					</div>
				</div>

				<p class="q-job__text"><?php echo esc_html( wp_trim_words( get_the_excerpt( $job ), 16, '…' ) ); ?></p>

				<?php qafesheh_arrow_link( $btn, get_permalink( $job ) ); ?>
			</article>
		<?php endforeach; ?>
	</div>
	<?php
}

/**
 * بطاقات التواصل — تُعرض كصفوف مواصفات.
 */
function qafesheh_render_contact_cards() {
	$rows = array(
		array( 'العنوان', qafesheh_opt( 'c_address', '' ), '' ),
		array( 'الهاتف', qafesheh_opt( 'c_phone', '' ), qafesheh_tel_href( qafesheh_opt( 'c_phone', '' ) ) ),
		array( 'البريد الإلكتروني', qafesheh_opt( 'c_email', '' ), 'mailto:' . qafesheh_opt( 'c_email', '' ) ),
		array( 'الدوام', qafesheh_opt( 'cap_r4_v', '٧:٠٠ — ١٩:٠٠' ), '' ),
	);
	?>
	<dl class="q-caps__list" data-q-stagger="rows">
		<?php foreach ( $rows as $row ) : ?>
			<?php if ( ! $row[1] ) { continue; } ?>
			<div class="q-caps__row">
				<dt><?php echo esc_html( $row[0] ); ?></dt>
				<dd>
					<?php if ( $row[2] ) : ?>
						<a dir="auto" href="<?php echo esc_url( $row[2] ); ?>"><?php echo esc_html( $row[1] ); ?></a>
					<?php else : ?>
						<?php echo esc_html( $row[1] ); ?>
					<?php endif; ?>
				</dd>
			</div>
		<?php endforeach; ?>
	</dl>
	<?php
}

/**
 * دعوة التواصل — شريط داكن بعرض الشاشة.
 *
 * @param array $args المعطيات.
 */
function qafesheh_render_cta( $args = array() ) {
	$args = wp_parse_args(
		$args,
		array(
			'title' => qafesheh_opt( 'cta_title', '' ),
			'text'  => qafesheh_opt( 'cta_text', '' ),
			'b1_t'  => qafesheh_opt( 'cta_b1_t', '' ),
			'b1_u'  => qafesheh_opt( 'cta_b1_u', '' ),
			'b2_t'  => qafesheh_opt( 'cta_b2_t', '' ),
			'b2_u'  => qafesheh_opt( 'cta_b2_u', '' ),
		)
	);

	if ( ! $args['title'] ) {
		return;
	}
	?>
	<section class="q-cta">
		<span class="q-cta__grid" aria-hidden="true"></span>
		<div class="q-wrap q-cta__in">
			<div class="q-cta__txt">
				<span class="q-cta__bar" aria-hidden="true" data-q-anim="draw"></span>
				<h2 class="q-cta__title q-lines"><?php echo esc_html( $args['title'] ); ?></h2>
				<?php if ( $args['text'] ) : ?>
					<p class="q-cta__text" data-q-anim="rise" data-q-d="3"><?php echo esc_html( $args['text'] ); ?></p>
				<?php endif; ?>
			</div>

			<div class="q-btns" data-q-anim="rise" data-q-d="4">
				<?php
				qafesheh_button( $args['b1_t'], $args['b1_u'], 'solid' );
				qafesheh_button( $args['b2_t'], $args['b2_u'], 'ghost' );
				?>
			</div>
		</div>
	</section>
	<?php
}

/**
 * رسالة للمحررين فقط.
 *
 * @param string $message النص.
 */
function qafesheh_render_placeholder( $message ) {
	if ( ! current_user_can( 'edit_posts' ) ) {
		return;
	}
	printf( '<p class="q-editor-note">%s</p>', esc_html( $message ) );
}
