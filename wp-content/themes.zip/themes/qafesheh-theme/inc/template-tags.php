<?php
/**
 * دوال العرض المشتركة — مسار تصيير واحد تستخدمه القوالب وودجات Elementor معاً.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * شعار المجموعة.
 *
 * @param string $variant dark|light.
 * @param string $class   كلاس إضافي.
 */
function qafesheh_logo( $variant = 'dark', $class = 'q-logo' ) {
	$key      = ( 'light' === $variant ) ? 'logo_light' : 'logo_dark';
	$image    = qafesheh_opt_image( $key, 'medium' );
	$fallback = qafesheh_url( 'assets/images/logo-qafesheh.png' );
	$src      = $image['url'] ? $image['url'] : $fallback;
	$brand    = qafesheh_opt( 'brand_ar', 'مجموعة قفيشة الصناعية' );
	?>
	<a class="<?php echo esc_attr( $class ); ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
		<span class="q-logo__mark">
			<img src="<?php echo esc_url( $src ); ?>" alt="<?php echo esc_attr( $brand ); ?>" width="120" height="120" decoding="async">
		</span>
		<span class="q-logo__txt">
			<strong><?php echo esc_html( $brand ); ?></strong>
			<em><?php echo esc_html( qafesheh_opt( 'brand_en', 'QAFESHEH INDUSTRIAL GROUP' ) ); ?></em>
		</span>
	</a>
	<?php
}

/**
 * قائمة بديلة إذا لم يُنشئ العميل قائمة بعد — حتى لا يظهر الهيدر فارغاً.
 */
function qafesheh_nav_fallback() {
	$pages = get_pages(
		array(
			'sort_column' => 'menu_order,post_title',
			'number'      => 8,
		)
	);

	echo '<ul class="q-nav__list">';

	if ( $pages ) {
		foreach ( $pages as $page ) {
			printf(
				'<li class="menu-item"><a href="%s">%s</a></li>',
				esc_url( get_permalink( $page ) ),
				esc_html( get_the_title( $page ) )
			);
		}
	} else {
		printf(
			'<li class="menu-item"><a href="%s">الرئيسية</a></li>',
			esc_url( home_url( '/' ) )
		);
	}

	echo '</ul>';
}

/**
 * بانر الصفحات الداخلية — نمط النجمة الثمانية كما في التصميم.
 *
 * @param array $args title, eyebrow, text, image, crumbs.
 */
function qafesheh_banner( $args = array() ) {
	$args = wp_parse_args(
		$args,
		array(
			'title'   => get_the_title(),
			'eyebrow' => '',
			'text'    => '',
			'image'   => 0,
			'crumbs'  => true,
		)
	);

	$url = '';
	if ( $args['image'] ) {
		$src = wp_get_attachment_image_src( absint( $args['image'] ), 'qafesheh_banner' );
		$url = $src ? $src[0] : '';
	}
	?>
	<section class="q-banner">
		<?php if ( $url ) : ?>
			<div class="q-banner__img" aria-hidden="true">
				<img src="<?php echo esc_url( $url ); ?>" alt="" fetchpriority="high" decoding="async">
			</div>
		<?php endif; ?>

		<span class="q-banner__star" aria-hidden="true"></span>

		<div class="q-wrap q-banner__in">
			<div class="q-banner__row">
				<div class="q-banner__col">
					<?php if ( $args['crumbs'] ) { qafesheh_breadcrumb(); } ?>
					<h1 class="q-banner__title q-lines"><?php echo esc_html( $args['title'] ); ?></h1>
				</div>

				<?php if ( $args['text'] ) : ?>
					<p class="q-banner__text" data-q-anim="rise" data-q-d="3"><?php echo esc_html( $args['text'] ); ?></p>
				<?php endif; ?>
			</div>
		</div>
	</section>
	<?php
}

/**
 * مسار التنقّل.
 */
function qafesheh_breadcrumb() {
	if ( is_front_page() ) {
		return;
	}

	$items = array();
	$items[] = '<a href="' . esc_url( home_url( '/' ) ) . '">الرئيسية</a>';

	if ( is_singular() ) {
		$type = get_post_type_object( get_post_type() );
		if ( $type && ! empty( $type->has_archive ) ) {
			$link = get_post_type_archive_link( get_post_type() );
			if ( $link ) {
				$items[] = '<a href="' . esc_url( $link ) . '">' . esc_html( $type->labels->name ) . '</a>';
			}
		}
		$items[] = '<span>' . esc_html( wp_trim_words( get_the_title(), 8, '…' ) ) . '</span>';
	} elseif ( is_post_type_archive() || is_home() ) {
		$items[] = '<span>' . esc_html( post_type_archive_title( '', false ) ?: 'المقالات والأخبار' ) . '</span>';
	} elseif ( is_tax() || is_category() || is_tag() ) {
		$items[] = '<span>' . esc_html( single_term_title( '', false ) ) . '</span>';
	} elseif ( is_search() ) {
		$items[] = '<span>' . esc_html__( 'نتائج البحث', 'qafesheh' ) . '</span>';
	} elseif ( is_404() ) {
		$items[] = '<span>' . esc_html__( 'الصفحة غير موجودة', 'qafesheh' ) . '</span>';
	}

	printf(
		'<nav class="q-crumb" aria-label="%s" data-q-anim="rise">%s</nav>',
		esc_attr__( 'مسار التنقّل', 'qafesheh' ),
		implode( '<i aria-hidden="true">✦</i>', $items ) // phpcs:ignore WordPress.Security.EscapeOutput
	);
}

/**
 * روابط التواصل الاجتماعي — أيقونات التصميم.
 *
 * @param string $class كلاس الحاوية.
 */
function qafesheh_social( $class = 'q-social' ) {
	$icons = array(
		'instagram' => '<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1"/>',
		'facebook'  => '<path d="M14 8h3V4h-3c-2.2 0-4 1.8-4 4v2H7v4h3v6h4v-6h3l1-4h-4V8z"/>',
		'youtube'   => '<rect x="2" y="5" width="20" height="14" rx="4"/><path d="M10 9l5 3-5 3z"/>',
		'whatsapp'  => '<path d="M21 11.5a8.5 8.5 0 01-12.6 7.4L3 21l2.2-5.2A8.5 8.5 0 1121 11.5z"/>',
	);

	$links = array(
		'instagram' => array( 'إنستغرام', qafesheh_opt( 's_instagram', '' ) ),
		'facebook'  => array( 'فيسبوك', qafesheh_opt( 's_facebook', '' ) ),
		'youtube'   => array( 'يوتيوب', qafesheh_opt( 's_youtube', '' ) ),
	);

	$whats = qafesheh_opt( 's_whatsapp', '' );
	if ( $whats ) {
		$links['whatsapp'] = array( 'واتساب', 'https://wa.me/' . preg_replace( '/\D/', '', $whats ) );
	}

	$out = '';
	foreach ( $links as $id => $link ) {
		if ( empty( $link[1] ) ) {
			continue;
		}
		$out .= sprintf(
			'<a class="q-social__a" href="%s" target="_blank" rel="noopener noreferrer"><span class="screen-reader-text">%s</span><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke-width="1.3" aria-hidden="true">%s</svg></a>',
			esc_url( $link[1] ),
			esc_html( $link[0] ),
			$icons[ $id ]
		);
	}

	if ( $out ) {
		printf( '<div class="%s">%s</div>', esc_attr( $class ), $out ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

/**
 * رابط هاتف قابل للنقر.
 *
 * @param string $phone الرقم.
 * @return string
 */
function qafesheh_tel_href( $phone ) {
	return 'tel:' . preg_replace( '/[^0-9+]/', '', (string) $phone );
}

/**
 * زر بنمط التصميم.
 *
 * @param string $text    النص.
 * @param string $url     الرابط.
 * @param string $variant solid|ghost|light.
 */
function qafesheh_button( $text, $url, $variant = 'solid' ) {
	if ( ! $text ) {
		return;
	}
	printf(
		'<a class="q-btn q-btn--%s" href="%s">%s</a>',
		esc_attr( $variant ),
		esc_url( $url ? $url : '#' ),
		esc_html( $text )
	);
}

/**
 * بطاقة مقال/عنصر أرشيف.
 *
 * @param int|WP_Post $post المقال.
 */
function qafesheh_card( $post = null ) {
	$post = get_post( $post );
	if ( ! $post ) {
		return;
	}

	$thumb = get_the_post_thumbnail_url( $post, 'qafesheh_card' );
	?>
	<article class="q-card">
		<a href="<?php echo esc_url( get_permalink( $post ) ); ?>">
			<div class="q-card__media">
				<?php if ( $thumb ) : ?>
					<img src="<?php echo esc_url( $thumb ); ?>" alt="" loading="lazy" decoding="async">
				<?php else : ?>
					<span class="q-ph" aria-hidden="true"></span>
				<?php endif; ?>
			</div>
			<div class="q-card__body">
				<span class="q-card__date"><?php echo esc_html( get_the_date( 'j M Y', $post ) ); ?></span>
				<h3 class="q-card__title"><?php echo esc_html( get_the_title( $post ) ); ?></h3>
				<p class="q-card__text"><?php echo esc_html( wp_trim_words( get_the_excerpt( $post ), 18, '…' ) ); ?></p>
				<span class="q-card__more">اقرأ المزيد <?php qafesheh_arrow( 14 ); ?></span>
			</div>
		</a>
	</article>
	<?php
}

/**
 * ترقيم الصفحات بنمط التصميم.
 */
function qafesheh_pagination() {
	$links = paginate_links(
		array(
			'type'      => 'array',
			'prev_text' => '‹ السابق',
			'next_text' => 'التالي ›',
		)
	);

	if ( ! $links ) {
		return;
	}

	echo '<nav class="q-pager" aria-label="ترقيم الصفحات">';
	foreach ( $links as $link ) {
		echo wp_kses_post( $link );
	}
	echo '</nav>';
}

/**
 * الشركات الثلاث للعرض في الرئيسية — من نوع المحتوى، وإلا قيم افتراضية.
 *
 * @return array
 */
function qafesheh_companies() {
	$posts = get_posts(
		array(
			'post_type'      => 'qaf_company',
			'posts_per_page' => 6,
			'orderby'        => 'menu_order',
			'order'          => 'ASC',
		)
	);

	if ( $posts ) {
		$out = array();
		foreach ( $posts as $post ) {
			$out[] = array(
				'markets' => (string) get_post_meta( $post->ID, 'q_company_markets', true ),
				'points'  => (string) get_post_meta( $post->ID, 'q_company_points', true ),
				'title' => get_the_title( $post ),
				'en'    => (string) get_post_meta( $post->ID, 'q_company_en', true ),
				'tag'   => (string) get_post_meta( $post->ID, 'q_company_tag', true ),
				'color' => (string) get_post_meta( $post->ID, 'q_company_color', true ),
				'logo'  => absint( get_post_meta( $post->ID, 'q_company_logo', true ) ),
				'url'   => get_permalink( $post ),
				'shop'  => (string) get_post_meta( $post->ID, 'q_company_url', true ),
				'image' => get_post_thumbnail_id( $post ),
			);
		}
		return $out;
	}

	/* افتراضي حتى يُدخل العميل الشركات */
	return array(
		array(
			'title' => 'قفيشة',
			'en'    => 'QAFESHEH',
			'tag'   => 'الفروة الأردنية الأصيلة',
			'cats'  => 'فروات · بشوت · صدريات',
			'markets' => 'الأردن · الخليج',
			'points'  => 'المصنع + معرض وسط البلد',
			'color' => qafesheh_opt( 'c_qafesheh', '#C9A227' ),
			'logo'  => 0,
			'url'   => '#',
			'shop'  => '',
			'image' => 0,
		),
		array(
			'title' => 'الجازي',
			'en'    => 'AL JAZI',
			'tag'   => 'البشوت والعباءات الرجالية',
			'cats'  => 'أثواب · قفطان · أشمغة',
			'markets' => 'الأردن · الخليج',
			'points'  => 'وسط البلد + طبربور',
			'color' => qafesheh_opt( 'c_aljazi', '#E7E1D3' ),
			'logo'  => 0,
			'url'   => '#',
			'shop'  => '',
			'image' => 0,
		),
		array(
			'title' => 'مكارم',
			'en'    => 'MAKAREM',
			'tag'   => 'الأزياء التراثية والمطرزات',
			'cats'  => 'مطرزات · فساتين · قفاطين',
			'markets' => 'الأردن · الخليج',
			'points'  => 'خمسة معارض في المملكة',
			'color' => qafesheh_opt( 'c_makarem', '#A51E25' ),
			'logo'  => 0,
			'url'   => '#',
			'shop'  => '',
			'image' => 0,
		),
	);
}

/**
 * أرقام منصّة الهيرو.
 *
 * @return array
 */
function qafesheh_stats() {
	$stats = array();
	for ( $i = 1; $i <= 4; $i++ ) {
		$num = qafesheh_opt( 'stat' . $i . '_num', '' );
		$lbl = qafesheh_opt( 'stat' . $i . '_lbl', '' );
		if ( $num || $lbl ) {
			$stats[] = array(
				'num' => $num,
				'lbl' => $lbl,
			);
		}
	}
	return $stats;
}

/**
 * هل هذه الصفحة مبنيّة بـElementor فعلاً؟
 *
 * @param int $post_id معرّف الصفحة.
 * @return bool
 */
function qafesheh_is_elementor_page( $post_id = 0 ) {
	$post_id = $post_id ? absint( $post_id ) : get_the_ID();

	if ( ! $post_id || ! did_action( 'elementor/loaded' ) ) {
		return false;
	}

	if ( 'builder' !== get_post_meta( $post_id, '_elementor_edit_mode', true ) ) {
		return false;
	}

	$data = get_post_meta( $post_id, '_elementor_data', true );

	return ! empty( $data ) && '[]' !== trim( (string) $data );
}

/**
 * هل نُخفي بانر الثيم في هذه الصفحة؟
 * يُخفى تلقائياً إذا بدأت الصفحة بسلايدر أو ببانر خاص بها.
 *
 * @param int $post_id معرّف الصفحة.
 * @return bool
 */
function qafesheh_hide_banner( $post_id = 0 ) {
	$post_id = $post_id ? absint( $post_id ) : get_the_ID();

	if ( ! $post_id ) {
		return false;
	}

	if ( get_post_meta( $post_id, '_qafesheh_no_banner', true ) ) {
		return true;
	}

	$data = (string) get_post_meta( $post_id, '_elementor_data', true );

	return ( $data && false !== strpos( $data, 'qb_hero_slider' ) );
}

/**
 * ووكر يطبع روابط القائمة بلا عناصر <li> — لسطر السياسات في الفوتر.
 */
class Qafesheh_Flat_Walker extends Walker_Nav_Menu {

	/**
	 * بداية العنصر.
	 *
	 * @param string   $output السلسلة.
	 * @param WP_Post  $item   العنصر.
	 * @param int      $depth  العمق.
	 * @param stdClass $args   المعطيات.
	 * @param int      $id     المعرّف.
	 */
	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		$output .= sprintf(
			'<a href="%s">%s</a>',
			esc_url( $item->url ),
			esc_html( $item->title )
		);
	}

	/**
	 * نهاية العنصر.
	 *
	 * @param string   $output السلسلة.
	 * @param WP_Post  $item   العنصر.
	 * @param int      $depth  العمق.
	 * @param stdClass $args   المعطيات.
	 */
	public function end_el( &$output, $item, $depth = 0, $args = null ) {
		unset( $output, $item, $depth, $args );
	}
}
