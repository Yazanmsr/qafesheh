<?php
/**
 * مصفوفة خيارات واحدة: qafesheh_options
 * قراءة، افتراضيات، تعقيم مركزي، ومسح كاش LiteSpeed عند الحفظ.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

const QAFESHEH_OPTION_KEY = 'qafesheh_options';

/**
 * كل الخيارات مدموجة مع الافتراضيات.
 *
 * @return array
 */
function qafesheh_options() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}

	$saved    = get_option( QAFESHEH_OPTION_KEY, array() );
	$saved    = is_array( $saved ) ? $saved : array();
	$defaults = qafesheh_option_defaults();
	$cache    = array_merge( $defaults, $saved );

	return $cache;
}

/**
 * الافتراضيات مستخرجة من المخطط.
 *
 * @return array
 */
function qafesheh_option_defaults() {
	static $defaults = null;
	if ( null !== $defaults ) {
		return $defaults;
	}

	$defaults = array();
	foreach ( qafesheh_options_flat() as $key => $field ) {
		if ( 'heading' === ( $field['type'] ?? 'text' ) ) {
			continue;
		}
		$defaults[ $key ] = $field['default'] ?? '';
	}
	return $defaults;
}

/**
 * قراءة خيار واحد.
 *
 * @param string $key      المفتاح.
 * @param mixed  $fallback قيمة بديلة.
 * @return mixed
 */
function qafesheh_opt( $key, $fallback = '' ) {
	$options = qafesheh_options();
	if ( ! array_key_exists( $key, $options ) ) {
		return $fallback;
	}
	$value = $options[ $key ];
	return ( '' === $value || null === $value ) ? $fallback : $value;
}

/**
 * قراءة صورة كمصفوفة جاهزة للطباعة.
 *
 * @param string $key  المفتاح.
 * @param string $size حجم الصورة.
 * @return array{id:int,url:string,alt:string}
 */
function qafesheh_opt_image( $key, $size = 'full' ) {
	$id  = absint( qafesheh_opt( $key, 0 ) );
	$out = array(
		'id'  => $id,
		'url' => '',
		'alt' => '',
	);

	if ( ! $id ) {
		return $out;
	}

	$src = wp_get_attachment_image_src( $id, $size );
	if ( $src ) {
		$out['url'] = $src[0];
		$out['alt'] = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
	}
	return $out;
}

/**
 * تعقيم مركزي لكل القيم حسب نوع الحقل في المخطط.
 *
 * @param array $input المدخلات الخام.
 * @return array
 */
function qafesheh_sanitize_options( $input ) {
	return qafesheh_sanitize_fields( $input, qafesheh_options_flat() );
}

/**
 * تعقيم عام لأي مجموعة حقول — تستخدمه صفحة الإعدادات وصفحات الأقسام معاً.
 *
 * @param array $input  المدخلات الخام.
 * @param array $fields تعريفات الحقول.
 * @return array
 */
function qafesheh_sanitize_fields( $input, $fields ) {
	$input  = is_array( $input ) ? $input : array();
	$clean  = array();

	foreach ( $fields as $key => $field ) {
		$type = $field['type'] ?? 'text';

		if ( 'heading' === $type ) {
			continue;
		}

		$raw = $input[ $key ] ?? null;

		switch ( $type ) {
			case 'toggle':
				$clean[ $key ] = empty( $raw ) ? 0 : 1;
				break;

			case 'number':
				$num = is_numeric( $raw ) ? (float) $raw : (float) ( $field['default'] ?? 0 );
				if ( isset( $field['min'] ) ) {
					$num = max( (float) $field['min'], $num );
				}
				if ( isset( $field['max'] ) ) {
					$num = min( (float) $field['max'], $num );
				}
				$clean[ $key ] = ( $num == (int) $num ) ? (int) $num : $num; // phpcs:ignore Universal.Operators.StrictComparisons
				break;

			case 'color':
				$hex           = sanitize_hex_color( (string) $raw );
				$clean[ $key ] = $hex ? $hex : ( $field['default'] ?? '' );
				break;

			case 'image':
				$clean[ $key ] = absint( $raw );
				break;

			case 'url':
				$clean[ $key ] = esc_url_raw( (string) $raw );
				break;

			case 'email':
				$clean[ $key ] = sanitize_email( (string) $raw );
				break;

			case 'tel':
				$clean[ $key ] = preg_replace( '/[^0-9+()\-\s]/', '', (string) $raw );
				break;

			case 'select':
				$allowed       = array_keys( $field['options'] ?? array() );
				$clean[ $key ] = in_array( $raw, $allowed, true ) ? $raw : ( $field['default'] ?? '' );
				break;

			case 'textarea':
				if ( in_array( $key, array( 'head_code', 'body_code' ), true ) ) {
					// أكواد المتابعة تُحفظ كما هي — للمشرفين فقط.
					$clean[ $key ] = current_user_can( 'unfiltered_html' ) ? (string) $raw : wp_kses_post( (string) $raw );
				} else {
					$clean[ $key ] = sanitize_textarea_field( (string) $raw );
				}
				break;

			default:
				$clean[ $key ] = sanitize_text_field( (string) $raw );
		}
	}

	return $clean;
}

/**
 * تسجيل الإعداد.
 */
function qafesheh_register_setting() {
	register_setting(
		'qafesheh_options_group',
		QAFESHEH_OPTION_KEY,
		array(
			'type'              => 'array',
			'sanitize_callback' => 'qafesheh_sanitize_options',
			'default'           => qafesheh_option_defaults(),
			'show_in_rest'      => false,
		)
	);
}
add_action( 'admin_init', 'qafesheh_register_setting' );

/**
 * مسح كاش LiteSpeed بعد كل حفظ.
 *
 * @param string $option اسم الخيار.
 */
function qafesheh_purge_on_save( $option ) {
	if ( QAFESHEH_OPTION_KEY !== $option ) {
		return;
	}
	if ( function_exists( 'do_action' ) ) {
		do_action( 'litespeed_purge_all' );
	}
	wp_cache_flush();
}
add_action( 'updated_option', 'qafesheh_purge_on_save' );
add_action( 'added_option', 'qafesheh_purge_on_save' );

/**
 * إصلاح لمرة واحدة: نسخة سابقة من الاستيراد كانت تحفظ كل المفاتيح صفراً
 * (الحركة، تثبيت الهيدر، preload، شريط الغرز) لأن الدمج تم بلا الافتراضيات.
 * نعيدها إلى قيمتها الافتراضية مرة واحدة فقط، ثم لا نلمسها بعدها أبداً.
 */
function qafesheh_repair_toggles() {
	if ( get_option( 'qafesheh_toggle_repair' ) ) {
		return;
	}

	$saved = get_option( QAFESHEH_OPTION_KEY, null );

	/* لا يوجد إعدادات محفوظة بعد — لا شيء لإصلاحه */
	if ( ! is_array( $saved ) ) {
		update_option( 'qafesheh_toggle_repair', 1, false );
		return;
	}

	$defaults = qafesheh_option_defaults();
	$toggles  = array( 'motion_on', 'header_sticky', 'preload_hero', 'footer_stitch' );
	$changed  = false;

	foreach ( $toggles as $key ) {
		$default = (int) ( $defaults[ $key ] ?? 1 );

		if ( 1 === $default && isset( $saved[ $key ] ) && 0 === (int) $saved[ $key ] ) {
			$saved[ $key ] = 1;
			$changed       = true;
		}
	}

	if ( $changed ) {
		update_option( QAFESHEH_OPTION_KEY, $saved );
		do_action( 'litespeed_purge_all' );
	}

	update_option( 'qafesheh_toggle_repair', 1, false );
}
add_action( 'admin_init', 'qafesheh_repair_toggles', 5 );
