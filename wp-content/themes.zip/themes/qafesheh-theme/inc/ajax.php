<?php
/**
 * نقاط AJAX: تحميل المزيد من المقالات، واستقبال الشكاوى والاقتراحات.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * تحميل المزيد من البطاقات.
 */
function qafesheh_ajax_load_more() {
	check_ajax_referer( 'qafesheh_front', 'nonce' );

	$page      = max( 1, absint( $_POST['page'] ?? 1 ) );
	$post_type = sanitize_key( $_POST['post_type'] ?? 'post' );
	$per_page  = min( 24, max( 1, absint( $_POST['per_page'] ?? 9 ) ) );

	$allowed = array( 'post', 'qaf_company', 'qaf_service', 'qaf_branch', 'qaf_job' );
	if ( ! in_array( $post_type, $allowed, true ) ) {
		wp_send_json_error( array( 'message' => 'نوع غير مسموح.' ), 400 );
	}

	$query = new WP_Query(
		array(
			'post_type'              => $post_type,
			'post_status'            => 'publish',
			'posts_per_page'         => $per_page,
			'paged'                  => $page + 1,
			'ignore_sticky_posts'    => true,
			'no_found_rows'          => false,
			'update_post_term_cache' => false,
		)
	);

	if ( ! $query->have_posts() ) {
		wp_send_json_success(
			array(
				'html' => '',
				'more' => false,
			)
		);
	}

	ob_start();
	while ( $query->have_posts() ) {
		$query->the_post();
		qafesheh_card( get_post() );
	}
	wp_reset_postdata();

	wp_send_json_success(
		array(
			'html' => ob_get_clean(),
			'more' => ( $page + 1 ) < (int) $query->max_num_pages,
		)
	);
}
add_action( 'wp_ajax_qafesheh_load_more', 'qafesheh_ajax_load_more' );
add_action( 'wp_ajax_nopriv_qafesheh_load_more', 'qafesheh_ajax_load_more' );

/**
 * استقبال شكوى أو اقتراح وتخزينها كمحتوى خاص.
 */
function qafesheh_ajax_complaint() {
	check_ajax_referer( 'qafesheh_front', 'nonce' );

	/* مصيدة السبام */
	if ( ! empty( $_POST['q_website'] ) ) {
		wp_send_json_success( array( 'message' => 'تم الاستلام.' ) );
	}

	$name    = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
	$email   = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$phone   = preg_replace( '/[^0-9+()\-\s]/', '', (string) wp_unslash( $_POST['phone'] ?? '' ) );
	$subject = sanitize_text_field( wp_unslash( $_POST['subject'] ?? '' ) );
	$type    = sanitize_text_field( wp_unslash( $_POST['type'] ?? 'شكوى' ) );
	$message = sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) );

	if ( ! $name || ! $message ) {
		wp_send_json_error( array( 'message' => 'الاسم والرسالة مطلوبان.' ), 400 );
	}

	if ( $email && ! is_email( $email ) ) {
		wp_send_json_error( array( 'message' => 'البريد الإلكتروني غير صحيح.' ), 400 );
	}

	$body = sprintf(
		"النوع: %s\nالاسم: %s\nالبريد: %s\nالهاتف: %s\n\n%s",
		$type,
		$name,
		$email,
		$phone,
		$message
	);

	$post_id = wp_insert_post(
		array(
			'post_type'    => 'qaf_complaint',
			'post_status'  => 'publish',
			'post_title'   => ( $subject ? $subject : $type ) . ' — ' . $name,
			'post_content' => $body,
		),
		true
	);

	if ( is_wp_error( $post_id ) ) {
		wp_send_json_error( array( 'message' => 'تعذّر الحفظ، حاول لاحقاً.' ), 500 );
	}

	update_post_meta( $post_id, 'q_c_name', $name );
	update_post_meta( $post_id, 'q_c_email', $email );
	update_post_meta( $post_id, 'q_c_phone', $phone );
	update_post_meta( $post_id, 'q_c_type', $type );

	$to = qafesheh_opt( 'c_email', get_option( 'admin_email' ) );
	wp_mail(
		$to,
		'[الموقع] ' . $type . ' جديدة — ' . $name,
		$body,
		array( 'Content-Type: text/plain; charset=UTF-8' )
	);

	wp_send_json_success( array( 'message' => 'تم استلام رسالتك، شكراً لك. سنعود إليك قريباً.' ) );
}
add_action( 'wp_ajax_qafesheh_complaint', 'qafesheh_ajax_complaint' );
add_action( 'wp_ajax_nopriv_qafesheh_complaint', 'qafesheh_ajax_complaint' );

/**
 * حفظ نسخة من رسائل Contact Form 7 داخل «الشكاوى والاقتراحات».
 *
 * @param WPCF7_ContactForm $form النموذج.
 */
function qafesheh_store_cf7( $form ) {
	if ( ! class_exists( 'WPCF7_Submission' ) ) {
		return;
	}

	$submission = WPCF7_Submission::get_instance();
	if ( ! $submission ) {
		return;
	}

	$data  = $submission->get_posted_data();
	$lines = array();
	$name  = '';

	foreach ( (array) $data as $key => $value ) {
		if ( 0 === strpos( $key, '_' ) ) {
			continue;
		}
		$value = is_array( $value ) ? implode( '، ', $value ) : (string) $value;
		$lines[] = $key . ': ' . $value;

		if ( ! $name && preg_match( '/name|الاسم/i', $key ) ) {
			$name = $value;
		}
	}

	wp_insert_post(
		array(
			'post_type'    => 'qaf_complaint',
			'post_status'  => 'publish',
			'post_title'   => $form->title() . ( $name ? ' — ' . $name : '' ),
			'post_content' => implode( "\n", array_map( 'sanitize_text_field', $lines ) ),
		)
	);
}
add_action( 'wpcf7_mail_sent', 'qafesheh_store_cf7' );
