<?php
/**
 * توكنز التصميم — منقولة حرفياً من لوحات التصميم المعتمدة
 * (qafesheh-group-final). كل قيمة هنا لها ما يقابلها في الـartboards.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * تحويل HEX إلى "r, g, b" للاستخدام داخل rgba().
 *
 * @param string $hex لون.
 * @return string
 */
function qafesheh_hex_to_rgb( $hex ) {
	$hex = ltrim( (string) $hex, '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	if ( 6 !== strlen( $hex ) ) {
		return '0, 0, 0';
	}
	return sprintf(
		'%d, %d, %d',
		hexdec( substr( $hex, 0, 2 ) ),
		hexdec( substr( $hex, 2, 2 ) ),
		hexdec( substr( $hex, 4, 2 ) )
	);
}

/**
 * عائلات الخطوط حسب الاختيار.
 *
 * @return array{display:string,body:string,latin:string}
 */
function qafesheh_font_stacks() {
	$choice = qafesheh_opt( 'font_display', 'naskh' );

	$display = "'Noto Naskh Arabic', 'Times New Roman', serif";
	if ( 'amiri' === $choice ) {
		$display = "'Amiri', 'Times New Roman', serif";
	} elseif ( 'plex' === $choice ) {
		$display = "'IBM Plex Sans Arabic', system-ui, sans-serif";
	}

	return array(
		'display' => $display,
		'body'    => "'IBM Plex Sans Arabic', system-ui, -apple-system, 'Segoe UI', sans-serif",
		'latin'   => "'Libre Baskerville', Georgia, serif",
	);
}

/**
 * بناء كتلة التوكنز.
 *
 * @return string
 */
function qafesheh_tokens_css() {
	$ink    = qafesheh_opt( 'c_ink', '#0F0E0C' );
	$ink2   = qafesheh_opt( 'c_ink_2', '#0A0906' );
	$paper  = qafesheh_opt( 'c_paper', '#F2EEE7' );
	$paper2 = qafesheh_opt( 'c_paper2', '#E8E2D7' );
	$gold   = qafesheh_opt( 'c_gold', '#B8912F' );
	$rule   = qafesheh_opt( 'c_rule', '#D6CDBD' );
	$text   = qafesheh_opt( 'c_text', '#3A362E' );
	$muted  = qafesheh_opt( 'c_muted', '#7A7263' );

	$fonts = qafesheh_font_stacks();
	$scale = max( 85, min( 120, (int) qafesheh_opt( 'font_scale', 100 ) ) ) / 100;

	/**
	 * حجم بمقياس المستخدم.
	 *
	 * @param float $px الحجم الأساسي.
	 * @return string
	 */
	$fs = function ( $px ) use ( $scale ) {
		return round( $px * $scale, 2 ) . 'px';
	};

	$css = ':root{';

	/* ---------------------------------------------------- الألوان */

	$css .= '--q-ink:' . $ink . ';';
	$css .= '--q-ink-2:' . $ink2 . ';';
	$css .= '--q-ink-card:#14130F;';
	$css .= '--q-ink-rgb:' . qafesheh_hex_to_rgb( $ink ) . ';';

	$css .= '--q-paper:' . $paper . ';';
	$css .= '--q-paper-2:' . $paper2 . ';';
	$css .= '--q-white:#FFFFFF;';

	$css .= '--q-gold:' . $gold . ';';
	$css .= '--q-gold-rgb:' . qafesheh_hex_to_rgb( $gold ) . ';';
	$css .= '--q-gold-deep:#8C6B1F;';

	$css .= '--q-rule:' . $rule . ';';
	$css .= '--q-rule-2:#CDC3B0;';
	$css .= '--q-ph:#D8D0C0;';

	$css .= '--q-text:' . $text . ';';
	$css .= '--q-text-2:#5E574B;';
	$css .= '--q-muted:' . $muted . ';';
	$css .= '--q-muted-2:#8E8674;';

	/* على الخلفيات الداكنة */
	$css .= '--q-on-dark:#FBF8F2;';
	$css .= '--q-on-dark-2:#E7E1D3;';
	$css .= '--q-on-dark-muted:#ADA694;';
	$css .= '--q-on-dark-faint:#8A8270;';
	$css .= '--q-on-dark-dim:#6A6248;';
	$css .= '--q-on-dark-dimmer:#4E4835;';
	$css .= '--q-on-dark-copy:#5E5740;';
	$css .= '--q-nav:#B5AD98;';

	/* حدود على الداكن */
	$css .= '--q-line-d:rgba(var(--q-gold-rgb),.34);';
	$css .= '--q-line-d-soft:rgba(var(--q-gold-rgb),.22);';
	$css .= '--q-line-d-faint:rgba(var(--q-gold-rgb),.16);';

	/* ألوان العلامات */
	$css .= '--q-brand-qafesheh:' . qafesheh_opt( 'c_qafesheh', '#C9A227' ) . ';';
	$css .= '--q-brand-aljazi:' . qafesheh_opt( 'c_aljazi', '#E7E1D3' ) . ';';
	$css .= '--q-brand-makarem:' . qafesheh_opt( 'c_makarem', '#A51E25' ) . ';';

	/* ---------------------------------------------------- الخطوط */

	$css .= '--q-font-display:' . $fonts['display'] . ';';
	$css .= '--q-font-body:' . $fonts['body'] . ';';
	$css .= '--q-font-latin:' . $fonts['latin'] . ';';

	/* سلّم الأحجام — مأخوذ من الـartboards مباشرة */
	$sizes = array(
		'hero'    => 70,
		'banner'  => 64,
		'h2-lg'   => 48,
		'h2'      => 46,
		'h2-sm'   => 44,
		'cta'     => 38,
		'brand'   => 36,
		'std'     => 30,
		'svc'     => 26,
		'art'     => 25,
		'brand-s' => 22,
		'lead'    => 18,
		'copy'    => 16.5,
		'copy-s'  => 16,
		'base'    => 15.5,
		'card'    => 15,
		'nav'     => 14.5,
		'sm'      => 14,
		'xs'      => 13.5,
		'xxs'     => 13,
		'label'   => 12.5,
		'micro'   => 11.5,
	);

	foreach ( $sizes as $name => $px ) {
		$css .= '--q-fs-' . $name . ':' . $fs( $px ) . ';';
	}

	/* أحجام لاتينية ثابتة لا تتأثر بمقياس النص العربي */
	$css .= '--q-fs-plate:34px;';
	$css .= '--q-fs-plinth:38px;';
	$css .= '--q-fs-idx:13px;';
	$css .= '--q-fs-eyebrow:11px;';
	$css .= '--q-fs-latin:9.5px;';

	/* ارتفاعات الأسطر */
	$css .= '--q-lh-hero:1.55;';
	$css .= '--q-lh-banner:1.48;';
	$css .= '--q-lh-h2:1.6;';
	$css .= '--q-lh-statement:1.8;';
	$css .= '--q-lh-lead:2.15;';
	$css .= '--q-lh-copy:2.3;';
	$css .= '--q-lh-card:2.1;';

	/* تباعد الحروف */
	$css .= '--q-ls-eyebrow:.34em;';
	$css .= '--q-ls-label:.24em;';
	$css .= '--q-ls-crumb:.26em;';
	$css .= '--q-ls-brand:.32em;';
	$css .= '--q-ls-col:.22em;';
	$css .= '--q-ls-util:.05em;';

	/* ---------------------------------------------------- القياسات */

	$css .= '--q-gutter:68px;';
	$css .= '--q-gutter-m:22px;';
	$css .= '--q-max:1440px;';
	$css .= '--q-rail:300px;';
	$css .= '--q-rail-gap:66px;';
	$css .= '--q-sec:110px;';
	$css .= '--q-sec-lg:120px;';
	$css .= '--q-hero-h:760px;';
	$css .= '--q-plate:92px;';
	$css .= '--q-col:240px;';

	/* المسافات */
	$space = array( 1 => 5, 2 => 8, 3 => 12, 4 => 14, 5 => 20, 6 => 26, 7 => 36, 8 => 44, 9 => 58, 10 => 66 );
	foreach ( $space as $name => $px ) {
		$css .= '--q-sp-' . $name . ':' . $px . 'px;';
	}

	/* ---------------------------------------------------- الحركة */

	$css .= '--q-ease:cubic-bezier(.22,.61,.36,1);';
	$css .= '--q-ease-soft:cubic-bezier(.4,0,.2,1);';
	$css .= '--q-dur:1s;';
	$css .= '--q-dur-bar:1.15s;';
	$css .= '--q-dur-zoom:2s;';
	$css .= '--q-hover:.55s;';
	$css .= '--q-hover-slow:.85s;';

	$css .= '}';

	/* ---------------------------------------------------- اللوحي */

	$css .= '@media (max-width:1180px){:root{';
	$css .= '--q-gutter:40px;--q-rail:200px;--q-rail-gap:40px;--q-sec:84px;--q-sec-lg:92px;';
	$css .= '--q-fs-hero:' . $fs( 48 ) . ';';
	$css .= '--q-fs-banner:' . $fs( 44 ) . ';';
	$css .= '--q-fs-h2-lg:' . $fs( 36 ) . ';';
	$css .= '--q-fs-h2:' . $fs( 35 ) . ';';
	$css .= '--q-fs-h2-sm:' . $fs( 33 ) . ';';
	$css .= '--q-fs-cta:' . $fs( 29 ) . ';';
	$css .= '--q-fs-brand:' . $fs( 29 ) . ';';
	$css .= '--q-plate:76px;--q-fs-plate:27px;';
	$css .= '}}';

	/* ---------------------------------------------------- الموبايل */

	$css .= '@media (max-width:781px){:root{';
	$css .= '--q-gutter:var(--q-gutter-m);--q-rail:100%;--q-rail-gap:30px;--q-sec:58px;--q-sec-lg:62px;';
	$css .= '--q-hero-h:auto;';
	$css .= '--q-fs-hero:' . $fs( 33 ) . ';';
	$css .= '--q-fs-banner:' . $fs( 31 ) . ';';
	$css .= '--q-fs-h2-lg:' . $fs( 27 ) . ';';
	$css .= '--q-fs-h2:' . $fs( 26 ) . ';';
	$css .= '--q-fs-h2-sm:' . $fs( 25 ) . ';';
	$css .= '--q-fs-cta:' . $fs( 24 ) . ';';
	$css .= '--q-fs-brand:' . $fs( 26 ) . ';';
	$css .= '--q-fs-std:' . $fs( 22 ) . ';';
	$css .= '--q-fs-svc:' . $fs( 21 ) . ';';
	$css .= '--q-fs-art:' . $fs( 20 ) . ';';
	$css .= '--q-fs-lead:' . $fs( 15.5 ) . ';';
	$css .= '--q-fs-copy:' . $fs( 15 ) . ';';
	$css .= '--q-plate:64px;--q-fs-plate:23px;--q-fs-plinth:29px;';
	$css .= '--q-lh-hero:1.42;--q-lh-banner:1.4;--q-lh-h2:1.45;--q-lh-statement:1.65;';
	$css .= '--q-lh-lead:2;--q-lh-copy:2.05;';
	$css .= '}}';

	/**
	 * تعديل التوكنز.
	 *
	 * @param string $css كتلة CSS.
	 */
	return apply_filters( 'qafesheh_tokens_css', $css );
}

/**
 * طباعة التوكنز في الرأس — قبل أي ستايل آخر.
 */
function qafesheh_print_tokens() {
	printf( "<style id=\"qafesheh-tokens\">%s</style>\n", qafesheh_tokens_css() ); // phpcs:ignore WordPress.Security.EscapeOutput
}
add_action( 'wp_head', 'qafesheh_print_tokens', 1 );
