<?php
/**
 * الخطوط: تُستضاف محلياً داخل assets/fonts متى ما توفرت الملفات،
 * وإلا يسقط الثيم تلقائياً على Google Fonts حتى لا ينكسر الشكل.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * خريطة الخطوط المدعومة: العائلة => أوزانها وملفاتها.
 *
 * @return array
 */
function qafesheh_font_map() {
	return array(
		'IBM Plex Sans Arabic' => array(
			400 => 'ibm-plex-sans-arabic-400.woff2',
			500 => 'ibm-plex-sans-arabic-500.woff2',
			600 => 'ibm-plex-sans-arabic-600.woff2',
			700 => 'ibm-plex-sans-arabic-700.woff2',
		),
		'Noto Naskh Arabic'    => array(
			400 => 'noto-naskh-arabic-400.woff2',
			600 => 'noto-naskh-arabic-600.woff2',
			700 => 'noto-naskh-arabic-700.woff2',
		),
		'Amiri'                => array(
			400 => 'amiri-400.woff2',
			700 => 'amiri-700.woff2',
		),
		'Libre Baskerville'    => array(
			400 => 'libre-baskerville-400.woff2',
			700 => 'libre-baskerville-700.woff2',
		),
	);
}

/**
 * العائلات المطلوبة فعلياً حسب اختيار الخط في لوحة التحكم.
 *
 * @return array
 */
function qafesheh_fonts_needed() {
	$choice = qafesheh_opt( 'font_display', 'naskh' );

	$needed = array( 'IBM Plex Sans Arabic', 'Libre Baskerville' );

	if ( 'amiri' === $choice ) {
		$needed[] = 'Amiri';
	} elseif ( 'naskh' === $choice ) {
		$needed[] = 'Noto Naskh Arabic';
	}

	return array_unique( $needed );
}

/**
 * هل ملفات الخط المحلية موجودة؟
 *
 * @return bool
 */
function qafesheh_fonts_are_local() {
	static $local = null;
	if ( null !== $local ) {
		return $local;
	}

	$map   = qafesheh_font_map();
	$local = true;

	foreach ( qafesheh_fonts_needed() as $family ) {
		foreach ( array_values( $map[ $family ] ) as $file ) {
			if ( ! file_exists( QAFESHEH_DIR . 'assets/fonts/' . $file ) ) {
				$local = false;
				break 2;
			}
		}
	}

	return $local;
}

/**
 * بناء كتل @font-face للملفات المحلية.
 *
 * @return string
 */
function qafesheh_font_face_css() {
	$map = qafesheh_font_map();
	$css = '';

	foreach ( qafesheh_fonts_needed() as $family ) {
		foreach ( $map[ $family ] as $weight => $file ) {
			$css .= '@font-face{';
			$css .= 'font-family:"' . $family . '";';
			$css .= 'font-style:normal;';
			$css .= 'font-weight:' . (int) $weight . ';';
			$css .= 'font-display:swap;';
			$css .= 'src:url("' . esc_url( qafesheh_url( 'assets/fonts/' . $file ) ) . '") format("woff2");';
			$css .= '}';
		}
	}

	return $css;
}

/**
 * طباعة الخطوط في الرأس + preload لخط النص الأساسي.
 */
function qafesheh_print_fonts() {
	if ( qafesheh_fonts_are_local() ) {
		printf(
			'<link rel="preload" as="font" type="font/woff2" href="%s" crossorigin>' . "\n",
			esc_url( qafesheh_url( 'assets/fonts/ibm-plex-sans-arabic-400.woff2' ) )
		);
		printf( "<style id=\"qafesheh-fonts\">%s</style>\n", qafesheh_font_face_css() ); // phpcs:ignore WordPress.Security.EscapeOutput
		return;
	}

	/* احتياطي: Google Fonts حتى يتم رفع ملفات WOFF2 داخل assets/fonts */
	$families = array( 'IBM+Plex+Sans+Arabic:wght@400;500;600;700', 'Libre+Baskerville:wght@400;700' );
	$choice   = qafesheh_opt( 'font_display', 'naskh' );

	if ( 'amiri' === $choice ) {
		$families[] = 'Amiri:wght@400;700';
	} elseif ( 'naskh' === $choice ) {
		$families[] = 'Noto+Naskh+Arabic:wght@400;600;700';
	}

	$url = 'https://fonts.googleapis.com/css2?family=' . implode( '&family=', $families ) . '&display=swap';

	echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
	echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
	printf( '<link rel="stylesheet" href="%s">' . "\n", esc_url( $url ) );
}
add_action( 'wp_head', 'qafesheh_print_fonts', 2 );

/**
 * نفس الخطوط داخل لوحة التحكم — الداشبورد يتبع هوية الموقع.
 */
function qafesheh_admin_fonts() {
	if ( qafesheh_fonts_are_local() ) {
		printf( "<style id=\"qafesheh-admin-fonts\">%s</style>\n", qafesheh_font_face_css() ); // phpcs:ignore WordPress.Security.EscapeOutput
		return;
	}

	echo '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Noto+Naskh+Arabic:wght@400;700&display=swap">' . "\n";
}
add_action( 'admin_head', 'qafesheh_admin_fonts', 2 );
add_action( 'login_head', 'qafesheh_admin_fonts', 2 );
