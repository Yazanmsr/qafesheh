<?php
/**
 * أنواع المحتوى: شركات، خدمات، فروع، وظائف، شكاوى.
 * كل نوع له قائمته المستقلة في لوحة التحكم — لا شيء مكدّس تحت قائمة واحدة.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

/**
 * سلاج قائمة لوحة التحكم الأم.
 */
const QAFESHEH_MENU_SLUG = 'qafesheh-panel';

/**
 * تسجيل أنواع المحتوى.
 */
function qafesheh_register_post_types() {

	$common = array(
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'show_in_rest'       => true,
		'has_archive'        => true,
		'hierarchical'       => false,
		'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes', 'custom-fields' ),
	);

	/* الشركات */
	register_post_type(
		'qaf_company',
		array_merge(
			$common,
			array(
				'labels'       => qafesheh_pt_labels( 'شركة', 'الشركات' ),
				'menu_icon'     => 'dashicons-building',
				'menu_position' => 4,
				'rewrite'       => array( 'slug' => 'companies' ),
				'has_archive'   => 'companies',
			)
		)
	);

	/* الخدمات */
	register_post_type(
		'qaf_service',
		array_merge(
			$common,
			array(
				'labels'      => qafesheh_pt_labels( 'خدمة', 'الخدمات' ),
				'menu_icon'     => 'dashicons-admin-tools',
				'menu_position' => 5,
				'rewrite'       => array( 'slug' => 'services' ),
				'has_archive'   => 'services',
			)
		)
	);

	/* الفروع والمعارض */
	register_post_type(
		'qaf_branch',
		array_merge(
			$common,
			array(
				'labels'      => qafesheh_pt_labels( 'فرع', 'الفروع والمعارض' ),
				'menu_icon'     => 'dashicons-store',
				'menu_position' => 6,
				'rewrite'       => array( 'slug' => 'branches' ),
				'has_archive'   => 'branches',
				'supports'    => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
			)
		)
	);

	/* الوظائف */
	register_post_type(
		'qaf_job',
		array_merge(
			$common,
			array(
				'labels'      => qafesheh_pt_labels( 'وظيفة', 'الوظائف' ),
				'menu_icon'     => 'dashicons-businessperson',
				'menu_position' => 7,
				'rewrite'       => array( 'slug' => 'careers' ),
				'has_archive'   => 'careers',
			)
		)
	);

	/* الشكاوى والاقتراحات — لا تُعرض للعامة */
	register_post_type(
		'qaf_complaint',
		array(
			'labels'             => qafesheh_pt_labels( 'شكوى', 'الشكاوى والاقتراحات' ),
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'show_in_rest'       => false,
			'menu_icon'          => 'dashicons-megaphone',
			'menu_position'      => 8,
			'capability_type'    => 'post',
			'capabilities'       => array( 'create_posts' => 'do_not_allow' ),
			'map_meta_cap'       => true,
			'supports'           => array( 'title', 'editor' ),
		)
	);
}
add_action( 'init', 'qafesheh_register_post_types' );

/**
 * توليد تسميات عربية كاملة.
 *
 * @param string $single مفرد.
 * @param string $plural جمع.
 * @return array
 */
function qafesheh_pt_labels( $single, $plural ) {
	return array(
		'name'                  => $plural,
		'singular_name'         => $single,
		'menu_name'             => $plural,
		'all_items'             => 'كل ' . $plural,
		'add_new'               => 'إضافة جديد',
		'add_new_item'          => 'إضافة ' . $single,
		'edit_item'             => 'تعديل ' . $single,
		'new_item'              => $single . ' جديدة',
		'view_item'             => 'عرض ' . $single,
		'view_items'            => 'عرض ' . $plural,
		'search_items'          => 'بحث في ' . $plural,
		'not_found'             => 'لا يوجد ' . $plural . ' بعد',
		'not_found_in_trash'    => 'لا يوجد ' . $plural . ' في المهملات',
		'featured_image'        => 'الصورة الرئيسية',
		'set_featured_image'    => 'اختر الصورة الرئيسية',
		'remove_featured_image' => 'إزالة الصورة',
		'use_featured_image'    => 'استخدمها كصورة رئيسية',
		'items_list'            => 'قائمة ' . $plural,
		'item_published'        => $single . ' نُشرت.',
		'item_updated'          => $single . ' حُدّثت.',
	);
}

/**
 * تصنيف «العلامة التجارية» — مشترك بين كل الأنواع والمقالات.
 */
function qafesheh_register_taxonomies() {
	register_taxonomy(
		'qaf_brand',
		array( 'qaf_company', 'qaf_service', 'qaf_branch', 'qaf_job', 'post' ),
		array(
			'labels'            => array(
				'name'          => 'العلامة التجارية',
				'singular_name' => 'علامة',
				'menu_name'     => 'العلامات التجارية',
				'all_items'     => 'كل العلامات',
				'add_new_item'  => 'إضافة علامة',
				'edit_item'     => 'تعديل علامة',
				'search_items'  => 'بحث',
			),
			'public'            => true,
			'hierarchical'      => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'rewrite'           => array( 'slug' => 'brand' ),
		)
	);

	register_taxonomy(
		'qaf_service_cat',
		array( 'qaf_service' ),
		array(
			'labels'            => array(
				'name'          => 'أقسام الخدمات',
				'singular_name' => 'قسم',
			),
			'public'            => true,
			'hierarchical'      => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'rewrite'           => array( 'slug' => 'service-category' ),
		)
	);
}
add_action( 'init', 'qafesheh_register_taxonomies' );

/**
 * العلامات الثلاث تُزرع تلقائياً أول مرة.
 */
function qafesheh_seed_brands() {
	if ( get_option( 'qafesheh_brands_seeded' ) ) {
		return;
	}

	$brands = array(
		'qafesheh' => 'قفيشة',
		'aljazi'   => 'الجازي',
		'makarem'  => 'مكارم',
	);

	foreach ( $brands as $slug => $name ) {
		if ( ! term_exists( $slug, 'qaf_brand' ) ) {
			wp_insert_term( $name, 'qaf_brand', array( 'slug' => $slug ) );
		}
	}

	update_option( 'qafesheh_brands_seeded', 1, false );
}
add_action( 'init', 'qafesheh_seed_brands', 20 );

/**
 * إعادة تسمية «المقالات» لتوافق تسمية الموقع.
 */
function qafesheh_rename_posts() {
	global $wp_post_types;

	if ( empty( $wp_post_types['post'] ) ) {
		return;
	}

	$labels                = $wp_post_types['post']->labels;
	$labels->name          = 'المقالات والأخبار';
	$labels->singular_name = 'مقال';
	$labels->menu_name     = 'المقالات والأخبار';
	$labels->all_items     = 'كل المقالات';
	$labels->add_new_item  = 'إضافة مقال';
	$labels->edit_item     = 'تعديل مقال';

	$wp_post_types['post']->menu_icon = 'dashicons-media-document';
}
add_action( 'init', 'qafesheh_rename_posts', 30 );

/**
 * الحقول الإضافية لكل نوع — مربّع واحد بسيط بدل أي إضافة خارجية.
 */
function qafesheh_meta_fields() {
	return array(
		'qaf_company' => array(
			'q_company_en'    => array( 'label' => 'الاسم اللاتيني', 'type' => 'text', 'help' => 'يظهر تحت الاسم العربي على البطاقة، مثل: QAFESHEH' ),
			'q_company_color' => array( 'label' => 'لون العلامة', 'type' => 'color', 'help' => 'اللون المميّز لهذه العلامة على بطاقتها في الرئيسية.' ),
			'q_company_url'   => array( 'label' => 'رابط المتجر', 'type' => 'url', 'help' => 'رابط المتجر الإلكتروني الخاص بهذه العلامة.' ),
			'q_company_tag'   => array( 'label' => 'سطر التعريف', 'type' => 'text', 'help' => 'سطر واحد يصف العلامة، يظهر تحت الاسم مباشرة.' ),
			'q_company_logo'  => array( 'label' => 'شعار العلامة', 'type' => 'image', 'help' => 'يُفضّل PNG شفاف أو SVG.' ),
			'q_company_cats'  => array( 'label' => 'تصنيفات المنتجات', 'type' => 'text', 'help' => 'افصل بينها بنقطة وسطية ·  تظهر في صفحة العلامة.' ),
		),
		'qaf_branch'  => array(
			'q_branch_city'  => array( 'label' => 'المدينة', 'type' => 'text' ),
			'q_branch_addr'  => array( 'label' => 'العنوان', 'type' => 'text' ),
			'q_branch_phone' => array( 'label' => 'الهاتف', 'type' => 'tel' ),
			'q_branch_hours' => array( 'label' => 'ساعات العمل', 'type' => 'text', 'help' => 'مثال: ٩:٠٠ ص — ٩:٠٠ م' ),
			'q_branch_map'   => array( 'label' => 'رابط الخريطة', 'type' => 'url', 'help' => 'افتح الموقع على خرائط جوجل ← مشاركة ← انسخ الرابط والصقه هنا.' ),
		),
		'qaf_job'     => array(
			'q_job_dept'     => array( 'label' => 'القسم', 'type' => 'text' ),
			'q_job_location' => array( 'label' => 'الموقع', 'type' => 'text' ),
			'q_job_type'     => array( 'label' => 'نوع الدوام', 'type' => 'text' ),
			'q_job_deadline' => array( 'label' => 'آخر موعد للتقديم', 'type' => 'text', 'help' => 'اتركه فارغاً إذا كان التقديم مفتوحاً.' ),
		),
		'qaf_service' => array(
			'q_service_num'  => array( 'label' => 'رقم الخدمة', 'type' => 'text', 'help' => 'رقم ترتيبي يظهر على البطاقة، مثل ٠١ أو ٠٢.' ),
			'q_service_icon' => array( 'label' => 'أيقونة الخدمة', 'type' => 'image', 'help' => 'اختياري — أيقونة صغيرة تظهر أعلى البطاقة.' ),
		),
	);
}

/**
 * إضافة مربّعات الحقول.
 */
function qafesheh_add_meta_boxes() {
	foreach ( qafesheh_meta_fields() as $type => $fields ) {
		add_meta_box(
			'qafesheh_meta_' . $type,
			'تفاصيل إضافية',
			'qafesheh_render_meta_box',
			$type,
			'normal',
			'high'
		);
	}
}
add_action( 'add_meta_boxes', 'qafesheh_add_meta_boxes' );

/**
 * رسم مربّع الحقول.
 *
 * @param WP_Post $post المقال.
 */
function qafesheh_render_meta_box( $post ) {
	$all    = qafesheh_meta_fields();
	$fields = $all[ $post->post_type ] ?? array();

	if ( ! $fields ) {
		return;
	}

	wp_nonce_field( 'qafesheh_meta_save', 'qafesheh_meta_nonce' );

	echo '<div class="qafesheh-meta">';
	foreach ( $fields as $key => $field ) {
		$value = get_post_meta( $post->ID, $key, true );
		echo '<p class="qafesheh-meta__row">';
		printf( '<label for="%s"><strong>%s</strong></label>', esc_attr( $key ), esc_html( $field['label'] ) );

		if ( ! empty( $field['help'] ) ) {
			printf( '<span class="qafesheh-meta__help">%s</span>', esc_html( $field['help'] ) );
		}

		if ( 'image' === $field['type'] ) {
			$img = $value ? wp_get_attachment_image_src( absint( $value ), 'medium' ) : false;
			echo '<span class="q-opt__media q-opt__media--meta">';
			printf(
				'<span class="q-opt__media-preview%s">%s</span>',
				$img ? '' : ' is-empty',
				$img ? '<img src="' . esc_url( $img[0] ) . '" alt="">' : '<span>لا توجد صورة</span>'
			);
			echo '<span class="q-opt__media-actions">';
			echo '<button type="button" class="q-opt__btn q-media-pick">اختر صورة</button>';
			printf(
				'<button type="button" class="q-opt__btn q-opt__btn--ghost q-media-clear"%s>إزالة</button>',
				$img ? '' : ' hidden'
			);
			echo '</span>';
			printf(
				'<input type="hidden" id="%s" name="%s" value="%s" class="q-media-input">',
				esc_attr( $key ),
				esc_attr( $key ),
				esc_attr( (string) absint( $value ) )
			);
			echo '</span>';
		} elseif ( 'color' === $field['type'] ) {
			printf(
				'<input type="text" id="%s" name="%s" value="%s" class="widefat qafesheh-color" placeholder="#B8912F">',
				esc_attr( $key ),
				esc_attr( $key ),
				esc_attr( $value )
			);
		} else {
			printf(
				'<input type="%s" id="%s" name="%s" value="%s" class="widefat">',
				esc_attr( 'url' === $field['type'] ? 'url' : ( 'tel' === $field['type'] ? 'tel' : 'text' ) ),
				esc_attr( $key ),
				esc_attr( $key ),
				esc_attr( $value )
			);
		}
		echo '</p>';
	}
	echo '</div>';
}

/**
 * حفظ الحقول.
 *
 * @param int $post_id معرّف المقال.
 */
function qafesheh_save_meta( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! isset( $_POST['qafesheh_meta_nonce'] ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['qafesheh_meta_nonce'] ) ), 'qafesheh_meta_save' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$all    = qafesheh_meta_fields();
	$type   = get_post_type( $post_id );
	$fields = $all[ $type ] ?? array();

	foreach ( $fields as $key => $field ) {
		if ( ! isset( $_POST[ $key ] ) ) {
			continue;
		}
		$raw = wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

		switch ( $field['type'] ) {
			case 'url':
				$value = esc_url_raw( (string) $raw );
				break;
			case 'image':
				$value = absint( $raw );
				break;
			case 'color':
				$value = sanitize_hex_color( (string) $raw );
				break;
			case 'tel':
				$value = preg_replace( '/[^0-9+()\-\s]/', '', (string) $raw );
				break;
			default:
				$value = sanitize_text_field( (string) $raw );
		}

		if ( '' === $value || null === $value ) {
			delete_post_meta( $post_id, $key );
		} else {
			update_post_meta( $post_id, $key, $value );
		}
	}
}
add_action( 'save_post', 'qafesheh_save_meta' );

/**
 * إعادة بناء الروابط بعد تفعيل الثيم.
 */
function qafesheh_flush_rewrites() {
	qafesheh_register_post_types();
	qafesheh_register_taxonomies();
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'qafesheh_flush_rewrites' );
