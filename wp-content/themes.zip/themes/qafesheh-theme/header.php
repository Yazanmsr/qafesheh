<?php
/**
 * الهيدر — منقول من التصميم: شريط علوي، ثم شريط رئيسي بالشعار والقائمة وزر التواصل.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="q-skip" href="#q-main">تخطّي إلى المحتوى</a>

<div class="q-progress" aria-hidden="true"><span></span></div>

<header class="q-head" id="q-head">

	<div class="q-head__top">
		<div class="q-wrap q-head__top-in">
			<div class="q-head__top-info">
				<?php if ( qafesheh_opt( 'top_address' ) ) : ?>
					<span><?php echo esc_html( qafesheh_opt( 'top_address' ) ); ?></span>
				<?php endif; ?>

				<?php if ( qafesheh_opt( 'top_address' ) && qafesheh_opt( 'top_phone' ) ) : ?>
					<span class="q-head__sep" style="color:var(--q-gold)" aria-hidden="true">|</span>
				<?php endif; ?>

				<?php if ( qafesheh_opt( 'top_phone' ) ) : ?>
					<a class="q-head__tel" dir="ltr" href="<?php echo esc_url( qafesheh_tel_href( qafesheh_opt( 'top_phone' ) ) ); ?>">
						<?php echo esc_html( qafesheh_opt( 'top_phone' ) ); ?>
					</a>
				<?php endif; ?>
			</div>

			<div class="q-head__top-links">
				<?php
				if ( has_nav_menu( 'utility' ) ) {
					wp_nav_menu(
						array(
							'theme_location' => 'utility',
							'container'      => false,
							'menu_class'     => 'q-util',
							'depth'          => 1,
							'fallback_cb'    => false,
						)
					);
				} else {
					$q_links = array();
					for ( $q_i = 1; $q_i <= 2; $q_i++ ) {
						$q_text = qafesheh_opt( 'top_link_' . $q_i, '' );
						$q_url  = qafesheh_opt( 'top_url_' . $q_i, '' );
						if ( $q_text ) {
							$q_links[] = sprintf(
								'<a class="q-head__util" href="%s">%s</a>',
								esc_url( $q_url ? $q_url : '#' ),
								esc_html( $q_text )
							);
						}
					}
					echo implode( '<span class="q-head__sep" aria-hidden="true">|</span>', $q_links ); // phpcs:ignore WordPress.Security.EscapeOutput
				}
				?>
			</div>
		</div>
	</div>

	<div class="q-head__main">
		<div class="q-wrap q-head__main-in">

			<?php qafesheh_logo( 'dark', 'q-logo q-head__logo' ); ?>

			<nav class="q-nav" id="q-nav" aria-label="القائمة الرئيسية">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'     => 'q-nav__list',
						'depth'          => 2,
						'fallback_cb'    => 'qafesheh_nav_fallback',
					)
				);
				?>
			</nav>

			<div class="q-head__actions">
				<?php if ( qafesheh_opt( 'header_cta_text' ) ) : ?>
					<a class="q-head__cta" href="<?php echo esc_url( qafesheh_opt( 'header_cta_url' ) ? qafesheh_opt( 'header_cta_url' ) : '#' ); ?>">
						<?php echo esc_html( qafesheh_opt( 'header_cta_text' ) ); ?>
					</a>
				<?php endif; ?>

				<button class="q-burger" type="button" aria-expanded="false" aria-controls="q-nav" aria-label="القائمة">
					<span></span><span></span><span></span>
				</button>
			</div>

		</div>
	</div>
</header>

<main id="q-main" class="q-main">
