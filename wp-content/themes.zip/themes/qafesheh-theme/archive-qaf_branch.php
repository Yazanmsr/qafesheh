<?php
/**
 * أرشيف الفروع والمعارض.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

get_header();

qafesheh_banner(
	array(
		'title'   => qafesheh_sec( 'branches', 'arch_title', 'فروعنا ومعارضنا' ),
		'text'    => qafesheh_sec( 'branches', 'arch_intro', '' ),
		'image'   => qafesheh_sec_image_id( 'branches' ),
	)
);
?>

<section class="q-sec">
	<div class="q-wrap">
		<?php
		qafesheh_render_section_head(
			array(
				'num'   => '٠١',
				'label' => 'الفروع',
				'title' => 'أين تجدنا',
				'text'  => qafesheh_sec( 'branches', 'arch_intro', '' ),
			)
		);
		?>
	</div>
	<div class="q-wrap" style="margin-block-start:var(--q-sp-8)">
		<?php
		qafesheh_render_branches();
		?>
	</div>
</section>

<?php if ( qafesheh_sec( 'branches', 'cta_on', 1 ) ) : ?>
	<section class="q-sec q-sec--paper2 q-sec--tight">
		<div class="q-wrap">
			<?php
			qafesheh_render_cta(
				array(
					'title' => qafesheh_sec( 'branches', 'cta_title', '' ),
					'text'  => qafesheh_sec( 'branches', 'cta_text', '' ),
					'b1_t'  => qafesheh_sec( 'branches', 'cta_btn', '' ),
					'b1_u'  => qafesheh_sec( 'branches', 'cta_url', '' ),
					'b2_t'  => '',
					'b2_u'  => '',
				)
			);
			?>
		</div>
	</section>
<?php endif; ?>

<?php
get_footer();
