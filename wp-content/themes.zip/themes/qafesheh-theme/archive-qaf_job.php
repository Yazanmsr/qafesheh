<?php
/**
 * أرشيف الوظائف.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

get_header();

qafesheh_banner(
	array(
		'title'   => qafesheh_sec( 'jobs', 'arch_title', 'الوظائف الشاغرة' ),
		'text'    => qafesheh_sec( 'jobs', 'arch_intro', '' ),
		'image'   => qafesheh_sec_image_id( 'jobs' ),
	)
);
?>

<section class="q-sec">
	<div class="q-wrap">
		<?php
		qafesheh_render_section_head(
			array(
				'num'   => '٠١',
				'label' => 'الشواغر',
				'title' => 'انضمّ إلى فريق المجموعة',
				'text'  => qafesheh_sec( 'jobs', 'arch_intro', '' ),
			)
		);
		?>
	</div>
	<div class="q-wrap" style="margin-block-start:var(--q-sp-8)">
		<?php
		qafesheh_render_jobs();

		$q_form = qafesheh_sec( 'jobs', 'form_code', '' );
		if ( $q_form ) :
			?>
			<div class="q-apply">
				<h2 class="q-apply__title">نموذج التقديم</h2>
				<?php echo do_shortcode( $q_form ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>
		<?php endif; ?>
	</div>
</section>

<?php
get_footer();
