<?php
/**
 * صفحة وظيفة واحدة.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

get_header();

while ( have_posts() ) :
	the_post();

	$q_dept = (string) get_post_meta( get_the_ID(), 'q_job_dept', true );
	$q_loc  = (string) get_post_meta( get_the_ID(), 'q_job_location', true );
	$q_type = (string) get_post_meta( get_the_ID(), 'q_job_type', true );
	$q_dead = (string) get_post_meta( get_the_ID(), 'q_job_deadline', true );

	qafesheh_banner(
		array(
			'title'   => get_the_title(),
			'image'   => qafesheh_sec_image_id( 'jobs' ),
		)
	);
	?>

	<section class="q-sec">
		<div class="q-wrap">
			<div class="q-single">

				<article class="q-prose"><?php the_content(); ?></article>

				<aside class="q-single__side">
					<div class="q-box">
						<h2 class="q-box__title">تفاصيل الوظيفة</h2>
						<dl class="q-box__list">
							<?php if ( $q_dept ) : ?>
								<div class="q-caps__row"><dt>القسم</dt><dd><?php echo esc_html( $q_dept ); ?></dd></div>
							<?php endif; ?>
							<?php if ( $q_loc ) : ?>
								<div class="q-caps__row"><dt>الموقع</dt><dd><?php echo esc_html( $q_loc ); ?></dd></div>
							<?php endif; ?>
							<?php if ( $q_type ) : ?>
								<div class="q-caps__row"><dt>نوع الدوام</dt><dd><?php echo esc_html( $q_type ); ?></dd></div>
							<?php endif; ?>
							<?php if ( $q_dead ) : ?>
								<div class="q-caps__row"><dt>آخر موعد</dt><dd><?php echo esc_html( $q_dead ); ?></dd></div>
							<?php endif; ?>
						</dl>

						<?php
						$q_mail = qafesheh_sec( 'jobs', 'apply_mail', qafesheh_opt( 'c_email', '' ) );
						if ( $q_mail ) :
							?>
							<a class="q-box__cta" href="mailto:<?php echo esc_attr( $q_mail ); ?>?subject=<?php echo esc_attr( rawurlencode( 'تقديم على وظيفة: ' . get_the_title() ) ); ?>">
								<?php echo esc_html( qafesheh_sec( 'jobs', 'apply_txt', 'قدّم على الوظيفة' ) ); ?>
							</a>
						<?php endif; ?>
					</div>
				</aside>

			</div>

			<?php
			$q_form = qafesheh_sec( 'jobs', 'form_code', '' );
			if ( $q_form ) :
				?>
				<div class="q-apply">
					<h2 class="q-apply__title">نموذج التقديم</h2>
					<?php echo do_shortcode( $q_form ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</div>
			<?php endif; ?>
		</div>
	</section>

	<?php
endwhile;

get_footer();
