<?php
/**
 * Qafesheh Group — bootstrap only.
 * لا يوجد منطق هنا. كل شيء داخل inc/.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

define( 'QAFESHEH_VERSION', '1.0.0' );
define( 'QAFESHEH_DIR', trailingslashit( get_template_directory() ) );
define( 'QAFESHEH_URI', trailingslashit( get_template_directory_uri() ) );
define( 'QAFESHEH_PREFIX', 'qafesheh' );

/**
 * إصدار الأصل من تاريخ تعديل الملف — لا نسخة مكتوبة يدوياً أبداً.
 *
 * @param string $rel مسار نسبي داخل الثيم، مثل assets/css/base.css
 * @return string
 */
function qafesheh_asset_ver( $rel ) {
	$path = QAFESHEH_DIR . ltrim( $rel, '/' );
	return file_exists( $path ) ? (string) filemtime( $path ) : QAFESHEH_VERSION;
}

/**
 * رابط داخل الثيم — يعمل مع التنصيب في مجلد فرعي.
 *
 * @param string $rel مسار نسبي.
 * @return string
 */
function qafesheh_url( $rel = '' ) {
	return QAFESHEH_URI . ltrim( $rel, '/' );
}

$qafesheh_includes = array(
	/* البيانات */
	'inc/data/content.php',
	'inc/data/pages.php',
	'inc/data/elementor-home.php',

	/* النواة */
	'inc/options.php',
	'inc/options-schema.php',
	'inc/sections.php',
	'inc/tokens.php',
	'inc/fonts.php',
	'inc/enqueue.php',
	'inc/post-types.php',
	'inc/template-tags.php',
	'inc/renderers.php',
	'inc/ajax.php',

	/* لوحة التحكم */
	'inc/admin/admin-ui.php',
	'inc/admin/options-page.php',
	'inc/admin/menus.php',
	'inc/admin/columns.php',
	'inc/admin/importer.php',
	'inc/admin/services-manager.php',
	'inc/admin/guide.php',

	/* Elementor */
	'inc/elementor/init.php',
);

foreach ( $qafesheh_includes as $qafesheh_file ) {
	$qafesheh_path = QAFESHEH_DIR . $qafesheh_file;
	if ( file_exists( $qafesheh_path ) ) {
		require_once $qafesheh_path;
	}
}
unset( $qafesheh_includes, $qafesheh_file, $qafesheh_path );

/**
 * دعم الثيم.
 */
function qafesheh_setup() {
	load_theme_textdomain( 'qafesheh', QAFESHEH_DIR . 'languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );

	register_nav_menus(
		array(
			'primary'    => __( 'القائمة الرئيسية', 'qafesheh' ),
			'utility'    => __( 'الشريط العلوي', 'qafesheh' ),
			'footer_group'    => __( 'الفوتر — المجموعة', 'qafesheh' ),
			'footer_brands'   => __( 'الفوتر — شركاتنا', 'qafesheh' ),
			'footer_service'  => __( 'الفوتر — خدمة العملاء', 'qafesheh' ),
			'footer_legal'    => __( 'الفوتر — السياسات', 'qafesheh' ),
		)
	);

	add_image_size( 'qafesheh_hero', 2560, 1100, true );
	add_image_size( 'qafesheh_banner', 2560, 760, true );
	add_image_size( 'qafesheh_card', 1400, 1000, true );
	add_image_size( 'qafesheh_thumb', 800, 560, true );
}
add_action( 'after_setup_theme', 'qafesheh_setup' );

/**
 * تنظيف رأس الصفحة.
 */
function qafesheh_clean_head() {
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
}
add_action( 'init', 'qafesheh_clean_head' );

/**
 * رفع SVG عبر قائمة سماح تنظّف السكربتات — للمشرفين فقط.
 *
 * @param array $mimes أنواع الملفات.
 * @return array
 */
function qafesheh_allow_svg( $mimes ) {
	if ( current_user_can( 'manage_options' ) ) {
		$mimes['svg']  = 'image/svg+xml';
		$mimes['svgz'] = 'image/svg+xml';
	}
	return $mimes;
}
add_filter( 'upload_mimes', 'qafesheh_allow_svg' );

/**
 * تعقيم ملفات SVG المرفوعة: إزالة السكربتات ومعالجات الأحداث والمراجع الخارجية.
 *
 * @param array $file ملف مرفوع.
 * @return array
 */
function qafesheh_sanitize_svg_upload( $file ) {
	if ( empty( $file['type'] ) || 'image/svg+xml' !== $file['type'] || empty( $file['tmp_name'] ) ) {
		return $file;
	}

	$svg = file_get_contents( $file['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( false === $svg ) {
		$file['error'] = __( 'تعذّر قراءة ملف SVG.', 'qafesheh' );
		return $file;
	}

	$clean = qafesheh_clean_svg_markup( $svg );
	if ( null === $clean ) {
		$file['error'] = __( 'ملف SVG غير صالح أو يحتوي على محتوى غير مسموح.', 'qafesheh' );
		return $file;
	}

	file_put_contents( $file['tmp_name'], $clean ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	return $file;
}
add_filter( 'wp_handle_upload_prefilter', 'qafesheh_sanitize_svg_upload' );

/**
 * تنظيف مُعلَّم SVG عبر DOM.
 *
 * @param string $svg محتوى الملف.
 * @return string|null
 */
function qafesheh_clean_svg_markup( $svg ) {
	if ( ! class_exists( 'DOMDocument' ) ) {
		return null;
	}

	$svg = preg_replace( '/<!ENTITY[^>]*>/i', '', (string) $svg );

	$previous = libxml_use_internal_errors( true );
	$dom      = new DOMDocument();
	$loaded   = $dom->loadXML( $svg, LIBXML_NONET | LIBXML_NOENT );
	libxml_clear_errors();
	libxml_use_internal_errors( $previous );

	if ( ! $loaded || ! $dom->documentElement || 'svg' !== strtolower( $dom->documentElement->nodeName ) ) {
		return null;
	}

	$blocked_tags = array( 'script', 'foreignObject', 'iframe', 'embed', 'object', 'audio', 'video', 'handler', 'set', 'animate' );
	foreach ( $blocked_tags as $tag ) {
		$nodes = $dom->getElementsByTagName( $tag );
		for ( $i = $nodes->length - 1; $i >= 0; $i-- ) {
			$node = $nodes->item( $i );
			if ( $node && $node->parentNode ) {
				$node->parentNode->removeChild( $node );
			}
		}
	}

	$xpath = new DOMXPath( $dom );
	$all   = $xpath->query( '//*' );
	if ( $all ) {
		foreach ( $all as $node ) {
			if ( ! $node->hasAttributes() ) {
				continue;
			}
			for ( $i = $node->attributes->length - 1; $i >= 0; $i-- ) {
				$attr = $node->attributes->item( $i );
				if ( ! $attr ) {
					continue;
				}
				$name  = strtolower( $attr->nodeName );
				$value = trim( (string) $attr->nodeValue );

				if ( 0 === strpos( $name, 'on' ) ) {
					$node->removeAttribute( $attr->nodeName );
					continue;
				}
				if ( preg_match( '/(javascript:|data:text\/html|<script)/i', $value ) ) {
					$node->removeAttribute( $attr->nodeName );
					continue;
				}
				if ( in_array( $name, array( 'href', 'xlink:href' ), true ) && '' !== $value && '#' !== substr( $value, 0, 1 ) ) {
					$node->removeAttribute( $attr->nodeName );
				}
			}
		}
	}

	return $dom->saveXML();
}
