<?php
/**
 * الصفحة الرئيسية — بترتيب أقسام التصميم المعتمد.
 * إن بُنيت بـElementor نعرض مخرجاته، وإلا نعرض الأقسام الجاهزة بنفس دوال التصيير.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

get_header();

if ( qafesheh_is_elementor_page() ) {

	while ( have_posts() ) {
		the_post();
		the_content();
	}
} else {

	/* ---------------------------------------------- الهيرو + منصّة الأرقام */
	qafesheh_render_hero_slider(
		array(
			'slides' => array(
				array(
					'image'   => absint( qafesheh_opt( 'hero_image', 0 ) ),
					'eyebrow' => qafesheh_opt( 'hero_eyebrow', '' ),
					'title'   => qafesheh_opt( 'hero_title', '' ),
					'text'    => qafesheh_opt( 'hero_text', '' ),
					'b1'      => qafesheh_opt( 'hero_btn1_txt', '' ),
					'b1_url'  => qafesheh_opt( 'hero_btn1_url', '' ),
					'b2'      => qafesheh_opt( 'hero_btn2_txt', '' ),
					'b2_url'  => qafesheh_opt( 'hero_btn2_url', '' ),
				),
			),
		)
	);
	?>

	<section class="q-sec q-sec--lg">
		<div class="q-wrap"><?php qafesheh_render_about(); ?></div>
	</section>

	<section class="q-sec q-sec--ink" id="companies">
		<div class="q-wrap">
			<?php
			qafesheh_render_section_head(
				array(
					'num'   => '٠٢',
					'label' => 'قطاعات الأعمال',
					'title' => 'ثلاث علاماتٍ متخصصة',
					'text'  => qafesheh_sec( 'companies', 'arch_intro', 'كل علامةٍ تخدم قطاعها الخاص، وتشترك مع المجموعة في المصنع والخامة ومعايير الجودة.' ),
				)
			);
			?>
		</div>
		<div class="q-wrap" style="margin-block-start:var(--q-sp-9)">
			<?php qafesheh_render_companies(); ?>
		</div>
	</section>

	<section class="q-sec q-sec--paper2">
		<div class="q-wrap"><?php qafesheh_render_caps_split(); ?></div>
	</section>

	<?php if ( get_posts( array( 'post_type' => 'qaf_service', 'numberposts' => 1, 'fields' => 'ids' ) ) ) : ?>
		<section class="q-sec">
			<div class="q-wrap">
				<?php
				qafesheh_render_section_head(
					array(
						'num'      => '٠٤',
						'label'    => 'الخدمات',
						'title'    => 'ما نقدّمه للتجّار والأفراد',
						'link_txt' => 'كل الخدمات',
						'link_url' => get_post_type_archive_link( 'qaf_service' ),
					)
				);
				?>
			</div>
			<div class="q-wrap" style="margin-block-start:var(--q-sp-8)">
				<?php qafesheh_render_services( array( 'limit' => 6 ) ); ?>
			</div>
		</section>
	<?php endif; ?>

	<section class="q-sec q-sec--ink-2">
		<div class="q-wrap">
			<div class="q-lay">
				<?php qafesheh_rail( '٠٥', 'المعايير' ); ?>
				<div class="q-lay__body"><?php qafesheh_render_standards(); ?></div>
			</div>
		</div>
	</section>

	<?php if ( get_posts( array( 'numberposts' => 1, 'fields' => 'ids' ) ) ) : ?>
		<section class="q-sec">
			<div class="q-wrap">
				<?php
				$q_blog = get_option( 'page_for_posts' );

				qafesheh_render_section_head(
					array(
						'num'      => '٠٦',
						'label'    => 'المقالات والأخبار',
						'title'    => 'آخر ما نشرناه',
						'link_txt' => 'الأرشيف',
						'link_url' => $q_blog ? get_permalink( $q_blog ) : home_url( '/' ),
					)
				);
				?>
			</div>
			<div class="q-wrap" style="margin-block-start:var(--q-sp-8)">
				<?php qafesheh_render_articles( array( 'limit' => 3 ) ); ?>
			</div>
		</section>
	<?php endif; ?>

	<?php
	$q_map    = qafesheh_data_media_map();
	$q_branch = function_exists( 'qafesheh_demo_image_id' ) ? qafesheh_demo_image_id( $q_map['branches'] ) : 0;

	qafesheh_render_branches_split( array( 'image' => $q_branch ) );
	?>

	<?php qafesheh_render_cta(); ?>

	<?php
}

get_footer();
