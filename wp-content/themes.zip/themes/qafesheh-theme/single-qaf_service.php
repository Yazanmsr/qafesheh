<?php
/**
 * صفحة خدمة واحدة.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

get_header();

while ( have_posts() ) :
	the_post();

	$q_num = (string) get_post_meta( get_the_ID(), 'q_service_num', true );

	qafesheh_banner(
		array(
			'title'   => get_the_title(),
			'image'   => get_post_thumbnail_id() ? get_post_thumbnail_id() : qafesheh_sec_image_id( 'services' ),
		)
	);
	?>

	<section class="q-sec">
		<div class="q-wrap">
			<article class="q-prose"><?php the_content(); ?></article>
		</div>
	</section>

	<section class="q-sec q-sec--paper2">
		<div class="q-wrap">
			<?php
			qafesheh_render_section_head(
				array(
					'num'   => '٠٢',
					'label' => 'الخدمات',
					'title' => 'خدماتٌ أخرى',
				)
			);
			qafesheh_render_services( array( 'limit' => 3, 'cols' => '3' ) );
			?>
		</div>
	</section>

	<?php
endwhile;

get_footer();
