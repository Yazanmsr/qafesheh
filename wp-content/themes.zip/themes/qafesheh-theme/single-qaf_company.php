<?php
/**
 * صفحة شركة واحدة.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

get_header();

while ( have_posts() ) :
	the_post();

	$q_en    = (string) get_post_meta( get_the_ID(), 'q_company_en', true );
	$q_tag   = (string) get_post_meta( get_the_ID(), 'q_company_tag', true );
	$q_color = (string) get_post_meta( get_the_ID(), 'q_company_color', true );
	$q_shop  = (string) get_post_meta( get_the_ID(), 'q_company_url', true );
	$q_cats  = (string) get_post_meta( get_the_ID(), 'q_company_cats', true );
	$q_terms = wp_get_object_terms( get_the_ID(), 'qaf_brand', array( 'fields' => 'slugs' ) );
	$q_brand = ( ! is_wp_error( $q_terms ) && $q_terms ) ? $q_terms[0] : '';

	qafesheh_banner(
		array(
			'title'   => get_the_title(),
			'image'   => get_post_thumbnail_id(),
		)
	);
	?>

	<section class="q-sec q-sec--paper" style="--brand:<?php echo esc_attr( $q_color ? $q_color : 'var(--q-gold)' ); ?>">
		<div class="q-wrap">
			<div class="q-single">

				<div class="q-prose">
					<?php if ( $q_tag ) : ?>
						<p class="q-lead-quote"><?php echo esc_html( $q_tag ); ?></p>
					<?php endif; ?>
					<?php the_content(); ?>
				</div>

				<aside class="q-single__side">
					<div class="q-box">
						<h2 class="q-box__title">عن العلامة</h2>
						<dl class="q-box__list">
							<?php if ( $q_en ) : ?>
								<div class="q-caps__row"><dt>الاسم اللاتيني</dt><dd dir="ltr"><?php echo esc_html( $q_en ); ?></dd></div>
							<?php endif; ?>
							<?php if ( $q_cats ) : ?>
								<div class="q-caps__row"><dt>التصنيفات</dt><dd><?php echo esc_html( $q_cats ); ?></dd></div>
							<?php endif; ?>
							<div class="q-caps__row"><dt>المنشأ</dt><dd>صناعة أردنية ١٠٠٪</dd></div>
						</dl>

						<?php if ( $q_shop ) : ?>
							<a class="q-box__cta" href="<?php echo esc_url( $q_shop ); ?>" target="_blank" rel="noopener">زيارة المتجر ↗</a>
						<?php endif; ?>
					</div>
				</aside>

			</div>
		</div>
	</section>

	<?php if ( $q_brand ) : ?>
		<section class="q-sec q-sec--paper2">
			<div class="q-wrap">
				<?php
				qafesheh_render_section_head(
					array(
						'num'   => '٠٢',
						'label' => 'BRANCHES',
						'title' => 'أين تجد ' . get_the_title(),
					)
				);

				qafesheh_render_branches(
					array(
						'brand'       => $q_brand,
						'show_filter' => false,
					)
				);
				?>
			</div>
		</section>
	<?php endif; ?>

	<section class="q-sec q-sec--paper q-sec--tight">
		<div class="q-wrap"><?php qafesheh_render_cta(); ?></div>
	</section>

	<?php
endwhile;

get_footer();
