<?php
/**
 * Template Name: الشكاوى والاقتراحات
 *
 * نموذج يُخزّن الرسائل في لوحة التحكم ويرسل نسخة على البريد.
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

get_header();

qafesheh_banner(
	array(
		'title'   => qafesheh_sec( 'complaints', 'arch_title', 'الشكاوى والاقتراحات' ),
		'text'    => qafesheh_sec( 'complaints', 'arch_intro', '' ),
		'image'   => qafesheh_sec_image_id( 'complaints' ),
	)
);

$q_types = array_filter( array_map( 'trim', explode( '،', (string) qafesheh_sec( 'complaints', 'types', 'شكوى، اقتراح، استفسار، شكر' ) ) ) );
?>

<section class="q-sec">
	<div class="q-wrap">

		<?php
		qafesheh_render_section_head(
			array(
				'num'   => '٠١',
				'label' => 'رأيك يهمّنا',
				'title' => 'رأيك يصل مباشرة',
				'text'  => '',
			)
		);
		?>

		</div>
	</div>

	<div class="q-wrap" style="margin-block-start:var(--q-sp-8)">
		<form class="q-form" data-q-complaint novalidate>

			<div class="q-form__row">
				<div>
					<label for="q-name">الاسم <span aria-hidden="true">*</span></label>
					<input type="text" id="q-name" name="name" required>
				</div>
				<div>
					<label for="q-type">نوع الرسالة</label>
					<select id="q-type" name="type">
						<?php foreach ( $q_types as $q_type ) : ?>
							<option value="<?php echo esc_attr( $q_type ); ?>"><?php echo esc_html( $q_type ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>

			<div class="q-form__row">
				<div>
					<label for="q-email">البريد الإلكتروني</label>
					<input type="email" id="q-email" name="email" dir="ltr">
				</div>
				<div>
					<label for="q-phone">رقم الهاتف</label>
					<input type="tel" id="q-phone" name="phone" dir="ltr">
				</div>
			</div>

			<div class="q-form__row q-form__row--1">
				<div>
					<label for="q-subject">الموضوع</label>
					<input type="text" id="q-subject" name="subject">
				</div>
			</div>

			<div class="q-form__row q-form__row--1">
				<div>
					<label for="q-message">الرسالة <span aria-hidden="true">*</span></label>
					<textarea id="q-message" name="message" required></textarea>
				</div>
			</div>

			<label class="q-form__hp" aria-hidden="true">
				لا تملأ هذا الحقل
				<input type="text" name="q_website" tabindex="-1" autocomplete="off">
			</label>

			<button type="submit" class="q-btn q-btn--solid"><span>إرسال الرسالة</span></button>

			<span class="q-form__note" data-q-note></span>

			<?php if ( qafesheh_sec( 'complaints', 'privacy', '' ) ) : ?>
				<p class="q-form__privacy"><?php echo esc_html( qafesheh_sec( 'complaints', 'privacy', '' ) ); ?></p>
			<?php endif; ?>
		</form>

	</div>
</section>

<section class="q-sec q-sec--paper2 q-sec--tight">
	<div class="q-wrap"><?php qafesheh_render_contact_cards(); ?></div>
</section>

<?php
get_footer();
