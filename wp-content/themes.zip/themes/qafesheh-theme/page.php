<?php
/**
 * الصفحات العادية — بانر الثيم ثم محتوى الصفحة (أو مخرجات Elementor).
 *
 * @package Qafesheh
 */

defined( 'ABSPATH' ) || exit;

get_header();

while ( have_posts() ) :
	the_post();

	if ( ! qafesheh_hide_banner() ) {
		qafesheh_banner(
			array(
				'title' => get_the_title(),
				'image' => get_post_thumbnail_id(),
			)
		);
	}

	if ( qafesheh_is_elementor_page() ) {
		the_content();
	} else {
		?>
		<section class="q-sec">
			<div class="q-wrap">
				<article class="q-prose"><?php the_content(); ?></article>
			</div>
		</section>
		<?php
	}

endwhile;

get_footer();
