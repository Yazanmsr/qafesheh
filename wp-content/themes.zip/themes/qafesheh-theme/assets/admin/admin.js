/**
 * لوحة تحكم قفيشة — التابات، البحث، اختيار الصور، منتقي الألوان.
 */
( function ( $ ) {
	'use strict';

	$( function () {

		/* ---------------------------------------------- منتقي الألوان */

		if ( $.fn.wpColorPicker ) {
			$( '.q-color, .qafesheh-color' ).wpColorPicker();
		}

		var $wrap = $( '#q-opt' );

		/* ---------------------------------------------- اختيار الصور */

		$( document ).on( 'click', '.q-media-pick', function ( e ) {
			e.preventDefault();

			var $media = $( this ).closest( '.q-opt__media' );
			var frame  = wp.media( {
				title:    ( window.QAFESHEH_ADMIN && QAFESHEH_ADMIN.choose ) || 'اختر صورة',
				button:   { text: ( window.QAFESHEH_ADMIN && QAFESHEH_ADMIN.use ) || 'استخدم هذه الصورة' },
				library:  { type: 'image' },
				multiple: false
			} );

			frame.on( 'select', function () {
				var att = frame.state().get( 'selection' ).first().toJSON();
				var url = ( att.sizes && att.sizes.medium ) ? att.sizes.medium.url : att.url;

				$media.find( '.q-media-input' ).val( att.id ).trigger( 'change' );
				$media.find( '.q-opt__media-preview' )
					.removeClass( 'is-empty' )
					.html( $( '<img>' ).attr( 'src', url ).attr( 'alt', '' ) );
				$media.find( '.q-media-clear' ).prop( 'hidden', false );
			} );

			frame.open();
		} );

		$( document ).on( 'click', '.q-media-clear', function ( e ) {
			e.preventDefault();
			var $media = $( this ).closest( '.q-opt__media' );

			$media.find( '.q-media-input' ).val( '' ).trigger( 'change' );
			$media.find( '.q-opt__media-preview' )
				.addClass( 'is-empty' )
				.html( $( '<span>' ).text( 'لا توجد صورة' ) );
			$( this ).prop( 'hidden', true );
		} );

		if ( ! $wrap.length ) {
			return;
		}

		/* ---------------------------------------------- التابات */

		function activate( id, push ) {
			var $tab = $wrap.find( '.q-opt__tab[data-tab="' + id + '"]' );
			if ( ! $tab.length ) {
				return;
			}

			$wrap.find( '.q-opt__tab' ).removeClass( 'is-active' );
			$tab.addClass( 'is-active' );

			$wrap.find( '.q-opt__panel' ).removeClass( 'is-active' );
			$wrap.find( '.q-opt__panel[data-panel="' + id + '"]' ).addClass( 'is-active' );

			try {
				window.localStorage.setItem( 'qafeshehTab', id );
			} catch ( err ) {}

			if ( push && window.history && window.history.replaceState ) {
				window.history.replaceState( null, '', '#' + id );
			}
		}

		$wrap.on( 'click', '.q-opt__tab', function () {
			activate( $( this ).data( 'tab' ), true );
			$( 'html, body' ).animate( { scrollTop: $wrap.offset().top - 40 }, 220 );
		} );

		var start = ( window.location.hash || '' ).replace( '#', '' );

		if ( ! start ) {
			try {
				start = window.localStorage.getItem( 'qafeshehTab' ) || '';
			} catch ( err ) {}
		}

		if ( start ) {
			activate( start, false );
		}

		/* ---------------------------------------------- البحث */

		var timer = null;

		$( '#q-opt-search' ).on( 'input', function () {
			var term = $.trim( this.value ).toLowerCase();

			window.clearTimeout( timer );
			timer = window.setTimeout( function () {
				if ( ! term ) {
					$wrap.removeClass( 'is-searching' );
					$wrap.find( '.q-opt__field, .q-opt__group' ).removeClass( 'is-hidden' );
					$( '#q-opt-empty' ).prop( 'hidden', true );
					activate( $wrap.find( '.q-opt__tab.is-active' ).data( 'tab' ) || start, false );
					return;
				}

				$wrap.addClass( 'is-searching' );

				var found = 0;

				$wrap.find( '.q-opt__field' ).each( function () {
					var hit = ( $( this ).attr( 'data-search' ) || '' ).indexOf( term ) !== -1;
					$( this ).toggleClass( 'is-hidden', ! hit );
					if ( hit ) {
						found++;
					}
				} );

				$wrap.find( '.q-opt__group' ).each( function () {
					var visible = $( this ).find( '.q-opt__field' ).not( '.is-hidden' ).length;
					$( this ).toggleClass( 'is-hidden', 0 === visible );
				} );

				$( '#q-opt-empty' ).prop( 'hidden', found > 0 );
			}, 130 );
		} );

		/* ---------------------------------------------- نص المفتاح */

		$wrap.on( 'change', '.q-opt__switch input', function () {
			$( this ).closest( '.q-opt__switch' )
				.find( '.q-opt__switch-txt' )
				.text( this.checked ? 'مُفعّل' : 'مُعطّل' );
		} );

		/* ---------------------------------------------- تنبيه التغييرات غير المحفوظة */

		var dirty  = false;
		var $form  = $( '#q-opt-form' );

		$form.on( 'change input', 'input, select, textarea', function () {
			if ( ! dirty ) {
				dirty = true;
				$( '.q-opt__bar-note' ).text( 'لديك تغييرات غير محفوظة.' ).css( 'color', '#D3A939' );
			}
		} );

		$form.on( 'submit', function () {
			dirty = false;
		} );

		$( window ).on( 'beforeunload', function () {
			if ( dirty ) {
				return 'لديك تغييرات لم تُحفظ بعد.';
			}
		} );

		/* ---------------------------------------------- حفظ بـ Ctrl+S */

		$( document ).on( 'keydown', function ( e ) {
			if ( ( e.ctrlKey || e.metaKey ) && 83 === e.which ) {
				e.preventDefault();
				$form.trigger( 'submit' );
			}
		} );

	} );

}( jQuery ) );

/**
 * الملاحظات الإرشادية · الاستيراد · لوحة الخدمات.
 */
( function ( $ ) {
	'use strict';

	var A = window.QAFESHEH_ADMIN || {};

	function post( action, data ) {
		return $.post( A.ajax, $.extend( { action: action, nonce: A.nonce }, data || {} ) );
	}

	$( function () {

		/* ---------------------------------------------- إخفاء الملاحظات */

		$( document ).on( 'click', '.q-note .notice-dismiss', function () {
			var id = $( this ).closest( '.q-note' ).data( 'q-note' );
			if ( id ) {
				post( 'qafesheh_dismiss_note', { note: id } );
			}
		} );

		/* ---------------------------------------------- الاستيراد */

		var $imp = $( '#q-imp' );

		if ( $imp.length ) {

			/* خطوة قد تطلب إعادة النداء (رفع الصور على دفعات).
			   نعيد Deferred واحداً لا يُحسم إلا بعد آخر دفعة، حتى لا يسبقه المتتابع. */
			var runStep = function ( $card ) {
				var step  = $card.data( 'step' );
				var $btn  = $card.find( '.q-imp__run' );
				var $out  = $card.find( '.q-imp__result' );
				var dfd   = $.Deferred();

				$card.addClass( 'is-running' ).removeClass( 'is-done is-fail' );
				$btn.prop( 'disabled', true );
				$out.text( 'جارٍ التنفيذ…' );

				var pass = function ( n ) {
					post( 'qafesheh_import', { step: step } )
						.done( function ( res ) {
							if ( res && res.success ) {
								$out.text( res.data.message );

								if ( res.data.repeat && n < 20 ) {
									pass( n + 1 );
									return;
								}

								$card.addClass( 'is-done' );
							} else {
								$card.addClass( 'is-fail' );
								$out.text( ( res && res.data && res.data.message ) || A.error );
							}

							finish();
						} )
						.fail( function () {
							$card.addClass( 'is-fail' );
							$out.text( A.error );
							finish();
						} );
				};

				var finish = function () {
					$card.removeClass( 'is-running' );
					$btn.prop( 'disabled', false );
					dfd.resolve();
				};

				pass( 1 );

				return dfd.promise();
			};

			$imp.on( 'click', '.q-imp__run', function () {
				runStep( $( this ).closest( '.q-imp__card' ) );
			} );

			$( '#q-imp-all' ).on( 'click', function () {
				var $all   = $imp.find( '.q-imp__card' );
				var $bar   = $( '#q-imp-progress' );
				var $state = $( '#q-imp-status' );
				var i      = 0;

				$( this ).prop( 'disabled', true );
				$bar.prop( 'hidden', false ).find( 'span' ).css( 'width', '0%' );
				$state.text( 'جارٍ الاستيراد…' );

				var next = function () {
					if ( i >= $all.length ) {
						$state.text( 'اكتمل الاستيراد. افتح الموقع لتراه.' );
						$bar.find( 'span' ).css( 'width', '100%' );
						$( '#q-imp-all' ).prop( 'disabled', false );
						return;
					}

					runStep( $all.eq( i ) ).always( function () {
						i++;
						$bar.find( 'span' ).css( 'width', Math.round( ( i / $all.length ) * 100 ) + '%' );
						window.setTimeout( next, 180 );
					} );
				};

				next();
			} );
		}

		/* ---------------------------------------------- لوحة الخدمات */

		var $svc = $( '#q-svc' );

		if ( ! $svc.length ) {
			return;
		}

		var $list   = $( '#q-svc-list' );
		var $status = $( '#q-svc-status' );

		var say = function ( text, bad ) {
			$status.text( text ).css( 'color', bad ? '#C0392B' : '#B8912F' );
			window.setTimeout( function () {
				$status.css( 'color', '' );
			}, 2200 );
		};

		if ( $.fn.sortable ) {
			$list.sortable( {
				handle: '.q-svc__handle',
				axis: 'y',
				placeholder: 'q-svc__ph',
				forcePlaceholderSize: true,
				update: function () {
					var ids = $list.find( '.q-svc__row' ).map( function () {
						return $( this ).data( 'id' );
					} ).get();

					post( 'qafesheh_svc_order', { ids: ids } )
						.done( function ( res ) {
							say( ( res && res.data && res.data.message ) || A.saved );
						} )
						.fail( function () {
							say( A.error, true );
						} );
				}
			} );
		}

		$( '#q-svc-add' ).on( 'submit', function ( e ) {
			e.preventDefault();

			var $form = $( this );
			var data  = {
				num: $form.find( '[name="num"]' ).val(),
				title: $form.find( '[name="title"]' ).val(),
				excerpt: $form.find( '[name="excerpt"]' ).val()
			};

			if ( ! $.trim( data.title ) ) {
				$( '#q-svc-add-note' ).text( 'اكتب اسم الخدمة أولاً.' );
				return;
			}

			$form.find( 'button' ).prop( 'disabled', true );

			post( 'qafesheh_svc_add', data )
				.done( function ( res ) {
					if ( res && res.success ) {
						$list.append( res.data.html );
						$( '#q-svc-empty' ).remove();
						$form[ 0 ].reset();
						$( '#q-svc-add-note' ).text( res.data.message );
						$form.find( '[name="title"]' ).trigger( 'focus' );
					} else {
						$( '#q-svc-add-note' ).text( ( res && res.data && res.data.message ) || A.error );
					}
				} )
				.fail( function () {
					$( '#q-svc-add-note' ).text( A.error );
				} )
				.always( function () {
					$form.find( 'button' ).prop( 'disabled', false );
				} );
		} );

		$list.on( 'click', '.q-svc__save', function () {
			var $row = $( this ).closest( '.q-svc__row' );
			var $btn = $( this );

			$btn.prop( 'disabled', true ).text( '…' );

			post( 'qafesheh_svc_save', {
				id: $row.data( 'id' ),
				num: $row.find( '.q-svc__in-num' ).val(),
				title: $row.find( '.q-svc__in-title' ).val(),
				excerpt: $row.find( '.q-svc__in-exc' ).val()
			} )
				.done( function ( res ) {
					$row.addClass( 'is-saved' );
					window.setTimeout( function () {
						$row.removeClass( 'is-saved' );
					}, 900 );
					say( ( res && res.data && res.data.message ) || A.saved );
				} )
				.fail( function () {
					say( A.error, true );
				} )
				.always( function () {
					$btn.prop( 'disabled', false ).text( 'حفظ' );
				} );
		} );

		$list.on( 'click', '.q-svc__trash', function () {
			if ( ! window.confirm( A.confirm ) ) {
				return;
			}

			var $row = $( this ).closest( '.q-svc__row' );

			post( 'qafesheh_svc_trash', { id: $row.data( 'id' ) } )
				.done( function ( res ) {
					$row.slideUp( 180, function () {
						$row.remove();
					} );
					say( ( res && res.data && res.data.message ) || A.saved );
				} )
				.fail( function () {
					say( A.error, true );
				} );
		} );

		$list.on( 'keydown', 'input', function ( e ) {
			if ( 13 === e.which ) {
				e.preventDefault();
				$( this ).closest( '.q-svc__row' ).find( '.q-svc__save' ).trigger( 'click' );
			}
		} );

	} );

}( jQuery ) );
