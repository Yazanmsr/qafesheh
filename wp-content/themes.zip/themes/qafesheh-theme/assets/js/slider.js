/**
 * سلايدر الهيرو — بلا مكتبات.
 * سحب حقيقي (pointer/touch)، أسهم كيبورد، عدّاد كسري، تشغيل تلقائي يتوقف
 * عند الهوفر أو عند إخفاء التبويب، وشريط تقدّم لكل شريحة.
 */
( function () {
	'use strict';

	var reduced = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

	function build( root ) {
		var track   = root.querySelector( '[data-q-track]' );
		var slides  = root.querySelectorAll( '.q-hs__slide' );
		var dots    = root.querySelectorAll( '.q-hs__dot' );
		var current = root.querySelector( '[data-q-now]' );
		var bar     = root.querySelector( '[data-q-bar]' );

		if ( ! track || slides.length < 1 ) {
			return;
		}

		var total    = slides.length;
		var index    = 0;
		var timer    = null;
		var delay    = Math.max( 2500, parseInt( root.getAttribute( 'data-autoplay' ) || '0', 10 ) );
		var auto     = delay > 0 && total > 1 && ! reduced;
		var rtl      = 'rtl' === ( document.documentElement.getAttribute( 'dir' ) || 'rtl' );
		var dragging = false;
		var startX   = 0;
		var deltaX   = 0;

		var AR = '٠١٢٣٤٥٦٧٨٩';

		function pad( n ) {
			var s = ( n < 10 ? '0' : '' ) + n;
			return s.replace( /[0-9]/g, function ( d ) {
				return AR.charAt( Number( d ) );
			} );
		}

		function paint() {
			each( slides, function ( slide, i ) {
				var on = ( i === index );
				slide.classList.toggle( 'is-on', on );
				slide.setAttribute( 'aria-hidden', on ? 'false' : 'true' );

				each( slide.querySelectorAll( 'a, button' ), function ( el ) {
					if ( on ) {
						el.removeAttribute( 'tabindex' );
					} else {
						el.setAttribute( 'tabindex', '-1' );
					}
				} );
			} );

			each( dots, function ( dot, i ) {
				dot.classList.toggle( 'is-on', i === index );
				dot.setAttribute( 'aria-selected', i === index ? 'true' : 'false' );
			} );

			if ( current ) {
				current.textContent = pad( index + 1 );
			}

			restartBar();
		}

		function restartBar() {
			if ( ! bar ) {
				return;
			}
			bar.style.transition = 'none';
			bar.style.transform  = 'scaleX(0)';

			/* إعادة تدفّق مقصودة حتى تعاد الحركة من الصفر */
			void bar.offsetWidth;

			if ( auto ) {
				bar.style.transition = 'transform ' + delay + 'ms linear';
				bar.style.transform  = 'scaleX(1)';
			}
		}

		function go( next ) {
			index = ( next + total ) % total;
			paint();
			schedule();
		}

		function schedule() {
			window.clearTimeout( timer );
			if ( auto ) {
				timer = window.setTimeout( function () {
					go( index + 1 );
				}, delay );
			}
		}

		function each( list, fn ) {
			Array.prototype.forEach.call( list, fn );
		}

		/* -------------------------------------------------- التحكّم */

		each( root.querySelectorAll( '[data-q-prev]' ), function ( b ) {
			b.addEventListener( 'click', function () {
				go( index - 1 );
			} );
		} );

		each( root.querySelectorAll( '[data-q-next]' ), function ( b ) {
			b.addEventListener( 'click', function () {
				go( index + 1 );
			} );
		} );

		each( dots, function ( dot, i ) {
			dot.addEventListener( 'click', function () {
				go( i );
			} );
		} );

		root.addEventListener( 'keydown', function ( e ) {
			if ( 'ArrowRight' === e.key ) {
				e.preventDefault();
				go( rtl ? index - 1 : index + 1 );
			} else if ( 'ArrowLeft' === e.key ) {
				e.preventDefault();
				go( rtl ? index + 1 : index - 1 );
			}
		} );

		root.addEventListener( 'mouseenter', function () {
			window.clearTimeout( timer );
			if ( bar ) {
				var w = bar.getBoundingClientRect().width / Math.max( 1, bar.parentNode.getBoundingClientRect().width );
				bar.style.transition = 'none';
				bar.style.transform  = 'scaleX(' + w + ')';
			}
		} );

		root.addEventListener( 'mouseleave', schedule );

		document.addEventListener( 'visibilitychange', function () {
			if ( document.hidden ) {
				window.clearTimeout( timer );
			} else {
				schedule();
			}
		} );

		/* -------------------------------------------------- السحب */

		track.addEventListener( 'pointerdown', function ( e ) {
			if ( total < 2 ) {
				return;
			}
			dragging = true;
			startX   = e.clientX;
			deltaX   = 0;
			track.setPointerCapture( e.pointerId );
			root.classList.add( 'is-dragging' );
			window.clearTimeout( timer );
		} );

		track.addEventListener( 'pointermove', function ( e ) {
			if ( ! dragging ) {
				return;
			}
			deltaX = e.clientX - startX;
		} );

		function endDrag() {
			if ( ! dragging ) {
				return;
			}
			dragging = false;
			root.classList.remove( 'is-dragging' );

			if ( Math.abs( deltaX ) > 60 ) {
				var forward = rtl ? deltaX > 0 : deltaX < 0;
				go( forward ? index + 1 : index - 1 );
			} else {
				schedule();
			}

			deltaX = 0;
		}

		track.addEventListener( 'pointerup', endDrag );
		track.addEventListener( 'pointercancel', endDrag );

		/* -------------------------------------------------- الإقلاع */

		root.classList.add( 'is-ready' );
		paint();
		schedule();
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		Array.prototype.forEach.call( document.querySelectorAll( '[data-q-slider]' ), build );
	} );

}() );
