/**
 * محرّك الحركة — IntersectionObserver واحد لكل الصفحة.
 * المراقبة على الحاوية لا على كل بطاقة، والتأخير يُحسب كـcustom property.
 * بلا مكتبات. يحترم prefers-reduced-motion وإطفاء الحركة من لوحة التحكم.
 */
( function () {
	'use strict';

	var cfg     = window.QAFESHEH || {};
	var reduced = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	var off     = reduced || 0 === Number( cfg.motion );
	var STEP    = 90;

	/* ------------------------------------------------------------ أدوات */

	function each( list, fn ) {
		Array.prototype.forEach.call( list, fn );
	}

	function showAll() {
		each( document.querySelectorAll( '[data-q-anim], [data-q-stagger], .q-lines' ), function ( el ) {
			el.classList.add( 'q-in' );
		} );
	}

	/* ------------------------------------------- تقسيم العنوان إلى أسطر */

	function buildLines( el ) {
		if ( el.dataset.qLinesReady ) {
			return;
		}

		var source = el.querySelectorAll( ':scope > span' );
		var lines  = [];

		if ( source.length ) {
			each( source, function ( s ) {
				lines.push( s.textContent );
			} );
		} else {
			lines = el.textContent.split( '\n' );
		}

		lines = lines.map( function ( t ) {
			return t.trim();
		} ).filter( Boolean );

		if ( ! lines.length ) {
			return;
		}

		el.textContent = '';

		lines.forEach( function ( text, i ) {
			var outer = document.createElement( 'span' );
			var inner = document.createElement( 'i' );

			inner.textContent = text;
			inner.style.setProperty( '--q-d', ( i * 110 ) + 'ms' );
			outer.appendChild( inner );
			el.appendChild( outer );
		} );

		el.dataset.qLinesReady = '1';
	}

	/* ------------------------------------------------------- العدّادات */

	var AR = '٠١٢٣٤٥٦٧٨٩';

	function isArabicDigits( str ) {
		return /[٠-٩]/.test( str );
	}

	function toArabic( n ) {
		return String( n ).replace( /[0-9]/g, function ( d ) {
			return AR.charAt( Number( d ) );
		} );
	}

	function toLatin( str ) {
		return str.replace( /[٠-٩]/g, function ( d ) {
			return String( AR.indexOf( d ) );
		} );
	}

	function runCounter( el ) {
		if ( el.dataset.qCounted ) {
			return;
		}
		el.dataset.qCounted = '1';

		var raw    = el.textContent.trim();
		var arabic = isArabicDigits( raw );
		var latin  = arabic ? toLatin( raw ) : raw;
		var match  = latin.match( /(\d+)/ );

		if ( ! match ) {
			return;
		}

		var target = parseInt( match[ 1 ], 10 );

		if ( ! target || target > 100000 ) {
			return;
		}

		var pad   = match[ 1 ].length;
		var start = performance.now();
		var dur   = Math.min( 1500, 420 + target * 9 );

		function frame( now ) {
			var p = Math.min( 1, ( now - start ) / dur );
			var e = 1 - Math.pow( 1 - p, 3 );
			var v = String( Math.round( target * e ) );

			while ( v.length < pad ) {
				v = '0' + v;
			}

			el.textContent = latin.replace( /\d+/, arabic ? toArabic( v ) : v );

			if ( p < 1 ) {
				requestAnimationFrame( frame );
			}
		}

		requestAnimationFrame( frame );
	}

	/* ----------------------------------------------------- نقطة الدخول */

	window.addEventListener( 'error', function () {
		document.documentElement.classList.add( 'q-reveal-all' );
	} );

	document.addEventListener( 'DOMContentLoaded', function () {

		/* العناوين تُقسَّم دائماً — حتى مع إطفاء الحركة يبقى الشكل سليماً */
		each( document.querySelectorAll( '.q-lines' ), buildLines );

		if ( off ) {
			document.documentElement.classList.remove( 'q-js' );
			showAll();
			each( document.querySelectorAll( '.q-count' ), function ( el ) {
				el.dataset.qCounted = '1';
			} );
			return;
		}

		if ( ! ( 'IntersectionObserver' in window ) ) {
			document.documentElement.classList.remove( 'q-js' );
			showAll();
			return;
		}

		/* ------------------------------------------ مراقب الدخول الموحّد */

		var io = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( entry ) {
				if ( ! entry.isIntersecting ) {
					return;
				}

				var el = entry.target;
				el.classList.add( 'q-in' );

				/* تدرّج الأبناء يُحسب مرة واحدة عند الدخول */
				if ( el.hasAttribute( 'data-q-stagger' ) ) {
					each( el.children, function ( child, i ) {
						child.style.setProperty( '--q-d', Math.min( i * STEP, 640 ) + 'ms' );
					} );
				}

				each( el.querySelectorAll( '.q-count' ), runCounter );

				if ( el.classList.contains( 'q-count' ) ) {
					runCounter( el );
				}

				io.unobserve( el );
			} );
		}, {
			rootMargin: '0px 0px -10% 0px',
			threshold: 0.12
		} );

		var watched = document.querySelectorAll( '[data-q-anim], [data-q-stagger], .q-lines' );

		each( watched, function ( el ) {
			io.observe( el );
		} );

		/* شبكة أمان: أي عنصر داخل الشاشة لم يُكشف بعد ثانيتين يُكشف قسراً،
		   وأي عنصر بقي مخفياً بعد ٦ ثوانٍ يُكشف مهما كان السبب.
		   بهذا لا يمكن لقسم أن يبقى فارغاً أبداً. */
		function sweep( force ) {
			each( document.querySelectorAll( '[data-q-anim]:not(.q-in), [data-q-stagger]:not(.q-in), .q-lines:not(.q-in)' ), function ( el ) {
				if ( force ) {
					el.classList.add( 'q-in' );
					return;
				}

				var r = el.getBoundingClientRect();
				if ( r.top < window.innerHeight && r.bottom > 0 ) {
					el.classList.add( 'q-in' );
					if ( el.hasAttribute( 'data-q-stagger' ) ) {
						each( el.children, function ( c, i ) {
							c.style.setProperty( '--q-d', Math.min( i * STEP, 640 ) + 'ms' );
						} );
					}
					each( el.querySelectorAll( '.q-count' ), runCounter );
				}
			} );
		}

		window.addEventListener( 'load', function () {
			sweep( false );
		} );

		window.setTimeout( function () {
			sweep( false );
		}, 2000 );

		window.setTimeout( function () {
			sweep( true );
		}, 6000 );

		/* ------------------------------------------------ توهّج المؤشر */

		each( document.querySelectorAll( '.q-spot' ), function ( el ) {
			el.addEventListener( 'pointermove', function ( e ) {
				var r = el.getBoundingClientRect();
				el.style.setProperty( '--mx', ( e.clientX - r.left ) + 'px' );
				el.style.setProperty( '--my', ( e.clientY - r.top ) + 'px' );
			} );
		} );

		/* ------------------------------------- الهيدر وشريط التقدّم */

		var progress = document.querySelector( '.q-progress span' );
		var ticking  = false;

		function onScroll() {
			if ( ticking ) {
				return;
			}
			ticking = true;

			requestAnimationFrame( function () {
				var y = window.scrollY || window.pageYOffset;

				document.body.classList.toggle( 'q-scrolled', y > 120 );

				if ( progress ) {
					var h = document.documentElement.scrollHeight - window.innerHeight;
					progress.style.width = ( h > 0 ? Math.min( 100, ( y / h ) * 100 ) : 0 ) + '%';
				}

				ticking = false;
			} );
		}

		window.addEventListener( 'scroll', onScroll, { passive: true } );
		onScroll();
	} );

}() );
