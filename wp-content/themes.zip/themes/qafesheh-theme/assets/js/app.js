/**
 * واجهة موقع مجموعة قفيشة — بلا مكتبات خارجية.
 */
( function () {
	'use strict';

	var cfg = window.QAFESHEH || {};

	document.addEventListener( 'DOMContentLoaded', function () {

		/* ------------------------------------------------ قائمة الموبايل */

		var burger = document.querySelector( '.q-burger' );
		var nav    = document.getElementById( 'q-nav' );

		if ( burger && nav ) {
			burger.addEventListener( 'click', function () {
				var open = nav.classList.toggle( 'is-open' );
				burger.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
				document.body.classList.toggle( 'q-nav-open', open );
			} );

			document.addEventListener( 'click', function ( e ) {
				if ( ! nav.classList.contains( 'is-open' ) ) {
					return;
				}
				if ( nav.contains( e.target ) || burger.contains( e.target ) ) {
					return;
				}
				nav.classList.remove( 'is-open' );
				burger.setAttribute( 'aria-expanded', 'false' );
				document.body.classList.remove( 'q-nav-open' );
			} );

			document.addEventListener( 'keydown', function ( e ) {
				if ( 'Escape' === e.key && nav.classList.contains( 'is-open' ) ) {
					nav.classList.remove( 'is-open' );
					burger.setAttribute( 'aria-expanded', 'false' );
					document.body.classList.remove( 'q-nav-open' );
					burger.focus();
				}
			} );
		}

		/* ------------------------------------------------ حركات الدخول */

		var reveals = document.querySelectorAll( '.q-r' );

		if ( reveals.length ) {
			if ( ! ( 'IntersectionObserver' in window ) || 0 === Number( cfg.motion ) ) {
				reveals.forEach( function ( el ) {
					el.classList.add( 'is-in' );
				} );
			} else {
				var io = new IntersectionObserver( function ( entries ) {
					entries.forEach( function ( entry, i ) {
						if ( ! entry.isIntersecting ) {
							return;
						}
						var el = entry.target;
						window.setTimeout( function () {
							el.classList.add( 'is-in' );
						}, Math.min( i * 70, 420 ) );
						io.unobserve( el );
					} );
				}, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 } );

				reveals.forEach( function ( el ) {
					io.observe( el );
				} );
			}
		}

		/* ------------------------------------------------ زر العودة للأعلى */

		var top = document.querySelector( '.q-top' );

		if ( top ) {
			var onScroll = function () {
				top.classList.toggle( 'is-on', window.scrollY > 600 );
			};

			window.addEventListener( 'scroll', onScroll, { passive: true } );
			onScroll();

			top.addEventListener( 'click', function () {
				window.scrollTo( { top: 0, behavior: 'smooth' } );
			} );
		}

		/* ------------------------------------------------ تحميل المزيد */

		var moreBtn = document.querySelector( '[data-q-more]' );

		if ( moreBtn && cfg.ajax ) {
			moreBtn.addEventListener( 'click', function () {
				var target = document.getElementById( moreBtn.getAttribute( 'data-q-target' ) || 'q-archive' );
				if ( ! target ) {
					return;
				}

				var page = parseInt( moreBtn.getAttribute( 'data-page' ) || '1', 10 );
				var body = new URLSearchParams();

				body.append( 'action', 'qafesheh_load_more' );
				body.append( 'nonce', cfg.nonce );
				body.append( 'page', page );
				body.append( 'post_type', moreBtn.getAttribute( 'data-q-more' ) );
				body.append( 'per_page', moreBtn.getAttribute( 'data-per' ) || '9' );

				moreBtn.disabled = true;
				moreBtn.textContent = ( cfg.i18n && cfg.i18n.loading ) || '…';

				fetch( cfg.ajax, {
					method: 'POST',
					credentials: 'same-origin',
					body: body
				} )
					.then( function ( r ) {
						return r.json();
					} )
					.then( function ( res ) {
						if ( ! res || ! res.success ) {
							throw new Error( 'bad response' );
						}

						target.insertAdjacentHTML( 'beforeend', res.data.html );
						moreBtn.setAttribute( 'data-page', page + 1 );

						target.querySelectorAll( '.q-r:not(.is-in)' ).forEach( function ( el ) {
							el.classList.add( 'is-in' );
						} );

						if ( res.data.more ) {
							moreBtn.disabled = false;
							moreBtn.textContent = ( cfg.i18n && cfg.i18n.more ) || 'المزيد';
						} else {
							moreBtn.textContent = ( cfg.i18n && cfg.i18n.end ) || '';
							moreBtn.hidden = true;
						}
					} )
					.catch( function () {
						moreBtn.disabled = false;
						moreBtn.textContent = ( cfg.i18n && cfg.i18n.error ) || 'خطأ';
					} );
			} );
		}

		/* ------------------------------------------------ فلتر الفروع */

		var filter = document.querySelector( '[data-q-filter]' );
		var list   = document.querySelector( '[data-q-branches]' );

		if ( filter && list ) {
			filter.addEventListener( 'click', function ( e ) {
				var btn = e.target.closest( '.q-filter__b' );
				if ( ! btn ) {
					return;
				}

				var brand = btn.getAttribute( 'data-brand' ) || '';

				filter.querySelectorAll( '.q-filter__b' ).forEach( function ( b ) {
					b.classList.toggle( 'is-on', b === btn );
				} );

				list.querySelectorAll( '[data-brands]' ).forEach( function ( card ) {
					var brands = ( card.getAttribute( 'data-brands' ) || '' ).split( ' ' );
					var show   = ( ! brand || brands.indexOf( brand ) !== -1 );
					card.classList.toggle( 'is-hidden', ! show );
				} );
			} );
		}

		/* ------------------------------------------------ نموذج الشكاوى */

		var form = document.querySelector( '[data-q-complaint]' );

		if ( form && cfg.ajax ) {
			form.addEventListener( 'submit', function ( e ) {
				e.preventDefault();

				var note   = form.querySelector( '[data-q-note]' );
				var submit = form.querySelector( '[type="submit"]' );
				var data   = new FormData( form );

				data.append( 'action', 'qafesheh_complaint' );
				data.append( 'nonce', cfg.nonce );

				if ( submit ) {
					submit.disabled = true;
				}

				fetch( cfg.ajax, {
					method: 'POST',
					credentials: 'same-origin',
					body: data
				} )
					.then( function ( r ) {
						return r.json();
					} )
					.then( function ( res ) {
						var ok = res && res.success;

						if ( note ) {
							note.textContent = ( res && res.data && res.data.message ) || '';
							note.className = 'q-form__note ' + ( ok ? 'is-ok' : 'is-err' );
						}

						if ( ok ) {
							form.reset();
						}
						if ( submit ) {
							submit.disabled = false;
						}
					} )
					.catch( function () {
						if ( note ) {
							note.textContent = ( cfg.i18n && cfg.i18n.error ) || '';
							note.className = 'q-form__note is-err';
						}
						if ( submit ) {
							submit.disabled = false;
						}
					} );
			} );
		}

	} );

}() );
